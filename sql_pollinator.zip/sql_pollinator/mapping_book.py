"""Read/write the mapping workbook (openpyxl only, to keep the .exe small).

Sheets
  Tables  : A1/B1 = pod labels (source pod, target pod); rows below = table names.
  Columns : source_table, target_table, source_column, target_column, status, match_method, confidence, notes
  Schemas : (optional) A1/B1 = pod labels; rows = schema placeholder in pod A -> pod B
Only rows whose status is 'confirmed' are applied by the converter (missing status column = confirmed).
"""
from dataclasses import dataclass
import openpyxl

TABLE_SHEET, COLUMN_SHEET, SCHEMA_SHEET = "Tables", "Columns", "Schemas"
VARIABLE_SHEET, LITERAL_SHEET = "Variables", "Literals"
COLUMN_HEADERS = ["source_table", "target_table", "source_column", "target_column",
                  "status", "match_method", "confidence", "notes"]


def _c(v):
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return "" if v is None else str(v).strip()


def _rows(ws):
    try:
        ws.reset_dimensions()          # read-only sheets sometimes report a wrong used range
    except Exception:  # noqa
        pass
    return ws.iter_rows(values_only=True)


def _triples(ws, labels):
    """name | value in pod A | value in pod B  (value columns located by pod-label header, else positional)."""
    it = _rows(ws)
    head = [_c(h).lower() for h in next(it, [])]
    lo = [x.lower() for x in labels]
    ia = head.index(lo[0]) if lo[0] in head[1:] else 1
    ib = head.index(lo[1]) if lo[1] in head[1:] else 2
    out = []
    for r in it:
        r = list(r) + [None] * 3
        if _c(r[0]):
            out.append((_c(r[0]), _c(r[ia]), _c(r[ib])))
    return out


@dataclass
class Directed:
    table_rows: list
    column_rows: list
    schema_rows: list
    variable_rows: list = None      # (name, value in source pod, value in target pod)
    literal_rows: list = None       # (column or '', value in source pod, value in target pod)


class MappingBook:
    def __init__(self, labels, table_rows, column_rows, schema_rows, path="", variable_rows=None, literal_rows=None):
        self.labels, self.table_rows = tuple(labels), table_rows
        self.column_rows, self.schema_rows, self.path = column_rows, schema_rows, path
        self.variable_rows, self.literal_rows = variable_rows or [], literal_rows or []

    @classmethod
    def load(cls, path):
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            names = wb.sheetnames
            ws = wb[TABLE_SHEET] if TABLE_SHEET in names else wb[names[0]]
            rows = [tuple((list(map(_c, r)) + ["", ""])[:2]) for r in _rows(ws)]
            if not rows or not rows[0][0] or not rows[0][1]:
                raise ValueError("First row of the table sheet must hold the two pod labels in columns A and B.")
            labels = rows[0]
            if labels[0].lower() == labels[1].lower():
                raise ValueError("The two pod labels in row 1 must be different.")
            tables = [r for r in rows[1:] if r[0] and r[1]]
            cols, schemas = [], []
            if COLUMN_SHEET in names:
                it = _rows(wb[COLUMN_SHEET])
                head = [_c(h).lower() for h in next(it, [])]
                for r in it:
                    d = {h: _c(v) for h, v in zip(head, r) if h}
                    if d.get("source_table") and d.get("target_table"):
                        d.setdefault("status", "confirmed")
                        d["status"] = d["status"] or "confirmed"
                        cols.append(d)
            if SCHEMA_SHEET in names:
                srows = [tuple((list(map(_c, r)) + ["", ""])[:2]) for r in _rows(wb[SCHEMA_SHEET])]
                schemas = [r for r in srows[1:] if r[0] and r[1]]
            variables = _triples(wb[VARIABLE_SHEET], labels) if VARIABLE_SHEET in names else []
            literals = _triples(wb[LITERAL_SHEET], labels) if LITERAL_SHEET in names else []
            return cls(labels, tables, cols, schemas, str(path), variables, literals)
        finally:
            wb.close()

    def directed(self, source, target):
        lo = [x.lower() for x in self.labels]
        s, t = source.lower(), target.lower()
        if s == t:
            raise ValueError("Source and target pod must be different.")
        if (s, t) == (lo[0], lo[1]):
            return Directed(list(self.table_rows), list(self.column_rows), list(self.schema_rows),
                            list(self.variable_rows), list(self.literal_rows))
        if (s, t) == (lo[1], lo[0]):
            swap = {"source_table": "target_table", "target_table": "source_table",
                    "source_column": "target_column", "target_column": "source_column"}
            cols = [{swap.get(k, k): v for k, v in r.items()} for r in self.column_rows]
            return Directed([(b, a) for a, b in self.table_rows], cols, [(b, a) for a, b in self.schema_rows],
                            [(n, b, a) for n, a, b in self.variable_rows], [(n, b, a) for n, a, b in self.literal_rows])
        raise ValueError(f"Selection {source!r} -> {target!r} is not covered by this workbook.")


def _value_sheet(wb, title, first_header, labels, rows):
    ws = wb.create_sheet(title)
    ws.append([first_header, labels[0], labels[1]])
    for r in rows:
        ws.append(list(r))


def write_mapping_workbook(path, labels, table_rows, column_rows, schema_rows=(), variable_rows=(), literal_rows=()):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = TABLE_SHEET
    ws.append(list(labels))
    for r in table_rows:
        ws.append(list(r))
    ws = wb.create_sheet(COLUMN_SHEET)
    ws.append(COLUMN_HEADERS)
    for r in column_rows:
        ws.append([r.get(h, "") for h in COLUMN_HEADERS])
    ws = wb.create_sheet(SCHEMA_SHEET)
    ws.append(list(labels))
    for r in schema_rows:
        ws.append(list(r))
    _value_sheet(wb, VARIABLE_SHEET, "variable", labels, variable_rows)
    _value_sheet(wb, LITERAL_SHEET, "column (optional)", labels, literal_rows)
    wb.save(path)


def save_value_sheets(path, labels, variable_rows, literal_rows):
    """Write the Variables / Literals sheets back into an existing workbook (everything else is kept)."""
    wb = openpyxl.load_workbook(path)
    for name in (VARIABLE_SHEET, LITERAL_SHEET):
        if name in wb.sheetnames:
            del wb[name]
    _value_sheet(wb, VARIABLE_SHEET, "variable", labels, variable_rows)
    _value_sheet(wb, LITERAL_SHEET, "column (optional)", labels, literal_rows)
    wb.save(path)


def write_report_workbook(path, sheets):
    """sheets: {name: (headers, rows)}"""
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for name, (headers, rows) in sheets.items():
        ws = wb.create_sheet(name[:31])
        ws.append(headers)
        for r in rows:
            ws.append(["" if v is None else v for v in r])
        for i, h in enumerate(headers, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = max(14, min(50, len(str(h)) + 6))
    wb.save(path)
