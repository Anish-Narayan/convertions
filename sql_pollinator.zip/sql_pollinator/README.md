# SQL Pod Cross-Pollination Tool - run it in this order

Converts SQL written for **Pod A** into the equivalent for **Pod B** using table/column mappings.
Two parts: **Component A** (analysis -> builds the mapping workbook) and **Component B** (GUI converter, packaged as .exe).

## Files
| File | Purpose |
|---|---|
| `analysis_engine.py` | **Component A** command-line analyser |
| `converter_gui.py` | **Component B** GUI (entry point for the .exe) |
| `converter.py` | conversion engine used by the GUI |
| `sql_resolver.py` | SQLGlot-based table/column/alias/CTE resolution (used by A and B) |
| `sql_common.py` | dialect, concept splitting, `$(schema)` <-> `tempN` registry, name matching |
| `column_matching.py` | name-based column candidate matching |
| `mapping_book.py` | read/write the Excel mapping workbook |
| `requirements-analysis.txt` / `requirements-converter.txt` | dependencies |
| `build_exe.bat` | builds `SQLConverter.exe` (Windows) |
| `tests/` | `test_pure.py` (no SQLGlot needed), `test_conversion.py` (needs SQLGlot) |
| `examples/` | sample SQL files, table mapping, synonyms, test input |

## Step 1 - Install (Python 3.10+)
```
python -m venv .venv
.venv\Scripts\activate            (Linux/macOS: source .venv/bin/activate)
pip install -r requirements-analysis.txt
```

## Step 2 - Run the tests
```
python -m unittest discover tests -v
```
The conversion tests were not run by the author (no SQLGlot in the build sandbox). If one fails, report the message.

## Step 3 - Prepare the inputs for Component A
1. `source.sql`, `target.sql`: one concept per pod. Optional `--concept_name` header lines split a file into concepts.
2. `table_mapping.xlsx`: row 1 = pod labels (A1 = source pod, B1 = target pod); then `source_table | target_table`.
   Write schema placeholders exactly as in the SQL, e.g. `$(gold.schema).claims`.

## Step 4 - Run the analysis (Component A)
```
python analysis_engine.py examples/source_podA.sql examples/target_podB.sql examples/table_mapping.xlsx --out analysis_out --synonyms examples/synonyms.json
```
Drop `--synonyms` to use pure name similarity. Other options: `--abbreviations abbr.json`, `--min-score 0.5`, `--no-similarity`.

Outputs in `analysis_out/`:
- `pod_mapping.xlsx` - **reusable mapping workbook** (Tables, Columns, Schemas sheets)
- `mapping_review.xlsx` - TableMapping, ColumnMapping (all candidates + confidence), Log, StructuralSimilarity
- `source_metadata.json`, `target_metadata.json`, `analysis_log.txt`
- `source.temp.sql`, `target.temp.sql`, `schema_map.json` (temporary copies; originals untouched)

## Step 5 - Review and confirm mappings (manual, important)
Open `analysis_out/pod_mapping.xlsx` -> sheet **Columns**.
- Only identical column names are auto-`confirmed`.
- Change `status` to `confirmed` for suggestions you accept; delete rejected alternatives.
- `ambiguous` / `unmapped` rows are never applied. Name similarity is not proof of equal meaning.
- Optional: sheet **Schemas** - pod-A placeholder in column A, pod-B placeholder in column B (e.g. `$(gold.schema)` -> `$(silver.schema)`).

## Step 6 - Run the converter GUI (Component B)
```
python converter_gui.py
```
1. **Upload mapping Excel** -> choose `pod_mapping.xlsx` (dropdowns fill from `Tables!A1:B1`).
2. Pick source and target pod.
3. Paste SQL on the left (try `examples/test_input.sql`; for variables try `examples/test_input_vars.sql` with
   `examples/sample_pod_mapping.xlsx`). Optional: **Variables & values…** (see below). Then **Convert**.
4. Read the status area (counts, warnings, applied mappings). Edit the output if needed.
5. **Copy Output** or **Save SQL**. **Clear** resets both boxes.

Converting from Pod B to Pod A also works (inverse mappings).

## Step 7 - Build the standalone .exe (Windows)
```
build_exe.bat
```
Runs: `pyinstaller --noconfirm --onefile --windowed --name SQLConverter --collect-all sqlglot converter_gui.py`
Result: `dist\SQLConverter.exe`. Distribute it with `pod_mapping.xlsx`; no Python needed on the user machine.

## Placeholders: how replace / restore works
- `$(gold.schema)` and `${gold.schema}` are replaced by `temp1`, `temp2`, ... (same placeholder = same id in both files;
  different placeholders = different ids), the SQL is parsed, and the ids are restored afterwards.
- Works when a placeholder is glued to a name (`$(env)_claims`, `claims_$(env)`), appears in strings or comments, or
  is a qualifier chain (`$(a).$(b).table`). Ids that already exist in your SQL (e.g. a real `temp1`) are never reused.
- **Safety check:** before parsing, the tool proves that restoring the replaced text gives back the exact original. If not, it stops
  with an error. After conversion it warns if a placeholder from the input is missing from the output.
- Target-pod schemas: if a table mapping has both names schema-qualified (`$(gold.schema).claims -> $(silver.schema).claim_header`),
  the schema pair `gold -> silver` is inferred and used for target names written without a schema. Conflicting evidence is
  not guessed (warning). The optional `Schemas` sheet always overrides the inference.
- A `$(amt)` used as a value is not mistaken for a column.

## Variables and values (change 100 to 50 for another pod)
Click **Variables & values…** before Convert. The dialog lists variables found in the source SQL:
`$(amt)` / `${amt}` placeholders, `SET amt = 100;` and `DECLARE ... DEFAULT 100;`.
Type the value the TARGET pod should use (placeholders are replaced by it, SET/DECLARE values are rewritten; the value
may itself be a placeholder, e.g. `$(amt_b)`). Empty = leave as is.

**Column value rules** change a literal compared with a column: `claims.claim_amount | 1000 -> 750` changes
`claim_amount > 1000` and `1000 = claim_amount`, `IN (...)`, `BETWEEN ...` but not other uses of 1000.
Leaving the column empty changes every matching literal (a warning shows how many).

Persist them: **Use & save to workbook** writes the `Variables` and `Literals` sheets (columns: name | value in pod A | value in pod B).
They are then applied automatically whenever that direction is converted (and inverted for the reverse direction).
Explicit values typed in the dialog override the workbook.

## Edge cases handled
- Unqualified columns in multi-table queries are flagged, never guessed; select aliases and `$(variables)` are not treated as columns.
- `claims.col` / `claims.*` without an alias follow the table rename; columns renamed inside CTEs/subqueries/CREATE AS keep their old
  output name via an alias, so later references still work.
- Same column name in two tables maps per table; internal (created) tables are never renamed.
- Column mappings are found even if the Columns sheet writes table names with a different qualification than the Tables sheet.
- Already-converted input is refused; unexpected errors give a clear message and never a half-converted output.
- Excel: numeric cells, trailing spaces, wrong stored sheet dimensions, and non-UTF-8 SQL files are handled.

## Behaviour and limits
- SQL is never executed.
- Unqualified columns in multi-table queries must be qualified with an alias by you (flagged, not guessed).
- Output is regenerated by SQLGlot: formatting is normalised, comments may move.
- `JOIN ... USING` is flagged, not rewritten. `MERGE`/`UPDATE` use a simpler resolver.
- `SET`/`DECLARE` detection is line-based: a value containing `;` inside quotes is not supported, and `UPDATE ... \n SET col = 1`
  on its own line also looks like a variable (only changed if you give that name a value).
- Value rules match literals by exact text (`100` does not match `100.00`) and do not handle negative numbers.
- Only `$(x)`/`${x}` placeholders are understood (not Jinja `{{ x }}`).
- A target table without schema keeps the source schema (warning) unless it can be inferred or mapped in `Schemas`.
