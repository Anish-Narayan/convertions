"""Component B engine - converts SQL from one pod to another using a mapping workbook. Never executes SQL."""
from collections import defaultdict
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp

from mapping_book import MappingBook
import re

from sql_common import (DIALECT, PLACEHOLDER, SchemaRegistry, apply_variables, infer_schema_pairs,
                        lookup_entries, match_entry, norm_key, split_parts)
from sql_resolver import QUERY_TYPES, rename_node, resolve_script


@dataclass
class ConversionResult:
    ok: bool = False
    sql: str = ""
    warnings: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    applied: list = field(default_factory=list)
    pending: list = field(default_factory=list)   # choices the user can still make: {id, kind, label, options}
    summary: dict = field(default_factory=lambda: dict(
        tables_mapped=0, columns_mapped=0, join_references_updated=0,
        unmapped_objects=0, ambiguous_mappings=0, aliases_added=0, values_changed=0))

    def report(self):
        s = self.summary
        lines = ["CONVERSION " + ("SUCCEEDED" if self.ok else "FAILED"), "",
                 f"Tables mapped:            {s['tables_mapped']}",
                 f"Columns mapped:           {s['columns_mapped']}",
                 f"Join references updated:  {s['join_references_updated']}",
                 f"Values/variables changed: {s['values_changed']}",
                 f"Unmapped objects:         {s['unmapped_objects']}",
                 f"Ambiguous mappings:       {s['ambiguous_mappings']}",
                 f"Aliases added (to keep internal column names stable): {s['aliases_added']}"]
        for title, items in (("ERRORS", self.errors), ("WARNINGS", self.warnings), ("APPLIED", self.applied)):
            if items:
                lines += ["", title + ":"] + [f"  - {i}" for i in items]
        lines += ["", "Note: mappings are name/mapping-file based; semantic equivalence is NOT validated. Review before use."]
        return "\n".join(lines)


def _fail(res, msg):
    res.ok, res.sql = False, ""
    res.errors.append(msg)
    return res


def _in_join_condition(col):
    return isinstance(col.find_ancestor(exp.Join, *QUERY_TYPES), exp.Join)


def _apply_table(ref, target_raw, schema_map, kept_schemas, used_schemas):
    node = ref.node
    old_cat, old_db = node.catalog, node.db
    parts = split_parts(target_raw)
    new_name = parts[-1]
    if len(parts) >= 2:
        new_db, new_cat = parts[-2], (parts[-3] if len(parts) >= 3 else None)
    else:
        new_db, new_cat = old_db or None, old_cat or None
        mapped = schema_map.get(old_db.lower()) if old_db else None
        if mapped:
            used_schemas.add((old_db, mapped))
            mp = split_parts(mapped)
            new_db, new_cat = mp[-1], (mp[-2] if len(mp) >= 2 else new_cat)
        elif old_db:
            kept_schemas.add(old_db)
    node.set("this", exp.to_identifier(new_name))
    node.set("db", exp.to_identifier(new_db) if new_db else None)
    node.set("catalog", exp.to_identifier(new_cat) if new_cat else None)
    ref.renamed_to = (new_cat, new_db, new_name)


def _requalify(col, ref):
    """Column written as claims.col (no alias) must follow the table rename."""
    if not col.table or ref.alias:
        return False
    cat, db, name = ref.renamed_to
    col.set("table", exp.to_identifier(name))
    if col.args.get("db") is not None:
        col.set("db", exp.to_identifier(db) if db else None)
    if col.args.get("catalog") is not None:
        col.set("catalog", exp.to_identifier(cat) if cat else None)
    return True


_NUM = re.compile(r"-?\d+(\.\d+)?")
_CMP = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE)


def _compared_literals(col):
    """Literals directly compared with this column: col > 100, 100 <= col, col IN (1,2), col BETWEEN 1 AND 2."""
    p = col.parent
    if isinstance(p, _CMP):
        other = p.right if p.left is col else p.left
        return [other] if isinstance(other, exp.Literal) else []
    if isinstance(p, exp.In) and p.this is col:
        return [e for e in p.expressions if isinstance(e, exp.Literal)]
    if isinstance(p, exp.Between) and p.this is col:
        return [e for e in (p.args.get("low"), p.args.get("high")) if isinstance(e, exp.Literal)]
    return []


def _new_literal(old, new):
    return exp.Literal.string(new) if (old.is_string or not _NUM.fullmatch(new)) else exp.Literal.number(new)


def _col_matches(spec, c):
    parts = spec.lower().split(".")
    if c.name.lower() != parts[-1]:
        return False
    if len(parts) == 1:
        return True
    prefix = ".".join(parts[:-1])
    return bool((c.table and match_entry(prefix, c.table.key)) or prefix == c.qualifier.lower())


def _apply_literal_rules(infos, rules, res):
    """rules: {(column_spec_or_'', old_value): new_value}. Column rules first, then global ones."""
    S, new_nodes = res.summary, set()
    col_rules = {k: v for k, v in rules.items() if k[0]}
    for i in infos:
        for c in i.columns:
            if c.kind != "column" or c.status == "star":
                continue
            for lit in _compared_literals(c.node):
                if id(lit) in new_nodes:
                    continue
                for (spec, old), new in col_rules.items():
                    if lit.this == old and _col_matches(spec, c):
                        n = _new_literal(lit, new)
                        lit.replace(n); new_nodes.add(id(n)); S["values_changed"] += 1
                        res.applied.append(f"value {spec}: {old} -> {new}")
                        break
    for (spec, old), new in rules.items():
        if spec:
            continue
        count = 0
        for i in infos:
            for lit in list(i.node.find_all(exp.Literal)):
                if lit.this == old and id(lit) not in new_nodes:
                    n = _new_literal(lit, new)
                    lit.replace(n); new_nodes.add(id(n)); count += 1
        if count:
            S["values_changed"] += count
            res.applied.append(f"value (any column): {old} -> {new}  x{count}")
            res.warnings.append(f"Value rule {old} -> {new} has no column and was applied to {count} literal(s) "
                                "anywhere in the SQL; add a column name to limit it.")


def convert_sql(*args, **kwargs):
    """Public entry point: any unexpected error becomes a failed result, never a crash or a half-converted output."""
    try:
        return _convert(*args, **kwargs)
    except Exception as e:  # noqa
        res = ConversionResult()
        return _fail(res, f"Unexpected error: {type(e).__name__}: {e}. No output generated.")


def _convert(sql, book: MappingBook, source_label, target_label, preserve_internal_names=True, force=False, choices=None,
             variables=None, literal_rules=None):
    """choices: {choice_id: option or ''} (ids from result.pending). variables: {name: new value text}.
    literal_rules: [{'column': 'tbl.col' or '', 'source_value': '100', 'target_value': '50'}]."""
    choices = choices or {}
    pend = {}
    res = ConversionResult()
    S = res.summary
    if not sql.strip():
        return _fail(res, "Source SQL is empty.")
    try:
        d = book.directed(source_label, target_label)
    except ValueError as e:
        return _fail(res, str(e))
    if not d.table_rows:
        return _fail(res, "The workbook contains no table mappings.")

    # --- 0: variable values for the target pod (explicit UI values override workbook defaults) ---
    vals = {n: t for n, _, t in (d.variable_rows or []) if t}
    vals.update({k: v for k, v in (variables or {}).items()})
    sql, var_log = apply_variables(sql, vals)
    S["values_changed"] += len(var_log)
    res.applied += var_log

    # --- 1-3: schema placeholders -> temp ids (same logic as the analysis engine) ---
    registry = SchemaRegistry()
    try:
        tmp = registry.replace(sql)
        if registry.restore(tmp) != sql:                    # guarantee: replace + restore is lossless
            return _fail(res, "Internal check failed: schema placeholders could not be restored losslessly.")
        entries, tgt_keys, colmap, schema_map = defaultdict(list), set(), defaultdict(lambda: defaultdict(list)), {}
        for s_raw, t_raw in d.table_rows:
            t = registry.replace(t_raw)
            entries[norm_key(registry.replace(s_raw))].append(t)
            tgt_keys.add(norm_key(t))
        for r in d.column_rows:
            if r.get("source_column") and r.get("target_column"):
                pair = (norm_key(registry.replace(r["source_table"])), norm_key(registry.replace(r["target_table"])))
                colmap[pair][r["source_column"].lower()].append((r["target_column"], (r.get("status") or "confirmed").lower()))
        inferred, conflicts = infer_schema_pairs([(registry.replace(s_), registry.replace(t_)) for s_, t_ in d.table_rows])
        schema_map = {k: v[1] for k, v in inferred.items()}        # evidence: both names qualified in the table mapping
        for k in conflicts:
            res.warnings.append(f"Schema '{registry.restore(k)}' maps to several target schemas in the table mapping; "
                                "add it to the 'Schemas' sheet.")
        for a, b in d.schema_rows:                                  # explicit sheet wins
            schema_map[norm_key(registry.replace(a))] = registry.replace(b)
    except ValueError as e:
        return _fail(res, str(e))
    if not d.column_rows:
        res.warnings.append("Workbook has no column mappings: only table names will be converted.")

    # --- 4: parse (fail loudly) ---
    try:
        stmts = [s for s in sqlglot.parse(tmp, read=DIALECT) if s is not None]
    except Exception as e:  # noqa
        return _fail(res, f"Parse error ({DIALECT}): {e}")
    if not stmts:
        return _fail(res, "No SQL statements found.")
    infos, _ = resolve_script(stmts)
    for i in infos:
        res.errors += [f"Statement {i.index}: {e}" for e in i.errors]
        res.warnings += [f"Statement {i.index}: {w}" for w in i.warnings]
    if res.errors:
        return _fail(res, "Analysis failed; no output generated.")

    # --- safeguard: already converted? ---
    ext = {r.key for i in infos for r in i.tables if not r.internal}
    n_src = sum(1 for k in ext if lookup_entries(entries, k)[1])
    n_tgt = sum(1 for k in ext if any(match_entry(t, k) for t in tgt_keys))
    if n_tgt and not n_src and not force:
        return _fail(res, "Input already uses target-pod tables and none of the source tables; "
                          "not converting again (to avoid double conversion).")
    if n_tgt and n_src:
        res.warnings.append("Input mixes source-pod and target-pod table names; verify the result.")

    # --- value rules (workbook defaults + UI rules) on the source-side names, before anything is renamed ---
    rules = {(c.strip(), o): n for c, o, n in (d.literal_rows or []) if o and n}
    for r_ in literal_rules or []:
        if str(r_.get("source_value", "")).strip() and str(r_.get("target_value", "")).strip():
            rules[(r_.get("column", "").strip(), str(r_["source_value"]).strip())] = str(r_["target_value"]).strip()
    if rules:
        _apply_literal_rules(infos, rules, res)

    cm_cache = {}

    def colmap_for(pair):
        """Exact (table entry, table entry) match first; else rows whose table names are a suffix match."""
        if pair not in cm_cache:
            if pair in colmap:
                cm_cache[pair] = colmap[pair]
            else:
                merged = defaultdict(list)
                for (sk, tk), m in colmap.items():
                    if match_entry(sk, pair[0]) and match_entry(tk, pair[1]):
                        for k, v in m.items():
                            merged[k] += v
                cm_cache[pair] = merged
        return cm_cache[pair]

    # --- 5-7: tables ---
    kept_schemas, used_schemas, unmapped_t, unmapped_c, skipped = set(), set(), set(), set(), set()
    names_by_schema = defaultdict(set)
    for i in infos:
        for r in i.tables:
            if not r.internal:
                names_by_schema[r.node.name.lower()].add(r.node.db.lower())
    for i in infos:
        for r in i.tables:
            if r.internal:
                continue
            ek, targets = lookup_entries(entries, r.key)
            distinct = sorted(set(targets))
            tid = f"table:{r.key}"
            if len(distinct) > 1 and tid in choices:
                pick = {registry.restore(t): t for t in distinct}.get(choices[tid])
                if not pick:
                    if tid not in skipped:
                        skipped.add(tid)
                        res.warnings.append(f"Table {r.key}: left unchanged by your choice.")
                    continue
                distinct = [pick]
            if not distinct:
                if r.key not in unmapped_t:
                    res.warnings.append(f"Unmapped table: {r.key} (left unchanged)")
                unmapped_t.add(r.key)
            elif len(distinct) > 1:
                S["ambiguous_mappings"] += 1
                res.warnings.append(f"Ambiguous table mapping for {r.key}: {', '.join(distinct)} (left unchanged)")
                pend.setdefault(tid, dict(id=tid, kind="table", label=f"Table {registry.restore(r.key)}",
                                          options=[registry.restore(t) for t in distinct]))
            else:
                if len(ek.split(".")) < len(r.key.split(".")) and len(names_by_schema[r.node.name.lower()]) > 1:
                    res.warnings.append(f"Table '{r.node.name}' appears under several schemas; unqualified mapping "
                                        f"entry applied to {r.key}. Verify.")
                if r.role in ("insert", "update", "delete", "merge", "drop"):
                    res.warnings.append(f"Statement {i.index}: {r.role.upper()} on external table {r.key}; verify target.")
                old = r.key
                _apply_table(r, distinct[0], schema_map, kept_schemas, used_schemas)
                r.pair = (ek, norm_key(distinct[0]))
                S["tables_mapped"] += 1
                res.applied.append(f"table {old} -> {'.'.join(p for p in r.renamed_to if p)}")
    for a, b in sorted(used_schemas):
        res.applied.append(f"schema {registry.restore(a)} -> {registry.restore(b)} (for tables whose target name has no schema)")
    for s in sorted(kept_schemas):
        res.warnings.append(f"Schema '{s}' kept from source: no target schema in table mapping or 'Schemas' sheet.")

    # --- 6-8: columns, only in the context of their own table mapping ---
    stars = set()
    for i in infos:
        for c in i.columns:
            if not c.qualifier and c.name in registry.temp_to_placeholder:
                continue                                  # a $(variable) used as a value, not a column
            if c.status in ("ambiguous", "unresolved"):
                S["ambiguous_mappings"] += 1
                res.warnings.append(f"Statement {i.index}: cannot tell which table column "
                                    f"'{c.node.sql(dialect=DIALECT)}' belongs to ({c.status}); left unchanged. "
                                    "Qualify it with a table alias.")
                continue
            ref = c.table
            if ref is None or ref.internal or ref.pair is None:
                continue
            if c.status == "star":
                _requalify(c.node, ref)                    # claims.*  ->  claim_header.*
                stars.add(ref.key)
                continue
            changed = False
            if c.kind == "column":
                changed = _requalify(c.node, ref)
            cands = colmap_for(ref.pair).get(c.name.lower(), [])
            confirmed = sorted({t for t, st in cands if st == "confirmed"})
            label = f"{ref.key}.{c.name}"
            new = None
            if len(confirmed) == 1:
                new = confirmed[0]
            elif cands:                      # several confirmed, ambiguous, or only suggested -> user chooses
                cid = f"col:{ref.key}.{c.name.lower()}"
                opts = sorted({t for t, _ in cands})
                if cid in choices:
                    if choices[cid] in opts:
                        new = choices[cid]
                    elif cid not in skipped:
                        skipped.add(cid)
                        res.warnings.append(f"Column {label}: left unchanged by your choice.")
                elif cid not in pend:
                    S["ambiguous_mappings"] += 1
                    pend[cid] = dict(id=cid, kind="column", label=f"Column {registry.restore(ref.key)}.{c.name}", options=opts)
                    res.warnings.append(f"Column {label}: {len(opts)} candidate mapping(s), none chosen; left unchanged.")
            else:
                if label not in unmapped_c and d.column_rows:
                    res.warnings.append(f"No column mapping for {label} (table is mapped); left unchanged.")
                unmapped_c.add(label)
            if new is not None and new != c.name:
                col = c.node
                wrap = (preserve_internal_names and c.kind == "column" and isinstance(col.parent, exp.Select)
                        and col.arg_key == "expressions" and col.parent.find_ancestor(exp.CTE, exp.Subquery, exp.Create))
                rename_node(col, new)
                if wrap:
                    col.replace(exp.alias_(col.copy(), c.name))
                    S["aliases_added"] += 1
                S["columns_mapped"] += 1
                changed = True
                res.applied.append(f"column {label} -> {new}")
            if changed and c.kind == "column" and _in_join_condition(c.node):
                S["join_references_updated"] += 1
    for i in infos:
        for j in i.joins:
            if j["using"]:
                S["ambiguous_mappings"] += 1
                res.warnings.append(f"Statement {i.index}: JOIN ... USING ({', '.join(j['using'])}) not rewritten; "
                                    "verify column names exist in both tables.")
    for k in sorted(stars):
        res.warnings.append(f"SELECT * / alias.* used on {k}: columns now come from the target table; verify downstream use.")
    S["unmapped_objects"] = len(unmapped_t) + len(unmapped_c)
    res.pending = list(pend.values())

    # --- 9-10: generate, restore schemas, re-parse as a syntax check ---
    try:
        out = ";\n\n".join(s.sql(dialect=DIALECT, pretty=True) for s in stmts) + ";"
        sqlglot.parse(out, read=DIALECT)          # syntax check while schemas are still temp ids
        out = registry.restore(out)
        before = {m.group(0) for m in PLACEHOLDER.finditer(sql)}
        after = {m.group(0) for m in PLACEHOLDER.finditer(out)}
        for ph in sorted(before - after):
            if registry.placeholder_to_temp.get(ph, "").lower() not in schema_map:
                res.warnings.append(f"Placeholder {ph} from the input does not appear in the output; check the result.")
    except Exception as e:  # noqa
        return _fail(res, f"Generated SQL failed validation: {e}")
    res.ok, res.sql = True, out
    res.warnings.append("Output is regenerated by SQLGlot: formatting is normalised and comments may move slightly.")
    return res
