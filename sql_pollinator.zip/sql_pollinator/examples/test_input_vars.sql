SET amt = 100;
SELECT a.member_id, a.claim_amount
FROM $(gold.schema).claims a
WHERE a.claim_amount > $(amt)
  AND a.claim_amount < 1000
  AND a.service_date >= '2024-01-01';
