--claims_by_beneficiary
SELECT h.beneficiary_id, h.allowed_amount, m.provider_name
FROM $(silver.schema).claim_header h
LEFT JOIN $(silver.schema).provider_master m ON h.provider_key = m.provider_key
WHERE h.date_of_service >= '2024-01-01';
