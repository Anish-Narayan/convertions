--claims_by_member
SELECT a.member_id, a.claim_amount, p.provider_name
FROM $(gold.schema).claims a
LEFT JOIN $(gold.schema).providers p ON a.provider_id = p.provider_id
WHERE a.service_date >= '2024-01-01';
