SELECT a.member_id, a.claim_amount
FROM $(gold.schema).claims a
WHERE a.service_date >= '2024-01-01';
