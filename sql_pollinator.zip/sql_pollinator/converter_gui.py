"""Tkinter front end for the conversion engine (entry point for the .exe)."""
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from converter import convert_sql
from mapping_book import MappingBook, save_value_sheets
from sql_common import detect_variables


LEAVE = "(leave unchanged)"


class ChoiceDialog(tk.Toplevel):
    """Lets the user pick one candidate for every ambiguous table/column mapping."""

    def __init__(self, parent, pending):
        super().__init__(parent)
        self.title("Choose mappings")
        self.transient(parent)
        self.result, self.vars = None, {}
        ttk.Label(self, text="These mappings have more than one candidate. Pick the one to use "
                             "(or leave unchanged), then click Apply.", wraplength=560).pack(padx=10, pady=8, anchor="w")
        outer = ttk.Frame(self); outer.pack(fill="both", expand=True, padx=10)
        canvas = tk.Canvas(outer, height=min(380, 46 * len(pending) + 10), highlightthickness=0)
        bar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw"); canvas.configure(yscrollcommand=bar.set)
        canvas.pack(side="left", fill="both", expand=True); bar.pack(side="right", fill="y")
        for row, item in enumerate(pending):
            ttk.Label(inner, text=item["label"], font=("Segoe UI", 9, "bold")).grid(row=row, column=0, sticky="w", padx=4, pady=6)
            var = tk.StringVar(value=LEAVE)
            ttk.Combobox(inner, textvariable=var, state="readonly", width=38,
                         values=[LEAVE] + item["options"]).grid(row=row, column=1, padx=8, pady=6)
            self.vars[item["id"]] = var
        btns = ttk.Frame(self); btns.pack(pady=10)
        ttk.Button(btns, text="Apply & Convert", command=self.apply).pack(side="left", padx=6)
        ttk.Button(btns, text="Skip (leave all unchanged)", command=self.destroy).pack(side="left", padx=6)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.grab_set(); self.wait_window()

    def apply(self):
        self.result = {k: ("" if v.get() == LEAVE else v.get()) for k, v in self.vars.items()}
        self.destroy()


def _scroll(parent, height):
    outer = ttk.Frame(parent)
    canvas = tk.Canvas(outer, height=height, highlightthickness=0)
    bar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    inner = ttk.Frame(canvas)
    inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="nw"); canvas.configure(yscrollcommand=bar.set)
    canvas.pack(side="left", fill="both", expand=True); bar.pack(side="right", fill="y")
    return outer, inner


class ValuesDialog(tk.Toplevel):
    """Edit variable values (e.g. amt 100 -> 50) and column value rules for the target pod."""

    def __init__(self, parent, detected, defaults, variables, rules, src_label, tgt_label):
        super().__init__(parent)
        self.title(f"Variables & values:  {src_label}  ->  {tgt_label}")
        self.transient(parent)
        self.result = None
        ttk.Label(self, wraplength=640, text=(
            "Variables found in the source SQL are listed with their current value. Type the value the TARGET pod "
            "should use; empty = leave as is. Placeholders like $(amt) are replaced by the value; SET / DECLARE "
            "values are rewritten.")).pack(padx=10, pady=(8, 4), anchor="w")
        names = {d["name"]: d for d in detected}
        for n, _, t in defaults:
            names.setdefault(n, {"name": n, "kind": "workbook", "value": "", "count": 0})
        o1, f1 = _scroll(self, 170); o1.pack(fill="x", padx=10)
        for c, h in enumerate(("Variable", "Kind", f"Current ({src_label})", f"New value ({tgt_label})")):
            ttk.Label(f1, text=h, font=("Segoe UI", 9, "bold")).grid(row=0, column=c, padx=4, sticky="w")
        dflt = {n: t for n, _, t in defaults}
        self.var_entries = {}
        for r, (n, d) in enumerate(sorted(names.items()), 1):
            ttk.Label(f1, text=n).grid(row=r, column=0, sticky="w", padx=4)
            ttk.Label(f1, text=d["kind"]).grid(row=r, column=1, sticky="w", padx=4)
            ttk.Label(f1, text=d["value"] or "-").grid(row=r, column=2, sticky="w", padx=4)
            e = ttk.Entry(f1, width=24); e.grid(row=r, column=3, padx=4, pady=2)
            e.insert(0, variables.get(n, dflt.get(n, "")))
            self.var_entries[n] = e
        if not names:
            ttk.Label(f1, text="No variables detected in the source SQL.").grid(row=1, column=0, columnspan=4)

        ttk.Label(self, text="Column value rules - change a literal compared with a column "
                             "(column may be empty = every matching literal, or e.g. claims.claim_amount)",
                  wraplength=640).pack(padx=10, pady=(10, 2), anchor="w")
        o2, self.f2 = _scroll(self, 130); o2.pack(fill="x", padx=10)
        for c, h in enumerate(("Column (optional)", f"From ({src_label})", f"To ({tgt_label})")):
            ttk.Label(self.f2, text=h, font=("Segoe UI", 9, "bold")).grid(row=0, column=c, padx=4, sticky="w")
        self.rule_rows = []
        for r in (rules or []):
            self.add_rule(r)
        self.add_rule()
        ttk.Button(self, text="+ Add rule row", command=self.add_rule).pack(anchor="w", padx=10, pady=4)
        b = ttk.Frame(self); b.pack(pady=8)
        ttk.Button(b, text="Use for Convert", command=lambda: self.done(False)).pack(side="left", padx=5)
        ttk.Button(b, text="Use & save to workbook", command=lambda: self.done(True)).pack(side="left", padx=5)
        ttk.Button(b, text="Cancel", command=self.destroy).pack(side="left", padx=5)
        self.grab_set(); self.wait_window()

    def add_rule(self, rule=None):
        r = len(self.rule_rows) + 1
        es = []
        for c, key in enumerate(("column", "source_value", "target_value")):
            e = ttk.Entry(self.f2, width=24 if c else 30); e.grid(row=r, column=c, padx=4, pady=2)
            e.insert(0, (rule or {}).get(key, "")); es.append(e)
        self.rule_rows.append(es)

    def done(self, save):
        self.result = {
            "variables": {n: e.get().strip() for n, e in self.var_entries.items()},   # '' = explicitly no change
            "rules": [dict(column=a.get().strip(), source_value=b.get().strip(), target_value=c.get().strip())
                      for a, b, c in self.rule_rows if b.get().strip() and c.get().strip()],
            "save": save}
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SQL Pod Converter")
        self.geometry("1200x780")
        self.book, self.last_output, self.choices = None, None, {}
        self.variables, self.rules = {}, []
        self.report_callback_exception = self._on_error      # no silent failures in the windowed .exe
        self.columnconfigure(0, weight=1); self.columnconfigure(1, weight=1)
        self.rowconfigure(2, weight=3); self.rowconfigure(4, weight=1)

        top = ttk.Frame(self); top.grid(row=0, column=0, columnspan=2, sticky="ew", padx=8, pady=6)
        ttk.Button(top, text="Upload mapping Excel…", command=self.load_book).pack(side="left")
        self.file_lbl = ttk.Label(top, text="No workbook loaded"); self.file_lbl.pack(side="left", padx=10)

        self.src_var, self.tgt_var = tk.StringVar(), tk.StringVar()
        for col, (txt, var) in enumerate((("Source pod", self.src_var), ("Target pod", self.tgt_var))):
            f = ttk.Frame(self); f.grid(row=1, column=col, sticky="ew", padx=8)
            ttk.Label(f, text=txt).pack(side="left")
            cb = ttk.Combobox(f, textvariable=var, state="readonly", width=30); cb.pack(side="left", padx=6)
            setattr(self, "cb_src" if col == 0 else "cb_tgt", cb)
        self.src_txt = scrolledtext.ScrolledText(self, wrap="none", undo=True, font=("Consolas", 10))
        self.out_txt = scrolledtext.ScrolledText(self, wrap="none", undo=True, font=("Consolas", 10))
        self.src_txt.grid(row=2, column=0, sticky="nsew", padx=8, pady=4)
        self.out_txt.grid(row=2, column=1, sticky="nsew", padx=8, pady=4)

        for v in (self.src_var, self.tgt_var):
            v.trace_add("write", lambda *a: self._reset_session())
        bar = ttk.Frame(self); bar.grid(row=3, column=0, columnspan=2, pady=4)
        for text, cmd in (("Variables & values…", self.edit_values), ("Convert", self.convert), ("Clear", self.clear),
                          ("Copy Output", self.copy_out), ("Save SQL", self.save)):
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=5)
        self.status = scrolledtext.ScrolledText(self, height=10, wrap="word", state="disabled", font=("Consolas", 9))
        self.status.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=8, pady=6)
        self.status.tag_config("err", foreground="#b00020"); self.status.tag_config("ok", foreground="#1b6e1b")

    def _on_error(self, exc, val, tb):
        import traceback
        self.log("Unexpected error:\n" + "".join(traceback.format_exception(exc, val, tb)), "err")

    def _reset_session(self):
        self.choices, self.variables, self.rules = {}, {}, []

    def edit_values(self):
        if self.book is None:
            return self.log("Upload a mapping workbook first.", "err")
        src, tgt = self.src_var.get(), self.tgt_var.get()
        if not src or not tgt or src == tgt:
            return self.log("Choose two different pods.", "err")
        d = self.book.directed(src, tgt)
        det = detect_variables(self.src_txt.get("1.0", "end"))
        rules = self.rules or [dict(column=c, source_value=a, target_value=b) for c, a, b in d.literal_rows]
        dlg = ValuesDialog(self, det, d.variable_rows, self.variables, rules, src, tgt)
        if dlg.result is None:
            return
        self.variables, self.rules = dlg.result["variables"], dlg.result["rules"]
        msg = f"{len([v for v in self.variables.values() if v])} variable value(s) and {len(self.rules)} value rule(s) will be used on Convert."
        if dlg.result["save"]:
            try:
                self.save_values(d, det, src)
                msg += " Saved to the workbook."
            except Exception as e:  # noqa
                return self.log(f"Could not save to the workbook (is it open in Excel?):\n{e}", "err")
        self.log(msg, "ok")

    def save_values(self, d, detected, src):
        """Write values back into the workbook, oriented as the workbook's own pod columns."""
        cur = {x["name"]: x["value"] for x in detected}
        forward = src.lower() == self.book.labels[0].lower()
        orient = (lambda n, a, b: (n, a, b)) if forward else (lambda n, a, b: (n, b, a))
        old = {n: (a, b) for n, a, b in d.variable_rows}
        vrows = {n: orient(n, a, b) for n, (a, b) in old.items()}
        for n, new in self.variables.items():
            vrows[n] = orient(n, cur.get(n, old.get(n, ("", ""))[0]), new)
        lrows = [orient(r["column"], r["source_value"], r["target_value"]) for r in self.rules]
        other = [r for r in (self.book.literal_rows) if r not in [orient(*x) for x in d.literal_rows]]
        save_value_sheets(self.book.path, self.book.labels, list(vrows.values()), lrows + other)
        self.book.variable_rows, self.book.literal_rows = list(vrows.values()), lrows + other

    def log(self, text, tag=None):
        self.status.config(state="normal"); self.status.delete("1.0", "end")
        self.status.insert("end", text, tag); self.status.config(state="disabled")

    def load_book(self):
        path = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not path:
            return
        try:
            self.book = MappingBook.load(path)
            self._reset_session()
        except Exception as e:  # noqa
            self.book = None
            return self.log(f"Could not read workbook:\n{e}", "err")
        labels = list(self.book.labels)          # populated from the workbook, never hard-coded
        self.cb_src["values"] = self.cb_tgt["values"] = labels
        self.src_var.set(labels[0]); self.tgt_var.set(labels[1])
        self.file_lbl.config(text=path)
        self.log(f"Loaded {len(self.book.table_rows)} table mappings, {len(self.book.column_rows)} column rows.", "ok")

    def convert(self):
        if self.book is None:
            return self.log("Upload a mapping workbook first.", "err")
        if not self.src_var.get() or not self.tgt_var.get() or self.src_var.get() == self.tgt_var.get():
            return self.log("Choose two different pods.", "err")
        sql = self.src_txt.get("1.0", "end").strip()
        force = False
        if self.last_output and sql == self.last_output.strip():
            if not messagebox.askyesno("Already converted", "This text is the previous converted output. Convert again?"):
                return
            force = True
        args = (sql, self.book, self.src_var.get(), self.tgt_var.get())
        extra = dict(variables=self.variables, literal_rules=self.rules)
        res = convert_sql(*args, force=force, choices=self.choices, **extra)
        if res.ok and res.pending:                       # ambiguous mappings -> ask the user which one
            picked = ChoiceDialog(self, res.pending).result
            if picked is not None:
                self.choices.update(picked)
                res = convert_sql(*args, force=force, choices=self.choices, **extra)
        self.out_txt.delete("1.0", "end")
        if res.ok:
            self.out_txt.insert("1.0", res.sql)
            self.last_output = res.sql
        self.log(res.report(), "ok" if res.ok and not res.errors else "err")

    def clear(self):
        self.src_txt.delete("1.0", "end"); self.out_txt.delete("1.0", "end")
        self.last_output, self.choices = None, {}; self.log("Cleared (remembered choices reset; variable values kept).")

    def copy_out(self):
        self.clipboard_clear(); self.clipboard_append(self.out_txt.get("1.0", "end").strip())
        self.log("Output copied to clipboard.", "ok")

    def save(self):
        text = self.out_txt.get("1.0", "end").strip()
        if not text:
            return self.log("Nothing to save.", "err")
        path = filedialog.asksaveasfilename(defaultextension=".sql", filetypes=[("SQL", "*.sql")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text + "\n")
            self.log(f"Saved {path}", "ok")


if __name__ == "__main__":
    App().mainloop()
