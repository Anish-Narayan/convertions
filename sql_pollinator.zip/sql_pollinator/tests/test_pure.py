"""Tests that need no SQLGlot: schema registry, column matching, workbook round trip."""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sql_common import (SchemaRegistry, norm_key, match_entry, lookup_entries, detect_variables,
                        apply_variables, infer_schema_pairs)
from column_matching import ColumnMatcher
from mapping_book import MappingBook, write_mapping_workbook


class T(unittest.TestCase):
    def test_registry_consistent_and_distinct(self):
        r = SchemaRegistry()
        a = r.replace("SELECT * FROM $(gold.schema).claims JOIN $(silver.schema).m")
        b = r.replace("SELECT * FROM $(gold.schema).x")
        self.assertEqual(a, "SELECT * FROM temp1.claims JOIN temp2.m")
        self.assertEqual(b, "SELECT * FROM temp1.x")
        self.assertEqual(r.restore(a), "SELECT * FROM $(gold.schema).claims JOIN $(silver.schema).m")

    def test_registry_avoids_existing_temp_ids(self):
        r = SchemaRegistry()
        r.reserve("SELECT 1 FROM temp1.t")
        self.assertEqual(r.replace("$(a.b).t"), "temp2.t")
        r2 = SchemaRegistry(); r2.replace("$(a)")
        with self.assertRaises(ValueError):
            r2.replace("SELECT * FROM temp1.t")

    def test_name_matching(self):
        self.assertTrue(match_entry("claims", "a.claims"))
        self.assertFalse(match_entry("a.claims", "b.claims"))
        self.assertFalse(match_entry("a.claims", "claims"))
        self.assertEqual(lookup_entries({"claims": [1], "a.claims": [2]}, "a.claims")[1], [2])

    def test_column_matching(self):
        m = ColumnMatcher()
        rows = m.match(["member_id", "claim_amt", "svc"], ["member_id", "ClaimAmount", "other"])
        by = {r["source_column"]: r for r in rows if r["source_column"]}
        self.assertEqual(by["member_id"]["status"], "confirmed")
        self.assertEqual(by["claim_amt"]["target_column"], "ClaimAmount")
        self.assertIn(by["claim_amt"]["status"], ("suggested",))
        self.assertEqual(by["svc"]["status"], "unmapped")

    def test_synonyms_only_when_supplied(self):
        self.assertEqual(ColumnMatcher().match(["member_id"], ["beneficiary_id"])[0]["status"], "unmapped")
        m = ColumnMatcher(synonym_groups=[["member", "beneficiary"]])
        r = m.match(["member_id"], ["beneficiary_id"])[0]
        self.assertEqual((r["match_method"], r["status"]), ("normalized", "suggested"))

    def test_workbook_roundtrip_and_direction(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "m.xlsx")
            write_mapping_workbook(p, ("PodA", "PodB"), [("claims", "claim_header")],
                                   [dict(source_table="claims", target_table="claim_header", source_column="a",
                                         target_column="b", status="confirmed")], [("$(x)", "$(y)")])
            b = MappingBook.load(p)
            self.assertEqual(b.labels, ("PodA", "PodB"))
            rev = b.directed("PodB", "PodA")
            self.assertEqual(rev.table_rows, [("claim_header", "claims")])
            self.assertEqual(rev.column_rows[0]["source_column"], "b")
            with self.assertRaises(ValueError):
                b.directed("PodA", "PodA")


class TestAmbiguity(unittest.TestCase):
    def rows(self):
        mk = lambda t, rank, sc: dict(source_table="claims", target_table="ch", source_column="amt",
                                      target_column=t, rank=rank, status="ambiguous",
                                      match_method="token_fuzzy", confidence=sc)
        return [mk("allowed_amount", 1, .7), mk("billed_amount", 2, .68)]

    def test_pending_choice_and_reject(self):
        import resolve_ambiguities as ra
        rows = self.rows()
        (key, _), = ra.pending_groups(rows).items()
        out = ra.apply_choice(rows, key, "billed_amount")
        self.assertEqual([(r["target_column"], r["status"]) for r in out], [("billed_amount", "confirmed")])
        self.assertEqual(ra.pending_groups(out), {})
        self.assertEqual(ra.apply_choice(rows, key, "")[0]["status"], "unmapped")
        self.assertEqual(ra.apply_choice(rows, key, "x_amt")[0]["match_method"], "manual")

    def test_conflict_detection(self):
        import resolve_ambiguities as ra
        r = [dict(source_table="c", target_table="t", source_column=s, target_column="x", status="confirmed")
             for s in ("a", "b")]
        self.assertEqual(len(ra.conflicts(r)), 1)

    def test_roundtrip_glued_and_brace_placeholders(self):
        for sql in ["SELECT * FROM $(env)_claims", "SELECT * FROM claims_$(env)", "FROM ${gold.schema}.claims JOIN $(a).$(b).t",
                    "WHERE x > $(amt) AND n = '$(amt)' -- $(amt)", "SELECT temp1x, attempt1 FROM t_$(z)"]:
            r = SchemaRegistry()
            tmp = r.replace(sql)
            self.assertNotIn("$", tmp)
            self.assertEqual(r.restore(tmp), sql)

    def test_variables_detect_and_apply(self):
        sql = "SET amt = 100 -- keep\n;\nDECLARE lim INT DEFAULT 5;\nSELECT $(thr), $(s).x FROM t WHERE a > $(amt)"
        found = {d["name"]: d for d in detect_variables(sql)}
        self.assertEqual(set(found), {"amt", "lim", "thr"})          # $(s) is a schema, not a variable
        self.assertEqual(found["amt"]["value"], "100")
        out, log = apply_variables(sql, {"amt": "50", "thr": "7", "lim": "9", "s": "zzz"})
        self.assertIn("SET amt = 50 -- keep", out); self.assertIn("DEFAULT 9;", out)
        self.assertIn("SELECT 7, $(s).x", out); self.assertIn("a > 50", out)
        self.assertEqual(apply_variables(sql, {"amt": ""})[0], sql)

    def test_schema_inference(self):
        m, bad = infer_schema_pairs([("temp1.a", "temp2.b"), ("temp1.c", "temp2.d"), ("x.p", "y.q"), ("x.r", "z.q")])
        self.assertEqual(m["temp1"][1], "temp2"); self.assertNotIn("x", m); self.assertEqual(bad, ["x"])

    def test_values_sheets_roundtrip_and_swap(self):
        from mapping_book import save_value_sheets
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "m.xlsx")
            write_mapping_workbook(p, ("PodA", "PodB"), [("c", "h")], [], [], [("amt", "100", "50")], [("claim_amount", "100", 50.0)])
            b = MappingBook.load(p)
            self.assertEqual(b.variable_rows, [("amt", "100", "50")]); self.assertEqual(b.literal_rows, [("claim_amount", "100", "50")])
            self.assertEqual(b.directed("PodB", "PodA").variable_rows, [("amt", "50", "100")])
            save_value_sheets(p, b.labels, [("amt", "100", "60")], [])
            b2 = MappingBook.load(p)
            self.assertEqual((b2.variable_rows, b2.literal_rows, b2.table_rows), ([("amt", "100", "60")], [], [("c", "h")]))


if __name__ == "__main__":
    unittest.main()
