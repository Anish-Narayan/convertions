@echo off
rem Builds dist\PodPollinator.exe (no Python needed on the target machine). pod_data.xlsx is created next to the exe.
pip install pyinstaller -r requirements.txt
pyinstaller --noconfirm --onefile --name PodPollinator --add-data "web;web" app.py
