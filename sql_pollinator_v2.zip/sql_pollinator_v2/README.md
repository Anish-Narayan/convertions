# Pod Cross-Pollination Tool (v2)

One local UI (browser, served from your machine - no cloud, **no LLM, no network**) with three tabs, backed by **one Excel file**.

| Tab | What it does |
|---|---|
| **1 · Pods & queries** | Add pods/clients and their queries. Stored in the `Queries` sheet of `pod_data.xlsx`. Shows the selection reason(s) found in each query and an *Explain* view (tables, aliases, joins, filters as understood). |
| **2 · Analyze** | Pick two pods → **Analyze**. Queries are matched by **selection reason**; each matched pair is compared (tables, columns, joins). Results are written to Excel; re-analysing **overwrites** that pod pair. Shows a *"queries changed since - re-analyze"* flag. |
| **3 · Cross-pollinate** | Pick *from* pod → *to* pod, paste one or many queries, **Convert**. Output is ready to copy and run (Copy / Copy all). Manual replacements can be added and survive re-analysis. |

## Run
```
pip install -r requirements.txt
python app.py                       # opens http://127.0.0.1:8765, data in ./pod_data.xlsx
python app.py --data D:\pods\pods.xlsx --port 9000
```
Or `run.bat` / `run.sh`. Try the demo: `python app.py --data examples/sample_pod_data.xlsx`.
Windows exe: `build_exe.bat` -> `dist\PodPollinator.exe`.
Tests: `python -m unittest discover tests -v`.

You can also edit the workbook in Excel (add rows to `Queries`). Close Excel before using the app - Excel locks the file; the app tells you if it is locked.

## Excel workbook
`Pods`, `Queries` (pod, query_name, selection_reason_override, updated_at, sql…; SQL longer than ~30 000 chars continues in `sql_2`, `sql_3`…),
`Concepts` (one row per matched pair), `TableMap`, `ColumnMap`, `JoinMap`, `Unmatched` (reasons without a counterpart), `Runs`, `Overrides`.
Analysis sheets are rewritten per pod pair on every Analyze. `Overrides` is never touched by analysis.

## Where the selection reason comes from (all case-insensitive; `selectionreason` = `selection_reason` = `Selection Reason`)
1. `'x' AS selectionreason` (also `CASE WHEN … THEN 'x' ELSE 'y' END AS selectionreason` - only THEN/ELSE values count)
2. `INSERT INTO t (…, selectionreason, …) SELECT/VALUES …` (literal in the same position)
3. predicates `selectionreason = 'x'` / `IN ('x','y')` / `LIKE`
4. `SET selectionreason = 'x'` / `DECLARE VARIABLE selectionreason DEFAULT 'x'`
5. comments `-- selectionreason: x`
6. `named_struct('selectionreason','x')` / `map(...)`
7. the **override** box in the UI / sheet column (replaces everything above)

Reasons are compared after lower-casing, removing punctuation and collapsing spaces (`Type-2 Diabetes!` = `type 2 diabetes`).
With a `UNION` where each branch has its own reason, only that branch (plus the CTEs/temp tables it reads) is compared for that reason.

## How two queries are compared
1. **Instances**: every table occurrence is one instance (a table joined twice = two instances) with alias, join type, columns used, filters, position. CTEs, sub-queries, derived tables and temp tables/views created in the same script are traced through (lineage), so joins are always reported between *real* tables.
2. **Table alignment**: each instance of A is paired with an instance of B using name similarity, shared columns, join columns, **same filter values** (e.g. the same ICD codes), join type, root/non-root position, output names, and *"joined to an already-aligned table in the same way"*. One-to-one, with a confidence and the evidence. This is what finds *"claims used twice (INNER) in A ↔ two different tables (LEFT) in B"*; it is reported in the concept's notes.
3. **Column alignment** inside aligned tables: same name, same join position, same output name, same filter values, same select position, similar name - evidence is combined into a confidence.
4. **Join comparison**: equivalent / join type differs / different columns / only in one side.

## How conversion works
The pasted SQL is edited **in place** (formatting, comments, `$(placeholders)` untouched):
* tables are replaced **per instance** - if the analysis saw the same source table in several roles, join type / columns pick the right target;
* columns follow the chosen table; unqualified columns are placed using the column catalog learned from all queries; if still ambiguous they are left alone and reported;
* alias-less `claims.col` follows the table rename;
* a column renamed inside a CTE / temp table / `CREATE … AS` gets `AS old_name` so later references keep working (final `SELECT` keeps the target's names unless you tick the option);
* optional: align join types (INNER↔LEFT) where the analysis learned that pod B uses another type;
* anything unmapped is left unchanged and listed. `JOIN … USING (col)` is rewritten only when both sides agree.
Direction B→A is the inverse of the same analysis.

## The SQL parser (no dependencies)
Own tokenizer + structural parser for Databricks/Spark SQL: `$(a.b)`, `${a}`, `{{a}}` (also glued: `$(env)_claims`), backticks, `::`, `:json:path`, lambdas, `INTERVAL`, window/`FILTER`/`WITHIN GROUP`, `QUALIFY`, `LATERAL VIEW`, `PIVOT`, `TIMESTAMP AS OF`, `USING`, all join kinds, CTEs (incl. recursive & shadowing), set operations, sub-queries, `CREATE … AS`, `INSERT`, `MERGE`, `UPDATE`, `DELETE`, `SET`/`DECLARE`.
Layered fallbacks: **(1)** structural parse → **(2)** if a statement fails or tokens are left over, a token-based extractor (tables after FROM/JOIN/INTO, `alias.column`, ON text) with a warning → **(3)** unknown statement kinds are kept verbatim. It never raises; the Pods tab shows `parsed` / `fallback parse`. 3 000 randomly mutated queries are fuzz-tested.

## Limits (be aware)
* Matching is by *name/structure evidence*, not meaning - check low-confidence rows (the UI colours them); fix with **Manual replacements**.
* One source table that is *split* over several target tables cannot be rewritten automatically (the analysis notes show it).
* Unqualified columns in multi-table queries without catalog evidence are not guessed.
* SQL is never executed.
