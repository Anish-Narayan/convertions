"""Cross-pod comparison of two concept queries that share a selection reason.

Pipeline for one pair (query A in pod A, query B in pod B):
  1. instance alignment   which table instance of A plays the same role as which instance of B
                          (name, columns, join columns, filter values, join type, position, neighbours)
  2. column alignment     inside every aligned instance pair (same name, same join position, same output
                          name, same filter values, select position, fuzzy name)
  3. join comparison      every join edge of A against the edge between the aligned instances of B
  4. pattern notes        table used twice in A but two different tables in B, INNER vs LEFT, extra tables ...
All rule based and deterministic; every decision carries its evidence text and a confidence value.
"""
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher

THRESHOLD = 24.0
STRUCT_THRESHOLD = 20.0          # lower bar when the pair is also joined to an already aligned pair
STOP_TOKENS = {"tbl", "table", "dim", "fact", "vw", "view", "v", "t", "tmp", "temp", "the"}


# ---------------------------------------------------------------------------------------- name similarity
def _tokens(name):
    name = re.sub(r"([a-z])([A-Z])", r"\1_\2", str(name))
    toks = re.findall(r"[a-z]+|\d+", name.lower())
    return [t for t in toks if t not in STOP_TOKENS] or toks


def _tok_eq(a, b):
    if a == b:
        return 1.0
    s, l = (a, b) if len(a) <= len(b) else (b, a)
    if len(s) >= 3 and l.startswith(s):
        return 0.85
    if len(s) >= 3 and s[0] == l[0]:                      # abbreviation: clm ~ claim
        it = iter(l)
        if all(ch in it for ch in s):
            return 0.7
    return 0.0


def name_sim(a, b):
    a, b = str(a).lower(), str(b).lower()
    if a == b:
        return 1.0
    ta, tb = _tokens(a), _tokens(b)
    best = 0.0
    if ta and tb:
        total = 0.0
        used = set()
        for x in ta:
            m, mj = 0.0, None
            for j, y in enumerate(tb):
                if j in used:
                    continue
                v = _tok_eq(x, y)
                if v > m:
                    m, mj = v, j
            if mj is not None:
                used.add(mj)
            total += m
        best = total / ((len(ta) + len(tb)) / 2.0)
    return max(best, SequenceMatcher(None, a, b).ratio() * 0.85)


def _jac(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a | b) else 0.0


# ---------------------------------------------------------------------------------------- results
@dataclass
class TablePair:
    a: object            # Instance or None
    b: object
    score: float = 0.0
    evidence: list = field(default_factory=list)

    @property
    def confidence(self):
        return round(min(0.99, self.score / 100.0), 2) if self.a is not None and self.b is not None else 0.0


@dataclass
class ColumnPair:
    pair: TablePair
    col_a: str
    col_b: str
    usage: str
    confidence: float
    basis: str


@dataclass
class JoinRow:
    a_text: str
    b_text: str
    a_type: str
    b_type: str
    status: str
    note: str = ""


@dataclass
class Alignment:
    tables: list = field(default_factory=list)
    columns: list = field(default_factory=list)
    joins: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    unmatched_cols: list = field(default_factory=list)


def _clauses_usage(clauses):
    clauses = set(clauses)
    if clauses & {"on", "using"}:
        return "join"
    if "where" in clauses or "having" in clauses or "qualify" in clauses:
        return "filter"
    if "select" in clauses:
        return "select"
    return "other"


def _edges_of(edges, inst):
    return [e for e in edges if e.a is inst or e.b is inst]


# ---------------------------------------------------------------------------------------- instance alignment
def _static_score(a, b):
    s, ev = 0.0, []
    if a.name == b.name:
        s += 40
        ev.append("same table name")
    else:
        sim = name_sim(a.name, b.name)
        if sim >= 0.5:
            s += 28 * (sim - 0.5) / 0.5
            ev.append(f"similar table name ({sim:.0%})")
    ca, cb = {c for c in a.col_names if c != "*"}, {c for c in b.col_names if c != "*"}
    if ca and cb:
        exact = ca & cb
        s += 25 * len(exact) / len(ca | cb)
        rest_a, rest_b = ca - exact, cb - exact
        fz = sum(1 for x in rest_a if any(name_sim(x, y) >= 0.8 for y in rest_b))
        s += 6 * fz / len(ca | cb)
        if exact:
            ev.append("shared columns: " + ", ".join(sorted(exact)[:5]))
    ja, jb = {c for c in a.join_cols if c != "*"}, {c for c in b.join_cols if c != "*"}
    if ja and jb:
        s += 10 * _jac(ja, jb)
    fa = {v for f in a.filters for v in f[2]}
    fb = {v for f in b.filters for v in f[2]}
    if fa and fb and fa & fb:
        s += 14 * len(fa & fb) / len(fa | fb)
        ev.append("same filter values: " + ", ".join(sorted(fa & fb)[:4]))
    if {f[0] for f in a.filters} & {f[0] for f in b.filters}:
        s += 3
    if a.join_type == b.join_type:
        s += 4
    s += 3 if a.is_root == b.is_root else -3
    if a.depth == b.depth:
        s += 2
    oa, ob = {o[0] for o in a.outputs if o[0]}, {o[0] for o in b.outputs if o[0]}
    if oa & ob:
        s += 10
        ev.append("same output name: " + ", ".join(sorted(oa & ob)[:3]))
    return s, ev


def _assign(IA, IB, S, structural=frozenset()):
    pairs = sorted(((S[(i, j)], i, j) for i in range(len(IA)) for j in range(len(IB))), key=lambda x: (-x[0], x[1], x[2]))
    ua, ub, out = set(), set(), {}
    for sc, i, j in pairs:
        if sc < STRUCT_THRESHOLD:
            break
        if sc < THRESHOLD and (i, j) not in structural:
            continue
        if i in ua or j in ub:
            continue
        ua.add(i); ub.add(j)
        out[i] = j
    return out


def align_instances(IA, IB, edges_a, edges_b):
    static, ev = {}, {}
    for i, a in enumerate(IA):
        for j, b in enumerate(IB):
            static[(i, j)], ev[(i, j)] = _static_score(a, b)
    idx_a = {id(x): k for k, x in enumerate(IA)}
    idx_b = {id(x): k for k, x in enumerate(IB)}
    nbA = {i: [] for i in range(len(IA))}
    nbB = {j: [] for j in range(len(IB))}
    for e in edges_a:
        if id(e.a) in idx_a and id(e.b) in idx_a:
            nbA[idx_a[id(e.a)]].append((idx_a[id(e.b)], e.col_a, e.col_b))
            nbA[idx_a[id(e.b)]].append((idx_a[id(e.a)], e.col_b, e.col_a))
    for e in edges_b:
        if id(e.a) in idx_b and id(e.b) in idx_b:
            nbB[idx_b[id(e.a)]].append((idx_b[id(e.b)], e.col_a, e.col_b))
            nbB[idx_b[id(e.b)]].append((idx_b[id(e.a)], e.col_b, e.col_a))
    S = dict(static)
    M = _assign(IA, IB, S)
    extra = {}
    for _ in range(4):
        newS, extra = {}, {}
        for (i, j), v in static.items():
            bonus = 0.0
            for (ni, mycol, theircol) in nbA[i]:
                nj = M.get(ni)
                if nj is None:
                    continue
                for (bj, bmy, btheir) in nbB[j]:
                    if bj == nj:
                        bonus += 18 + (4 if (mycol == bmy or theircol == btheir) else 0)
                        break
            bonus = min(bonus, 32)
            newS[(i, j)] = v + bonus
            if bonus:
                extra[(i, j)] = "joined to an already aligned table in the same way"
        S = newS
        M2 = _assign(IA, IB, S, frozenset(extra))
        if M2 == M:
            break
        M = M2
    pairs = []
    for i, j in sorted(M.items()):
        e = list(ev[(i, j)])
        if (i, j) in extra:
            e.append(extra[(i, j)])
        pairs.append(TablePair(IA[i], IB[j], S[(i, j)], e))
    return pairs, M


# ---------------------------------------------------------------------------------------- column alignment
def _combine(ws):
    p = 1.0
    for w in ws:
        p *= (1 - w)
    return round(min(0.99, 1 - p), 2)


def align_columns(tp, pairs_by_a, edges_a, edges_b):
    a, b = tp.a, tp.b
    cand = {}

    def add(ca, cb, w, basis):
        if ca in ("*", "") or cb in ("*", ""):
            return
        cand.setdefault((ca, cb), []).append((w, basis))

    for c in a.col_names & b.col_names:
        add(c, c, 0.9, "same column name")
    # same position in the join graph
    ea, eb = _edges_of(edges_a, a), _edges_of(edges_b, b)
    for e in ea:
        pa = e.other(a)
        mine = e.col_a if e.a is a else e.col_b
        pb = pairs_by_a.get(id(pa))
        if pb is None:
            continue
        for f in eb:
            if f.other(b) is pb.b:
                theirs = f.col_a if f.a is b else f.col_b
                add(mine, theirs, 0.88, "same join position")
    # output names
    oa = {o[0]: o[1] for o in a.outputs if o[0]}
    ob = {o[0]: o[1] for o in b.outputs if o[0]}
    for alias in set(oa) & set(ob):
        add(oa[alias], ob[alias], 0.85, f"same output name '{alias}'")
    # filter values
    for fa in a.filters:
        if not fa[2]:
            continue
        for fb in b.filters:
            if fb[2] and _jac(fa[2], fb[2]) >= 0.5:
                add(fa[0], fb[0], 0.8, "same filter values")
    # select position (weak)
    pa = {o[2]: o[1] for o in a.outputs if not o[0]}
    pb = {o[2]: o[1] for o in b.outputs if not o[0]}
    for pos in set(pa) & set(pb):
        add(pa[pos], pb[pos], 0.55, "same select position")
    # fuzzy names for what is still open
    covered_a = {k[0] for k in cand}
    covered_b = {k[1] for k in cand}
    for x in sorted(a.col_names - covered_a):
        for y in sorted(b.col_names - covered_b):
            sim = name_sim(x, y)
            if sim >= 0.6:
                add(x, y, round(0.3 + 0.4 * sim, 2), f"similar column name ({sim:.0%})")
    scored = sorted(((_combine([w for w, _ in v]), k, v) for k, v in cand.items()), key=lambda t: (-t[0], t[1]))
    used_a, used_b, out = set(), set(), []
    for conf, (ca, cb), v in scored:
        identity = ca == cb
        if ca in used_a or (cb in used_b and not identity):
            continue
        used_a.add(ca); used_b.add(cb)
        basis = "; ".join(dict.fromkeys(bs for _, bs in v))
        usage = _clauses_usage(a.cols.get(ca, set()) | b.cols.get(cb, set()))
        out.append(ColumnPair(tp, ca, cb, usage, conf, basis))
    lost = sorted((c for c in a.col_names - used_a if c != "*"))
    return out, lost, sorted(c for c in b.col_names - used_b if c != "*")


# ---------------------------------------------------------------------------------------- join comparison
def _etype(e):
    return e.join_type


def compare_joins(pairs, edges_a, edges_b, colmap):
    img = {id(tp.a): tp.b for tp in pairs}
    inv = {id(tp.b): tp.a for tp in pairs}
    rows, used_b = [], set()

    def key(e):
        return frozenset((id(e.a), id(e.b)))

    for e in edges_a:
        ia, ib = img.get(id(e.a)), img.get(id(e.b))
        a_text = f"{e.a.label}.{e.col_a} {e.op} {e.b.label}.{e.col_b}"
        if ia is None or ib is None:
            rows.append(JoinRow(a_text, "", e.join_type, "", "no counterpart in B",
                                "one of the joined tables has no aligned table in B"))
            continue
        matches = [f for f in edges_b if key(f) == frozenset((id(ia), id(ib)))]
        if not matches:
            rows.append(JoinRow(a_text, "", e.join_type, "", "no counterpart in B", "aligned tables are not joined in B"))
            continue
        # prefer an edge whose columns correspond
        def cols_for(f):
            # columns of f at ia/ib orientation
            return (f.col_a, f.col_b) if f.a is ia else (f.col_b, f.col_a)
        want = (colmap.get((id(e.a), e.col_a)), colmap.get((id(e.b), e.col_b)))
        pick = None
        for f in matches:
            if id(f) in used_b:
                continue
            if cols_for(f) == want:
                pick = f
                break
        if pick is None:
            free = [f for f in matches if id(f) not in used_b]
            pick = free[0] if free else matches[0]
        used_b.add(id(pick))
        b_text = f"{pick.a.label}.{pick.col_a} {pick.op} {pick.b.label}.{pick.col_b}"
        same_cols = cols_for(pick) == want
        same_type = e.join_type == pick.join_type
        status = "equivalent" if (same_cols and same_type) else ("join type differs" if same_cols else "different columns")
        note = ""
        if not same_type:
            note = f"{e.join_type} in A vs {pick.join_type} in B"
        rows.append(JoinRow(a_text, b_text, e.join_type, pick.join_type, status, note))
    for f in edges_b:
        if id(f) not in used_b:
            ia, ib = inv.get(id(f.a)), inv.get(id(f.b))
            b_text = f"{f.a.label}.{f.col_a} {f.op} {f.b.label}.{f.col_b}"
            rows.append(JoinRow("", b_text, "", f.join_type, "only in B",
                                "join exists in B only" if (ia and ib) else "involves a table that exists only in B"))
    return rows


# ---------------------------------------------------------------------------------------- notes
def _pattern_notes(IA, IB, pairs, M_unmatched_a, M_unmatched_b):
    notes = []
    img = {id(tp.a): tp.b for tp in pairs}

    def multi(I):
        d = {}
        for i in I:
            d.setdefault(i.key, []).append(i)
        return {k: v for k, v in d.items() if len(v) > 1}

    for k, insts in multi(IA).items():
        imgs = [img.get(id(i)) for i in insts if img.get(id(i)) is not None]
        jt = ", ".join(sorted({i.join_type for i in insts}))
        txt = f"A uses {insts[0].raw} {len(insts)}x ({jt})"
        if imgs:
            keys = {m.key for m in imgs}
            jtb = ", ".join(sorted({m.join_type for m in imgs}))
            if len(keys) > 1:
                txt += f"; B uses {len(keys)} different tables for those roles: " + ", ".join(sorted(m.raw for m in imgs)) + f" ({jtb})"
            else:
                txt += f"; B uses {imgs[0].raw} {len(imgs)}x ({jtb})"
        notes.append(txt)
    for k, insts in multi(IB).items():
        imgs = [tp.a for tp in pairs if tp.b in insts]
        if len({i.key for i in imgs}) > 1:
            notes.append(f"B uses {insts[0].raw} {len(insts)}x where A uses {len({i.key for i in imgs})} different tables: " +
                         ", ".join(sorted(i.raw for i in imgs)))
    for tp in pairs:
        if tp.a.join_type != tp.b.join_type:
            notes.append(f"{tp.a.raw}: {tp.a.join_type} in A, but {tp.b.raw}: {tp.b.join_type} in B")
        if tp.a.key == tp.b.key:
            continue
    for i in M_unmatched_a:
        notes.append(f"{i.raw} ({i.join_type}) appears only in A")
    for j in M_unmatched_b:
        notes.append(f"{j.raw} ({j.join_type}) appears only in B")
    return notes


# ---------------------------------------------------------------------------------------- entry point
def align(model_a, scopes_a, model_b, scopes_b):
    IA = list(model_a.select_instances(scopes_a))
    IB = list(model_b.select_instances(scopes_b))
    sa, sb = {id(i) for i in IA}, {id(i) for i in IB}
    edges_a = [e for e in model_a.edges if id(e.a) in sa and id(e.b) in sa]
    edges_b = [e for e in model_b.edges if id(e.a) in sb and id(e.b) in sb]
    pairs, M = align_instances(IA, IB, edges_a, edges_b)
    res = Alignment()
    by_a = {id(tp.a): tp for tp in pairs}
    colmap, lost_all = {}, []
    for tp in pairs:
        cps, lost_a, lost_b = align_columns(tp, by_a, edges_a, edges_b)
        res.columns.extend(cps)
        for cp in cps:
            colmap[(id(tp.a), cp.col_a)] = cp.col_b
        for c in lost_a:
            res.unmatched_cols.append((tp, "A", c))
        for c in lost_b:
            res.unmatched_cols.append((tp, "B", c))
    matched_a = {id(tp.a) for tp in pairs}
    matched_b = {id(tp.b) for tp in pairs}
    ua = [i for i in IA if id(i) not in matched_a]
    ub = [j for j in IB if id(j) not in matched_b]
    res.tables = sorted(pairs, key=lambda tp: (tp.a.stmt, tp.a.order, tp.a.id)) + \
        [TablePair(i, None) for i in ua] + [TablePair(None, j) for j in ub]
    res.joins = compare_joins(pairs, edges_a, edges_b, colmap)
    res.notes = _pattern_notes(IA, IB, pairs, ua, ub)
    return res
