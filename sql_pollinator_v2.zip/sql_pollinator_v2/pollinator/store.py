"""Excel persistence.  One workbook holds everything:

  Pods        pod registry
  Queries     pod | query_name | selection_reason_override | updated_at | sql | sql_2 ...   (edit freely in Excel too)
  Concepts    one row per cross-pollinated concept pair          \
  TableMap    table instance <-> table instance                    |  written by "Analyze"; the rows of a pod
  ColumnMap   column <-> column                                    |  pair are REPLACED on every re-analysis
  JoinMap     join edge <-> join edge                              |
  Unmatched   selection reasons that exist in only one pod         |
  Runs        when a pair was analysed + fingerprints of the queries /
  Overrides   manual table / column replacements (never overwritten by analysis)
"""
import hashlib
import os
import tempfile
import threading
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

CELL_LIMIT = 30000

SHEETS = {
    "Pods": ["pod", "created_at"],
    "Queries": ["pod", "query_name", "selection_reason_override", "updated_at", "sql"],
    "Concepts": ["concept_id", "pod_a", "pod_b", "selection_reason", "query_a", "query_b", "parse_a", "parse_b",
                 "tables_a", "tables_b", "tables_matched", "notes", "analysed_at"],
    "TableMap": ["concept_id", "pod_a", "pod_b", "selection_reason", "query_a", "query_b",
                 "table_a", "key_a", "alias_a", "join_type_a", "join_a", "cols_a", "root_a",
                 "table_b", "key_b", "alias_b", "join_type_b", "join_b", "cols_b", "root_b",
                 "confidence", "evidence"],
    "ColumnMap": ["concept_id", "pod_a", "pod_b", "selection_reason", "query_a", "query_b",
                  "table_a", "key_a", "column_a", "table_b", "key_b", "column_b", "usage", "confidence", "basis"],
    "JoinMap": ["concept_id", "pod_a", "pod_b", "selection_reason", "query_a", "query_b",
                "join_a", "type_a", "join_b", "type_b", "status", "note"],
    "Unmatched": ["pod_a", "pod_b", "pod", "query", "selection_reason", "status"],
    "Runs": ["pod_a", "pod_b", "analysed_at", "hash_a", "hash_b", "concepts", "warnings"],
    "Overrides": ["pod_from", "pod_to", "kind", "source_table", "source_column", "target_table", "target_column"],
}
PAIR_SHEETS = ["Concepts", "TableMap", "ColumnMap", "JoinMap", "Unmatched", "Runs"]


class StoreError(Exception):
    pass


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def norm_name(s):
    return str(s or "").strip().casefold()


def pair_key(a, b):
    return tuple(sorted((a, b), key=norm_name))


def fingerprint(queries):
    h = hashlib.sha1()
    for q in sorted(queries, key=lambda q: norm_name(q["query_name"])):
        h.update(norm_name(q["query_name"]).encode())
        h.update(b"\0")
        h.update(q["sql"].encode("utf-8", "replace"))
        h.update(b"\0")
        h.update(str(q.get("selection_reason_override", "")).encode())
    return h.hexdigest()[:12]


class Store:
    def __init__(self, path):
        self.path = os.path.abspath(path)
        self.lock = threading.RLock()
        if not os.path.exists(self.path):
            self._save(self._new_book())

    # ---- low level -----------------------------------------------------------------------------
    def _new_book(self):
        wb = Workbook()
        wb.remove(wb.active)
        for name, headers in SHEETS.items():
            self._init_sheet(wb.create_sheet(name), headers)
        return wb

    @staticmethod
    def _init_sheet(ws, headers):
        ws.append(headers)
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="305496")
        ws.freeze_panes = "A2"
        for i, h in enumerate(headers, 1):
            ws.column_dimensions[get_column_letter(i)].width = 60 if h.startswith("sql") else max(14, min(40, len(h) + 6))

    def _load(self):
        try:
            wb = load_workbook(self.path)
        except PermissionError:
            raise StoreError(f"Cannot open '{self.path}'. Close it in Excel and try again.")
        except Exception as e:
            raise StoreError(f"Cannot read '{self.path}': {e}")
        for name, headers in SHEETS.items():           # tolerate missing sheets (hand-edited workbooks)
            if name not in wb.sheetnames:
                self._init_sheet(wb.create_sheet(name), headers)
        return wb

    def _save(self, wb):
        d = os.path.dirname(self.path) or "."
        fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=d)
        os.close(fd)
        try:
            wb.save(tmp)
            os.replace(tmp, self.path)
        except PermissionError:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise StoreError(f"Cannot write '{self.path}'. Close it in Excel and try again.")
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    @staticmethod
    def _rows(ws):
        it = ws.iter_rows(values_only=True)
        try:
            headers = [str(h).strip() if h is not None else "" for h in next(it)]
        except StopIteration:
            return []
        out = []
        for r in it:
            if r is None or all(v is None or str(v).strip() == "" for v in r):
                continue
            out.append({h: ("" if v is None else v) for h, v in zip(headers, r) if h})
        return out

    @staticmethod
    def _write(ws, headers, rows):
        ws.delete_rows(1, ws.max_row + 1)
        ws.append(headers)
        for r in rows:
            ws.append([_cell(r.get(h, "")) for h in headers])
        Store._init_style(ws, headers)

    @staticmethod
    def _init_style(ws, headers):
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="305496")
        ws.freeze_panes = "A2"
        for i, h in enumerate(headers, 1):
            ws.column_dimensions[get_column_letter(i)].width = 60 if h.startswith("sql") else max(14, min(40, len(h) + 6))

    def read(self, sheet):
        with self.lock:
            wb = self._load()
            return self._rows(wb[sheet])

    # ---- pods ----------------------------------------------------------------------------------
    def pods(self):
        with self.lock:
            wb = self._load()
            names = {}
            for r in self._rows(wb["Pods"]):
                names.setdefault(norm_name(r["pod"]), str(r["pod"]).strip())
            for r in self._rows(wb["Queries"]):          # pods that only exist through the Queries sheet
                names.setdefault(norm_name(r["pod"]), str(r["pod"]).strip())
            return sorted(names.values(), key=norm_name)

    def add_pod(self, name):
        name = str(name or "").strip()
        if not name:
            raise StoreError("Pod name is required.")
        with self.lock:
            if norm_name(name) in {norm_name(p) for p in self.pods()}:
                raise StoreError(f"Pod '{name}' already exists.")
            wb = self._load()
            wb["Pods"].append([name, now()])
            self._save(wb)
        return name

    def delete_pod(self, name):
        with self.lock:
            wb = self._load()
            n = norm_name(name)
            self._filter(wb, "Pods", lambda r: norm_name(r["pod"]) != n)
            self._filter(wb, "Queries", lambda r: norm_name(r["pod"]) != n)
            for sh in PAIR_SHEETS:
                self._filter(wb, sh, lambda r: n not in (norm_name(r.get("pod_a")), norm_name(r.get("pod_b"))) and
                             norm_name(r.get("pod")) != n)
            self._filter(wb, "Overrides", lambda r: n not in (norm_name(r.get("pod_from")), norm_name(r.get("pod_to"))))
            self._save(wb)

    def rename_pod(self, old, new):
        new = str(new or "").strip()
        if not new:
            raise StoreError("New pod name is required.")
        with self.lock:
            others = {norm_name(p) for p in self.pods()} - {norm_name(old)}
            if norm_name(new) in others:
                raise StoreError(f"Pod '{new}' already exists.")
            wb = self._load()
            o = norm_name(old)
            for sh in ("Pods", "Queries"):
                self._update(wb, sh, lambda r: norm_name(r["pod"]) == o, {"pod": new})
            for sh in PAIR_SHEETS + ["Overrides"]:
                for col in ("pod_a", "pod_b", "pod", "pod_from", "pod_to"):
                    if col in SHEETS[sh]:
                        self._update(wb, sh, lambda r, col=col: norm_name(r.get(col)) == o, {col: new})
            self._save(wb)

    # ---- queries -------------------------------------------------------------------------------
    @staticmethod
    def _sql_of(row):
        parts = [str(row.get("sql", "") or "")]
        k = 2
        while f"sql_{k}" in row:
            parts.append(str(row.get(f"sql_{k}", "") or ""))
            k += 1
        return "".join(parts)

    def queries(self, pod=None):
        with self.lock:
            wb = self._load()
            out = []
            for r in self._rows(wb["Queries"]):
                if pod is not None and norm_name(r["pod"]) != norm_name(pod):
                    continue
                out.append({"pod": str(r["pod"]).strip(), "query_name": str(r["query_name"]).strip(),
                            "selection_reason_override": str(r.get("selection_reason_override", "") or ""),
                            "sql": self._sql_of(r), "updated_at": str(r.get("updated_at", ""))})
            return out

    def upsert_query(self, pod, name, sql, override="", old_name=None):
        pod, name = str(pod).strip(), str(name or "").strip()
        if not sql or not str(sql).strip():
            raise StoreError("The query is empty.")
        with self.lock:
            if norm_name(pod) not in {norm_name(p) for p in self.pods()}:
                raise StoreError(f"Unknown pod '{pod}'.")
            existing = {norm_name(q["query_name"]) for q in self.queries(pod)}
            if not name:
                k = len(existing) + 1
                while f"query_{k}" in existing:
                    k += 1
                name = f"query_{k}"
            self._store_query(pod, name, sql, override, old_name)
        return name

    def _store_query(self, pod, name, sql, override, old_name=None):
        wb = self._load()
        rows = self._rows(wb["Queries"])
        target = norm_name(old_name if old_name is not None else name)
        rows = [r for r in rows if not (norm_name(r["pod"]) == norm_name(pod) and norm_name(r["query_name"]) == target)]
        if old_name is not None and norm_name(old_name) != norm_name(name):
            if any(norm_name(r["pod"]) == norm_name(pod) and norm_name(r["query_name"]) == norm_name(name) for r in rows):
                raise StoreError(f"A query named '{name}' already exists in pod '{pod}'.")
        sql = str(sql).replace("\r\n", "\n")
        chunks = [sql[i:i + CELL_LIMIT] for i in range(0, len(sql), CELL_LIMIT)] or [""]
        new = {"pod": pod, "query_name": name, "selection_reason_override": override or "", "updated_at": now(),
               "sql": chunks[0]}
        for k, c in enumerate(chunks[1:], 2):
            new[f"sql_{k}"] = c
        rows.append(new)
        extra = max([int(h[4:]) for r in rows for h in r if h.startswith("sql_") and h[4:].isdigit()] or [1])
        headers = SHEETS["Queries"] + [f"sql_{k}" for k in range(2, extra + 1)]
        self._write(wb["Queries"], headers, rows)
        self._save(wb)

    def delete_query(self, pod, name):
        with self.lock:
            wb = self._load()
            self._filter(wb, "Queries", lambda r: not (norm_name(r["pod"]) == norm_name(pod) and
                                                       norm_name(r["query_name"]) == norm_name(name)))
            self._save(wb)

    # ---- analysis results ----------------------------------------------------------------------
    def replace_analysis(self, pod_a, pod_b, data):
        """data: {sheet: [rows]} for Concepts/TableMap/ColumnMap/JoinMap/Unmatched/Runs.  Old rows of the pair are dropped."""
        pk = tuple(norm_name(x) for x in pair_key(pod_a, pod_b))
        with self.lock:
            wb = self._load()
            for sh in PAIR_SHEETS:
                keep = [r for r in self._rows(wb[sh])
                        if tuple(sorted((norm_name(r.get("pod_a")), norm_name(r.get("pod_b"))))) != pk]
                self._write(wb[sh], SHEETS[sh], keep + data.get(sh, []))
            self._save(wb)

    def analysis(self, pod_a, pod_b):
        pk = tuple(sorted((norm_name(pod_a), norm_name(pod_b))))
        with self.lock:
            wb = self._load()
            out = {}
            for sh in PAIR_SHEETS:
                out[sh] = [r for r in self._rows(wb[sh])
                           if tuple(sorted((norm_name(r.get("pod_a")), norm_name(r.get("pod_b"))))) == pk]
            return out

    def runs(self):
        return self.read("Runs")

    # ---- overrides -----------------------------------------------------------------------------
    def add_override(self, row):
        with self.lock:
            wb = self._load()
            wb["Overrides"].append([str(row.get(h, "") or "").strip() for h in SHEETS["Overrides"]])
            self._save(wb)

    def delete_override(self, index):
        with self.lock:
            wb = self._load()
            ws = wb["Overrides"]
            if 0 <= index < ws.max_row - 1:
                ws.delete_rows(index + 2)
            self._save(wb)

    # ---- helpers -------------------------------------------------------------------------------
    def _filter(self, wb, sheet, keep):
        ws = wb[sheet]
        headers = [c.value for c in ws[1]]
        rows = [r for r in self._rows(ws) if keep(r)]
        self._write(ws, [h for h in headers if h], rows)

    def _update(self, wb, sheet, pred, changes):
        ws = wb[sheet]
        headers = [c.value for c in ws[1] if c.value]
        rows = self._rows(ws)
        for r in rows:
            if pred(r):
                r.update(changes)
        self._write(ws, headers, rows)


def _cell(v):
    if isinstance(v, (list, tuple, set)):
        v = ", ".join(map(str, v))
    if isinstance(v, str) and len(v) > CELL_LIMIT + 2000:
        v = v[:CELL_LIMIT + 2000]
    if isinstance(v, float):
        v = round(v, 3)
    return v
