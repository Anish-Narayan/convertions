"""Rule-based structural parser for Databricks / Spark SQL.

Goal: understand HOW a query works (tables, aliases, joins and their conditions, CTEs, sub-queries, set operations,
which column belongs to which table) - not to validate SQL.  It is deliberately lenient:

  * level 1  full recursive-descent structure parse of every statement
  * level 2  if a statement cannot be parsed (or tokens are left over) -> token based fallback extractor
             (tables after FROM/JOIN/INTO..., alias.column pairs, join conditions as text)
  * level 3  unknown statement kinds are kept verbatim, only their table mentions are listed
  Nothing in this module ever raises to the caller; problems become `warnings` on the statement / script.

Everything is case-insensitive (keys are lower-cased) while original text and token spans are preserved, so the
converter can edit the original SQL in place without touching formatting or comments.
"""
import re
from dataclasses import dataclass, field

from .tokenizer import tokenize, Tok, PLACEHOLDER_RE, unquote_string

FULL_PLACEHOLDER = re.compile(r"^(?:\$\([^()\n]+\)|\$\{[^{}\n]+\}|\{\{[^{}\n]+\}\})$")


class ParseError(Exception):
    pass


# ---------------------------------------------------------------------------------------- word sets
CLAUSE_STOP = {"FROM", "WHERE", "GROUP", "HAVING", "QUALIFY", "WINDOW", "ORDER", "LIMIT", "UNION", "INTERSECT",
               "EXCEPT", "MINUS", "JOIN", "INNER", "CROSS", "NATURAL", "ON", "USING", "LATERAL", "OFFSET", "FETCH",
               "CLUSTER", "DISTRIBUTE", "SORT", "SELECT"}
JOIN_WORDS_SOFT = {"LEFT", "RIGHT", "FULL", "OUTER", "SEMI", "ANTI"}      # stop an expression only after an operand
CONST_WORDS = {"NULL", "TRUE", "FALSE", "UNKNOWN", "CURRENT_DATE", "CURRENT_TIMESTAMP", "CURRENT_TIME",
               "CURRENT_USER", "CURRENT_CATALOG", "CURRENT_SCHEMA", "CURRENT_DATABASE", "SESSION_USER",
               "LOCALTIMESTAMP", "LOCALTIME", "SYSDATE"}
OPERATOR_WORDS = {"AND", "OR", "NOT", "XOR", "IN", "LIKE", "ILIKE", "RLIKE", "REGEXP", "BETWEEN", "IS", "DISTINCT",
                  "ESCAPE", "ANY", "ALL", "SOME", "EXISTS", "DIV", "SIMILAR", "TO"}
LENIENT_SKIP = {"ORDER", "BY", "ASC", "DESC", "NULLS", "FIRST", "LAST", "SEPARATOR", "FOR", "PLACING", "BOTH",
                "LEADING", "TRAILING", "USING", "IGNORE", "RESPECT", "WHERE", "FROM", "GROUP", "HAVING", "PARTITION",
                "ROWS", "RANGE", "GROUPS", "UNBOUNDED", "PRECEDING", "FOLLOWING", "CURRENT", "ROW", "EXCLUDE",
                "TIES", "NO", "OTHERS", "WITHIN", "FILTER", "OVER", "DISTINCT", "ALL"}
UNIT_WORDS = {"YEAR", "YEARS", "MONTH", "MONTHS", "DAY", "DAYS", "HOUR", "HOURS", "MINUTE", "MINUTES", "SECOND",
              "SECONDS", "WEEK", "WEEKS", "MILLISECOND", "MILLISECONDS", "MICROSECOND", "MICROSECONDS", "QUARTER",
              "DAYOFYEAR", "DOY", "YY", "YYYY", "MM", "DD", "MS", "MCS", "DECADE", "CENTURY", "DOW", "EPOCH"}
UNIT_FUNCS = {"DATEDIFF", "DATEADD", "TIMESTAMPADD", "TIMESTAMPDIFF", "DATE_DIFF", "DATE_ADD", "DATE_PART",
              "DATE_TRUNC", "TIMESTAMP_DIFF"}
TYPED_LITERALS = {"DATE", "TIMESTAMP", "TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIME", "X", "BINARY"}
CAST_FNS = {"CAST", "TRY_CAST"}
QUERY_START = {"SELECT", "WITH", "FROM", "VALUES", "TABLE"}
AFTER_TABLE_RESERVED = {"WHERE", "GROUP", "ORDER", "HAVING", "LIMIT", "UNION", "INTERSECT", "EXCEPT", "MINUS", "JOIN",
                        "INNER", "LEFT", "RIGHT", "FULL", "CROSS", "NATURAL", "OUTER", "SEMI", "ANTI", "ON", "USING",
                        "LATERAL", "WINDOW", "QUALIFY", "SORT", "CLUSTER", "DISTRIBUTE", "OFFSET", "FETCH",
                        "TABLESAMPLE", "PIVOT", "UNPIVOT", "WHEN", "THEN", "SET", "SELECT", "FROM", "VALUES", "WITH",
                        "VERSION", "TIMESTAMP", "INSERT", "UPDATE", "DELETE", "MERGE", "OPTIMIZE", "ZORDER", "AS"}
COMPARE_OPS = {"=", "==", "<=>", "!=", "<>", "<", ">", "<=", ">=", "!<", "!>"}
FLIP = {"<": ">", ">": "<", "<=": ">=", ">=": "<=", "!<": "!>", "!>": "!<"}
COND_WORDS = {"IN", "LIKE", "ILIKE", "RLIKE", "REGEXP", "BETWEEN", "IS"}


def _norm_part(s):
    return s.strip().lower()


# ---------------------------------------------------------------------------------------- model
class TableName:
    """A (possibly qualified) table name in the SQL text, with the exact token span."""

    def __init__(self, toks):
        self.toks = toks                                   # name part tokens (no dots)
        self.parts = [t.name if t.kind in ("QID", "DQ") else t.text for t in toks]
        self.start, self.end = toks[0].start, toks[-1].end
        self.first_idx, self.last_idx = toks[0].idx, toks[-1].idx

    @property
    def key(self):
        return ".".join(_norm_part(p) for p in self.parts)

    @property
    def name(self):
        return _norm_part(self.parts[-1])

    def raw(self, text):
        return text[self.start:self.end]


@dataclass(eq=False)
class ColRef:
    parts: list                    # tokens of the name chain (no dots)
    ti: int                        # first / last token index
    tj: int
    scope: object
    clause: str
    source: object = None
    name: str = ""                 # resolved column name (lower-case)
    name_tok: object = None        # the token carrying the column name (for in-place renaming)
    qualifier_toks: list = field(default_factory=list)
    status: str = "unresolved"     # resolved | derived | alias | ambiguous | unresolved | star
    candidates: list = field(default_factory=list)
    path: list = field(default_factory=list)
    item: object = None
    kind: str = "column"           # column | insert_target | assign_target | using

    def __repr__(self):
        return f"ColRef({'.'.join(t.text for t in self.parts)}, {self.status})"


@dataclass(eq=False)
class SelectItem:
    scope: object
    ti: int
    tj: int
    alias: str = ""
    alias_tok: object = None
    refs: list = field(default_factory=list)
    is_star: bool = False
    star_qual: str = ""
    strings: list = field(default_factory=list)       # [(value, tok)]
    simple_ref: object = None                          # item is exactly one column reference
    out_name: str = ""
    position: int = 0


@dataclass(eq=False)
class Cond:
    kind: str                       # join | filter | in_subquery | complex
    scope: object
    clause: str
    source: object = None           # for ON conditions: the joined source
    left: object = None
    right: object = None
    op: str = ""
    values: list = field(default_factory=list)
    wrapped: bool = False
    refs: list = field(default_factory=list)
    subquery: object = None
    ti: int = 0
    tj: int = 0


@dataclass(eq=False)
class Source:
    id: int
    kind: str                       # table | derived | cte | internal | function | values | lateral_view
    scope: object
    alias: str = ""
    alias_tok: object = None
    table: TableName = None
    query: object = None
    join_type: str = "FROM"
    join_ti: int = -1
    on_range: tuple = None
    using: list = field(default_factory=list)
    col_aliases: list = field(default_factory=list)
    func_name: str = ""
    created_by: int = None
    lateral: bool = False
    role: str = "read"
    order: int = 0
    stmt: int = 0

    @property
    def display_name(self):
        return (self.alias or (self.table.parts[-1] if self.table else "") or self.func_name or "").lower()

    @property
    def is_physical(self):
        return self.kind == "table"


class Scope:
    """One SELECT block (or VALUES / DML context)."""

    def __init__(self, sid, query):
        self.id = sid
        self.query = query
        self.sources = []
        self.refs = []
        self.items = []
        self.conds = []
        self.children = []          # QueryNodes of sub-queries found in expressions
        self.stars = []
        self.kind = "select"
        self.values_rows = []
        self.flags = set()          # e.g. 'pivot', 'lateral_view', 'using_join'
        self.stmt = 0

    @property
    def parent_scope(self):
        return self.query.parent_scope if self.query is not None else None

    def first_leaf(self):
        return self


class QueryNode:
    def __init__(self, qid, kind, name="", parent_scope=None):
        self.id = qid
        self.kind = kind            # root | cte | subquery | derived | paren
        self.name = name
        self.parent_scope = parent_scope
        self.ctes = []              # QueryNodes of kind 'cte'
        self.branches = []          # Scope | QueryNode
        self.setops = []
        self.recursive = False
        self.owner = None           # for ctes: the QueryNode that defines them
        self.cte_index = 0
        self.col_aliases = []
        self.stmt = 0
        self.ti = self.tj = 0

    def first_leaf(self):
        b = self.branches[0] if self.branches else None
        return b.first_leaf() if b is not None else None

    def leaves(self):
        out = []
        for b in self.branches:
            out.extend(b.leaves() if isinstance(b, QueryNode) else [b])
        return out

    def output_items(self):
        leaf = self.first_leaf()
        return leaf.items if leaf is not None else []

    def outputs(self):
        """(names, has_star): output column names in order (lower-case; '' when unnamed)."""
        if self.col_aliases:
            return [c.lower() for c in self.col_aliases], False
        leaf = self.first_leaf()
        if leaf is None:
            return [], True
        if leaf.kind == "values":
            return [], True
        names, star = [], False
        for it in leaf.items:
            if it.is_star:
                star = True
            names.append(it.out_name)
        return names, star


@dataclass(eq=False)
class Statement:
    index: int
    kind: str                       # SELECT CREATE INSERT MERGE UPDATE DELETE SET DECLARE DROP OTHER
    ti: int
    tj: int
    text: str = ""
    mode: str = "full"              # full | fallback | skipped
    root: object = None             # QueryNode (query body) when any
    scopes: list = field(default_factory=list)       # every Scope in the statement
    queries: list = field(default_factory=list)      # every QueryNode
    target: TableName = None        # CREATE / INSERT / MERGE / UPDATE / DELETE target
    target_role: str = ""
    target_columns: list = field(default_factory=list)   # tokens of explicit column list (INSERT/CREATE)
    created_key: str = ""
    created_columns: list = field(default_factory=list)
    var_name: str = ""
    var_strings: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    sources: list = field(default_factory=list)      # every Source


@dataclass(eq=False)
class Script:
    text: str
    toks: list
    comments: list
    statements: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    internal_defs: dict = field(default_factory=dict)       # key -> [(QueryNode, [colnames] or None)]

    @property
    def modes(self):
        return {s.mode for s in self.statements}

    def all_scopes(self):
        return [sc for st in self.statements for sc in st.scopes]

    def all_sources(self):
        return [s for st in self.statements for s in st.sources]


# ---------------------------------------------------------------------------------------- parser
class _Expr:
    __slots__ = ("ti", "tj", "refs", "strings", "alias", "alias_tok", "star", "star_qual", "stars")

    def __init__(self, ti):
        self.ti, self.tj = ti, ti
        self.refs, self.strings, self.alias, self.alias_tok = [], [], "", None
        self.star, self.star_qual = False, ""


class _Parser:
    def __init__(self, script, stmt):
        self.script, self.text = script, script.text
        self.toks = script.toks
        self.stmt = stmt
        self.i = stmt.ti
        self.end = stmt.tj                       # exclusive
        self.ref_at, self.subq_at = {}, {}
        self._sid = 0
        self.eof = script.toks[-1]

    # ---- token helpers ------------------------------------------------------------------------
    def peek(self, k=0):
        j = self.i + k
        return self.toks[j] if j < self.end else self.eof

    def next(self):
        t = self.peek()
        if t.kind != "EOF":
            self.i += 1
        return t

    def at_word(self, *w, k=0):
        t = self.peek(k)
        return t.kind == "ID" and t.text.upper() in w

    def at_punct(self, c, k=0):
        t = self.peek(k)
        return t.kind == "PUNCT" and t.text == c

    def at_op(self, c, k=0):
        t = self.peek(k)
        return t.kind == "OP" and t.text == c

    def accept_word(self, *w):
        if self.at_word(*w):
            return self.next()
        return None

    def expect_punct(self, c):
        if not self.at_punct(c):
            raise ParseError(f"expected '{c}' near {self._near()}")
        return self.next()

    def expect_word(self, *w):
        if not self.at_word(*w):
            raise ParseError(f"expected {'/'.join(w)} near {self._near()}")
        return self.next()

    def _near(self):
        t = self.peek()
        ctx = self.text[max(0, t.start - 25):t.end + 25].replace("\n", " ")
        return f"'{t.text}' (...{ctx}...)"

    def skip_balanced(self):
        """At '(' -> consume through the matching ')'."""
        self.expect_punct("(")
        d = 1
        while d and self.peek().kind != "EOF":
            t = self.next()
            if t.kind == "PUNCT":
                d += (t.text == "(") - (t.text == ")")
        if d:
            raise ParseError("unbalanced parentheses")

    def new_query(self, kind, name="", parent_scope=None):
        self._sid += 1
        q = QueryNode((self.stmt.index, self._sid), kind, name, parent_scope)
        q.stmt = self.stmt.index
        q.ti = self.i
        self.stmt.queries.append(q)
        return q

    def new_scope(self, q, kind="select"):
        self._sid += 1
        sc = Scope((self.stmt.index, self._sid), q)
        sc.kind = kind
        sc.stmt = self.stmt.index
        self.stmt.scopes.append(sc)
        return sc

    def new_source(self, scope, kind, **kw):
        self._sid += 1
        s = Source(id=(self.stmt.index, self._sid), kind=kind, scope=scope, order=len(scope.sources),
                   stmt=self.stmt.index, **kw)
        scope.sources.append(s)
        self.stmt.sources.append(s)
        return s

    # ---- names --------------------------------------------------------------------------------
    def name_chain(self, allow_star=False):
        """ID (. ID)* -> list of tokens (without the dots)."""
        t = self.peek()
        if t.kind not in ("ID", "QID", "DQ"):
            raise ParseError(f"expected a name near {self._near()}")
        toks = [self.next()]
        while self.at_punct(".") and self.peek(1).kind in ("ID", "QID", "DQ") or \
                (allow_star and self.at_punct(".") and self.at_op("*", 1)):
            self.next()
            toks.append(self.next())
        return toks

    # ---- query --------------------------------------------------------------------------------
    def parse_query(self, kind="subquery", name="", parent_scope=None):
        q = self.new_query(kind, name, parent_scope)
        if self.at_word("WITH"):
            self.next()
            if self.accept_word("RECURSIVE"):
                q.recursive = True
            while True:
                nt = self.next()
                if nt.kind not in ("ID", "QID", "DQ"):
                    raise ParseError(f"bad CTE name near {self._near()}")
                cols = []
                if self.at_punct("("):
                    self.next()
                    while not self.at_punct(")"):
                        t = self.next()
                        if t.kind == "EOF":
                            raise ParseError("unterminated CTE column list")
                        if not (t.kind == "PUNCT" and t.text == ","):
                            cols.append(t.name)
                    self.next()
                self.expect_word("AS")
                self.accept_word("NOT")
                self.accept_word("MATERIALIZED")
                self.expect_punct("(")
                cte = self.parse_query("cte", nt.name, parent_scope)
                cte.owner, cte.cte_index, cte.col_aliases = q, len(q.ctes), cols
                self.expect_punct(")")
                cte.tj = self.i
                q.ctes.append(cte)
                if self.at_punct(","):
                    self.next()
                    continue
                break
        self.parse_query_body(q)
        q.tj = self.i
        return q

    def parse_query_body(self, q):
        q.branches.append(self.parse_term(q))
        while self.at_word("UNION", "INTERSECT", "EXCEPT", "MINUS"):
            op = self.next().text.upper()
            if self.accept_word("ALL"):
                op += " ALL"
            else:
                self.accept_word("DISTINCT")
            if self.at_word("BY") or (self.at_word("BY") and self.at_word("NAME", k=1)):
                self.next()
                self.accept_word("NAME")
            q.setops.append(op)
            q.branches.append(self.parse_term(q))
        self.parse_trailing(q)

    def parse_trailing(self, q):
        leaf = q.first_leaf()
        while True:
            if self.at_word("ORDER", "SORT", "CLUSTER", "DISTRIBUTE") and self.at_word("BY", k=1):
                self.next(); self.next()
                self.scan_list(leaf, "order")
            elif self.at_word("LIMIT", "OFFSET"):
                self.next()
                self.accept_word("ALL")
                self.scan_expr(leaf, "limit")
            elif self.at_word("FETCH"):
                self.next()
                while self.peek().kind != "EOF" and not self.at_punct(")") and not self.at_punct(";") \
                        and not self.at_word("UNION", "INTERSECT", "EXCEPT", "MINUS"):
                    self.next()
            else:
                break

    def scan_list(self, scope, clause, **kw):
        out = []
        while True:
            e = self.scan_expr(scope, clause, **kw)
            out.append(e)
            if self.at_punct(","):
                self.next()
                continue
            break
        return out

    def parse_term(self, q):
        t = self.peek()
        if t.kind == "PUNCT" and t.text == "(":
            self.next()
            sub = self.parse_query("paren", "", q.parent_scope)
            sub.owner = None
            self.expect_punct(")")
            return sub
        if self.at_word("VALUES"):
            return self.parse_values(q)
        if self.at_word("TABLE") and self.peek(1).kind in ("ID", "QID", "DQ"):
            self.next()
            sc = self.new_scope(q, "table")
            toks = self.name_chain()
            self.new_source(sc, "table", table=TableName(toks))
            return sc
        if self.at_word("SELECT", "FROM"):
            return self.parse_select_core(q)
        raise ParseError(f"expected SELECT near {self._near()}")

    def parse_values(self, q):
        self.expect_word("VALUES")
        sc = self.new_scope(q, "values")
        while True:
            row = []
            if self.at_punct("("):
                self.next()
                row = self.scan_list(sc, "values", lenient=True)
                self.expect_punct(")")
            else:
                row = [self.scan_expr(sc, "values")]
            sc.values_rows.append(row)
            if self.at_punct(","):
                self.next()
                continue
            break
        # items = first row (so positional lookups such as selection reasons work)
        for k, e in enumerate(sc.values_rows[0] if sc.values_rows else []):
            it = SelectItem(sc, e.ti, e.tj, refs=e.refs, strings=e.strings, position=k)
            sc.items.append(it)
        return sc

    def parse_select_core(self, q):
        sc = self.new_scope(q)
        if self.at_word("FROM"):                       # FROM t SELECT ...   (Databricks pipe-less variant)
            self.next()
            self.parse_from(sc)
            if not self.at_word("SELECT"):
                sc.items = []
                sc.stars.append(("", None))
                return sc
        self.expect_word("SELECT")
        if self.at_word("DISTINCT", "ALL"):
            self.next()
        if self.at_word("TOP") and self.peek(1).kind == "NUM":
            self.next(); self.next()
        # select list
        while True:
            if self.at_word("FROM") or self.peek().kind == "EOF" or self.at_punct(")"):
                break
            self.parse_select_item(sc)
            if self.at_punct(","):
                self.next()
                continue
            break
        if self.at_word("FROM"):
            self.next()
            self.parse_from(sc)
        if self.at_word("WHERE"):
            self.next()
            e = self.scan_expr(sc, "where")
            self.classify(sc, e.ti, e.tj, "where")
        if self.at_word("GROUP") and self.at_word("BY", k=1):
            self.next(); self.next()
            self.accept_word("ALL")
            self.scan_list(sc, "group")
            if self.at_word("WITH") and self.at_word("ROLLUP", "CUBE", k=1):
                self.next(); self.next()
        if self.at_word("HAVING"):
            self.next()
            e = self.scan_expr(sc, "having")
            self.classify(sc, e.ti, e.tj, "having")
        if self.at_word("QUALIFY"):
            self.next()
            e = self.scan_expr(sc, "qualify")
            self.classify(sc, e.ti, e.tj, "qualify")
        while self.at_word("WINDOW"):
            self.next()
            while True:
                self.next()                                  # window name
                self.expect_word("AS")
                self.expect_punct("(")
                self.scan_list(sc, "window", lenient=True, window=True)
                self.expect_punct(")")
                if self.at_punct(","):
                    self.next(); continue
                break
        return sc

    def parse_select_item(self, sc):
        e = self.scan_expr(sc, "select", allow_alias=True)
        it = SelectItem(sc, e.ti, e.tj, alias=e.alias, alias_tok=e.alias_tok, refs=e.refs, is_star=e.star,
                        star_qual=e.star_qual, strings=e.strings, position=len(sc.items))
        if e.tj - e.ti >= 1:
            # simple column: exactly one ref covering the whole expression (ignoring the alias tokens)
            end = it.tj
            if e.alias_tok is not None:
                end = e.alias_tok.idx
                while end > e.ti and self.toks[end - 1].is_word("AS"):
                    end -= 1
            if len(e.refs) == 1 and e.refs[0].ti == e.ti and e.refs[0].tj + 1 == end and not e.star:
                it.simple_ref = e.refs[0]
                e.refs[0].item = it
        if it.alias:
            it.out_name = it.alias.lower()
        elif it.simple_ref is not None:
            it.out_name = it.simple_ref.parts[-1].name.lower() if it.simple_ref.parts else ""
        sc.items.append(it)
        for r in e.refs:
            r.item = r.item or it
        return it

    # ---- FROM ---------------------------------------------------------------------------------
    def parse_from(self, sc):
        first = True
        while True:
            self.parse_factor(sc, "FROM" if first else "COMMA", self.i)
            first = False
            while True:
                if self.at_word("LATERAL") and self.at_word("VIEW", k=1):
                    self.parse_lateral_view(sc)
                    continue
                if self.at_punct(","):
                    break
                jt = self.try_join_type()
                if jt is None:
                    break
                jti = self.i - 1
                src = self.parse_factor(sc, jt, jti)
                if self.at_word("ON"):
                    self.next()
                    e = self.scan_expr(sc, "on")
                    src.on_range = (e.ti, e.tj)
                    self.classify(sc, e.ti, e.tj, "on", src)
                elif self.at_word("USING") and self.at_punct("(", k=1):
                    self.next(); self.next()
                    while not self.at_punct(")"):
                        t = self.next()
                        if t.kind == "EOF":
                            raise ParseError("unterminated USING list")
                        if t.kind != "PUNCT":
                            src.using.append(t)
                    self.next()
                    sc.flags.add("using_join")
            if self.at_punct(","):
                self.next()
                continue
            break

    def try_join_type(self):
        """If positioned at a join keyword sequence, consume through JOIN and return the normalised type."""
        j, words = 0, []
        while self.peek(j).kind == "ID" and self.peek(j).text.upper() in (
                "NATURAL", "INNER", "CROSS", "LEFT", "RIGHT", "FULL", "OUTER", "SEMI", "ANTI", "JOIN", "STRAIGHT_JOIN"):
            w = self.peek(j).text.upper()
            words.append(w)
            j += 1
            if w in ("JOIN", "STRAIGHT_JOIN"):
                break
        if not words or words[-1] not in ("JOIN", "STRAIGHT_JOIN"):
            return None
        for _ in range(j):
            self.next()
        words = [w for w in words if w not in ("JOIN", "STRAIGHT_JOIN", "OUTER")]
        nat = "NATURAL " if "NATURAL" in words else ""
        words = [w for w in words if w != "NATURAL"]
        if "SEMI" in words and not any(w in ("LEFT", "RIGHT") for w in words):
            words.insert(0, "LEFT")
        if "ANTI" in words and not any(w in ("LEFT", "RIGHT") for w in words):
            words.insert(0, "LEFT")
        return nat + (" ".join(words) if words else "INNER")

    def parse_lateral_view(self, sc):
        start = self.i
        self.next(); self.next()
        self.accept_word("OUTER")
        fn = self.name_chain()
        self.expect_punct("(")
        self.scan_list(sc, "from", lenient=True)
        self.expect_punct(")")
        alias, cols = "", []
        if self.peek().kind in ("ID", "QID") and not self.at_word("AS", "LATERAL", "WHERE", "GROUP", "ORDER", "LIMIT",
                                                                    "JOIN", "LEFT", "INNER", "CROSS", "UNION", "ON"):
            alias = self.next().name
        if self.accept_word("AS"):
            pass
        while self.peek().kind in ("ID", "QID") and not self.at_word(*AFTER_TABLE_RESERVED):
            cols.append(self.next().name)
            if self.at_punct(","):
                self.next()
            else:
                break
        src = self.new_source(sc, "lateral_view", alias=alias, func_name=fn[-1].text, col_aliases=cols,
                              join_type="LATERAL VIEW", join_ti=start)
        sc.flags.add("lateral_view")
        return src

    def parse_factor(self, sc, join_type, join_ti):
        t = self.peek()
        lateral = False
        if self.at_word("LATERAL") and not self.at_word("VIEW", k=1):
            self.next()
            lateral = True
            t = self.peek()
        src = None
        if t.kind == "PUNCT" and t.text == "(":
            if self.at_word(*QUERY_START, k=1) or (self.peek(1).kind == "PUNCT" and self.peek(1).text == "("
                                                    and self._paren_starts_query()):
                self.next()
                q = self.parse_query("derived", "", sc)
                self.expect_punct(")")
                src = self.new_source(sc, "derived", query=q, join_type=join_type, join_ti=join_ti, lateral=lateral)
            else:                                           # (a JOIN b ON ...)  parenthesised join tree
                self.next()
                self.parse_from(sc)
                self.expect_punct(")")
                self.skip_table_alias(None)
                return sc.sources[-1] if sc.sources else None
        elif self.at_word("VALUES"):
            q = self.new_query("derived", "", sc)
            q.branches.append(self.parse_values(q))
            q.tj = self.i
            src = self.new_source(sc, "values", query=q, join_type=join_type, join_ti=join_ti)
        elif self.at_word("TABLE") and self.at_punct("(", k=1):
            self.next(); self.next()
            self.scan_list(sc, "from", lenient=True)
            self.expect_punct(")")
            src = self.new_source(sc, "function", func_name="table", join_type=join_type, join_ti=join_ti)
        elif self.at_word("IDENTIFIER") and self.at_punct("(", k=1):
            self.next(); self.skip_balanced()
            src = self.new_source(sc, "function", func_name="identifier", join_type=join_type, join_ti=join_ti)
        else:
            toks = self.name_chain()
            if self.at_punct("("):                          # table-valued function
                self.next()
                self.scan_list(sc, "from", lenient=True) if not self.at_punct(")") else None
                self.expect_punct(")")
                src = self.new_source(sc, "function", func_name=".".join(x.text for x in toks),
                                      join_type=join_type, join_ti=join_ti)
            else:
                tn = TableName(toks)
                src = self.new_source(sc, "table", table=tn, join_type=join_type, join_ti=join_ti)
                self.skip_table_modifiers(sc)
        src.lateral = lateral
        self.skip_table_alias(src)
        # PIVOT / UNPIVOT (...) [alias]
        while self.at_word("PIVOT", "UNPIVOT") and self.at_punct("(", k=1):
            self.next()
            self.skip_balanced()
            sc.flags.add("pivot")
            self.skip_table_alias(src)
        return src

    def _paren_starts_query(self):
        k = 1
        while self.peek(k).kind == "PUNCT" and self.peek(k).text == "(":
            k += 1
        return self.at_word(*QUERY_START, k=k)

    def skip_table_modifiers(self, sc):
        while True:
            if self.at_word("VERSION", "TIMESTAMP") and self.at_word("AS", k=1) and self.at_word("OF", k=2):
                self.next(); self.next(); self.next()
                t = self.peek()
                if t.kind in ("STR", "NUM", "DQ"):
                    self.next()
                elif t.kind == "PUNCT" and t.text == "(":
                    self.skip_balanced()
                elif t.kind == "ID":
                    self.next()
                    if self.at_punct("("):
                        self.skip_balanced()
            elif self.at_word("TABLESAMPLE") and self.at_punct("(", k=1):
                self.next(); self.skip_balanced()
                if self.at_word("REPEATABLE"):
                    self.next(); self.skip_balanced()
            elif self.at_punct("@") and self.peek(1).kind in ("ID", "NUM"):
                self.next(); self.next()
            elif self.at_word("OPTIONS") and self.at_punct("(", k=1):
                self.next(); self.skip_balanced()
            else:
                break

    def skip_table_alias(self, src):
        alias_tok = None
        if self.at_word("AS") and self.peek(1).kind in ("ID", "QID", "DQ") and not self.at_word("OF", k=1):
            self.next()
            alias_tok = self.next()
        elif self.peek().kind in ("ID", "QID", "DQ") and not (self.peek().kind == "ID" and
                                                              self.peek().text.upper() in AFTER_TABLE_RESERVED):
            alias_tok = self.next()
        if alias_tok is None:
            return
        cols = []
        if self.at_punct("("):                               # t(a, b)
            self.next()
            while not self.at_punct(")"):
                t = self.next()
                if t.kind == "EOF":
                    raise ParseError("unterminated alias column list")
                if t.kind not in ("PUNCT",):
                    cols.append(t.name)
            self.next()
        if src is not None:
            src.alias, src.alias_tok, src.col_aliases = alias_tok.name, alias_tok, cols

    # ---- expressions --------------------------------------------------------------------------
    def make_ref(self, scope, clause, parts, lam):
        first = parts[0]
        if len(parts) == 1:
            if first.kind == "ID" and (FULL_PLACEHOLDER.match(first.text) or first.text.upper() in CONST_WORDS):
                return None
            if first.kind == "ID" and first.text.lower() in lam:
                return None
        elif first.kind == "ID" and first.text.lower() in lam and len(parts) >= 2:
            return None                                       # lambda_param.field
        ref = ColRef(parts=parts, ti=parts[0].idx, tj=parts[-1].idx, scope=scope, clause=clause)
        scope.refs.append(ref)
        self.ref_at[ref.ti] = ref
        return ref

    def skip_type(self):
        """After '::' or CAST ... AS : consume a data type."""
        t = self.peek()
        if t.kind not in ("ID", "QID"):
            return
        self.next()
        while self.peek().kind == "ID" and self.peek().text.upper() in ("PRECISION", "VARYING", "WITH", "WITHOUT",
                                                                          "TIME", "ZONE", "LOCAL"):
            self.next()
        if self.at_punct("("):
            self.skip_balanced()
        if self.at_op("<") or self.at_op("<<"):
            d = 0
            while True:
                t = self.next()
                if t.kind == "EOF":
                    break
                if t.kind == "OP":
                    d += t.text.count("<") - t.text.count(">")
                if d <= 0:
                    break
        while self.at_punct("[") and self.at_punct("]", k=1):
            self.next(); self.next()

    def scan_expr(self, scope, clause, lenient=False, allow_alias=False, window=False, fn="", lam=None, first_arg=False):
        e = _Expr(self.i)
        lam = lam if lam is not None else set()
        expect_operand, case_depth = True, 0
        prev = self.toks[self.i - 1] if self.i > 0 else None
        in_distinct_from = False
        while True:
            t = self.peek()
            pos = self.i
            k = t.kind
            if k == "EOF":
                break
            if k == "PUNCT":
                c = t.text
                if c in (")", ";", ","):
                    break
                if c == "(":
                    self.paren(scope, clause, e, lam, window, expect_operand)
                    expect_operand = False
                elif c == "[":
                    self.next()
                    if not self.at_punct("]"):
                        self.scan_list(scope, clause, lenient=True, lam=lam)
                    self.expect_punct("]")
                    expect_operand = False
                elif c == ".":
                    self.next()
                    if self.peek().kind in ("ID", "QID", "DQ") or self.at_op("*"):
                        self.next()
                    expect_operand = False
                elif c == ":":
                    nxt = self.peek(1)
                    if not expect_operand and nxt.kind in ("ID", "QID", "STR") and nxt.start == t.end:
                        self.next()                                      # json path  col:a.b['c']
                        while True:
                            n2 = self.peek()
                            if n2.kind in ("ID", "QID", "STR") and n2.start == self.toks[self.i - 1].end:
                                self.next()
                            elif n2.kind == "PUNCT" and n2.text == "." and n2.start == self.toks[self.i - 1].end:
                                self.next()
                            elif n2.kind == "PUNCT" and n2.text == "[" and n2.start == self.toks[self.i - 1].end:
                                self.next()
                                self.scan_list(scope, clause, lenient=True, lam=lam)
                                self.expect_punct("]")
                            else:
                                break
                    else:
                        self.next()                                      # :param
                        if self.peek().kind in ("ID", "NUM", "QID"):
                            self.next()
                    expect_operand = False
                elif c == "{":
                    while self.peek().kind != "EOF" and not self.at_punct("}"):
                        self.next()
                    self.next()
                    expect_operand = False
                else:                                                     # '?' '@' '}' ']'
                    if c == "]":
                        break
                    self.next()
                    expect_operand = c != "?"
            elif k in ("STR", "DQ"):
                e.strings.append((unquote_string(t.text) if k == "STR" else t.name, t))
                self.next()
                expect_operand = False
            elif k == "NUM":
                self.next()
                expect_operand = False
            elif k == "OP":
                op = t.text
                if op == "*" and expect_operand:
                    self.next()
                    e.star, e.star_qual = True, ""
                    scope.stars.append(("", t))
                    expect_operand = False
                    if (self.at_word("EXCEPT") and self.at_punct("(", k=1)) or \
                            (self.at_word("EXCLUDE") and self.at_punct("(", k=1)):
                        self.next(); self.skip_balanced()
                elif op == "::":
                    self.next()
                    self.skip_type()
                    expect_operand = False
                else:
                    self.next()
                    expect_operand = True
            elif k == "QID" or k == "ID":
                up = t.text.upper() if k == "ID" else ""
                # ---- terminators -----------------------------------------------------------
                if k == "ID" and not lenient:
                    if up in CLAUSE_STOP and not (up == "EXCEPT" and e.star and self.at_punct("(", k=1)):
                        if not (up == "FROM" and in_distinct_from):
                            break
                    if up in JOIN_WORDS_SOFT and not expect_operand and not self.at_punct("(", k=1):
                        break
                    if case_depth == 0 and up in ("WHEN", "THEN", "ELSE", "END") :
                        break
                if k == "ID" and lenient and up in ("SELECT", "WITH") and expect_operand:
                    self.subquery_in_parens_missing()
                # ---- special words ---------------------------------------------------------
                if k == "ID" and up == "CASE":
                    case_depth += 1; self.next(); expect_operand = True; prev = t; continue
                if k == "ID" and up in ("WHEN", "THEN", "ELSE"):
                    self.next(); expect_operand = True; prev = t; continue
                if k == "ID" and up == "END":
                    case_depth = max(0, case_depth - 1); self.next(); expect_operand = False; prev = t; continue
                if k == "ID" and up == "AS":
                    self.next()
                    if allow_alias and case_depth == 0:
                        a = self.peek()
                        if a.kind in ("ID", "QID", "DQ", "STR"):
                            self.next()
                            e.alias, e.alias_tok = a.name if a.kind != "STR" else unquote_string(a.text), a
                        elif a.kind == "PUNCT" and a.text == "(":
                            self.skip_balanced()                         # explode(x) AS (k, v)
                    elif fn in CAST_FNS:
                        self.skip_type()
                    expect_operand = False
                    prev = t
                    continue
                if k == "ID" and up == "INTERVAL" and not self.at_punct("(", k=1):
                    self.next()
                    if self.at_op("-") or self.at_op("+"):
                        self.next()
                    nt = self.peek()
                    if nt.kind in ("STR", "NUM"):
                        self.next()
                    elif nt.kind == "ID" and FULL_PLACEHOLDER.match(nt.text):
                        self.next()
                    elif nt.kind == "PUNCT" and nt.text == "(":
                        self.paren(scope, clause, e, lam, window, True)
                    while self.peek().kind == "ID" and (self.peek().text.upper() in UNIT_WORDS or
                                                        (self.peek().text.upper() == "TO" and
                                                         self.peek(1).text.upper() in UNIT_WORDS)):
                        self.next()
                    expect_operand = False
                    prev = t
                    continue
                if k == "ID" and up in TYPED_LITERALS and self.peek(1).kind == "STR":
                    self.next(); s = self.next()
                    e.strings.append((unquote_string(s.text), s))
                    expect_operand = False; prev = t
                    continue
                if k == "ID" and up == "COLLATE":
                    self.next()
                    if self.peek().kind in ("ID", "QID"):
                        self.next()
                    prev = t
                    continue
                if k == "ID" and up == "NULLS" and self.at_word("FIRST", "LAST", k=1):
                    self.next(); self.next(); prev = t
                    continue
                if k == "ID" and up == "GROUPING" and self.at_word("SETS", k=1):
                    self.next(); self.next(); expect_operand = True; prev = t
                    continue
                if k == "ID" and up in ("ASC", "DESC") and not expect_operand:
                    self.next(); prev = t
                    continue
                if k == "ID" and up == "DISTINCT" and self.at_word("FROM", k=1):
                    in_distinct_from = True
                if k == "ID" and up == "FROM" and in_distinct_from:
                    in_distinct_from = False
                    self.next(); expect_operand = True; prev = t
                    continue
                if k == "ID" and up in OPERATOR_WORDS:
                    self.next()                      # EXISTS( / ANY( etc. continue into the paren handler
                    expect_operand = True
                    prev = t
                    continue
                if lenient and k == "ID" and up in LENIENT_SKIP and not self.at_punct("(", k=1):
                    # window / aggregate ordering keywords inside parentheses
                    self.next()
                    expect_operand = up not in ("PRECEDING", "FOLLOWING", "ROW", "ROWS", "RANGE")
                    prev = t
                    continue
                # ---- operand position: name chain ----------------------------------------
                if expect_operand:
                    # lambda  x -> expr
                    if self.peek(1).kind == "OP" and self.peek(1).text == "->" and k == "ID":
                        lam.add(t.text.lower())
                        self.next(); self.next()
                        expect_operand = True; prev = t
                        continue
                    if self.peek(1).kind == "OP" and self.peek(1).text == "=>" and k == "ID":
                        self.next(); self.next()                          # named argument  f(arg => 1)
                        expect_operand = True; prev = t
                        continue
                    parts = self.name_chain(allow_star=True)
                    star_tail = False
                    if self.at_punct(".") and self.at_op("*", 1):
                        self.next(); self.next(); star_tail = True
                    if parts[-1].kind == "OP":
                        parts = parts[:-1]
                    if star_tail:
                        e.star, e.star_qual = True, ".".join(x.name.lower() for x in parts)
                        scope.stars.append((e.star_qual, parts[0]))
                        if (self.at_word("EXCEPT") and self.at_punct("(", k=1)):
                            self.next(); self.skip_balanced()
                        expect_operand = False
                    elif self.at_punct("("):
                        name = ".".join(x.text for x in parts).upper()
                        self.call(scope, clause, e, lam, window, name)
                        expect_operand = False
                    else:
                        skip = False
                        if len(parts) == 1 and fn in UNIT_FUNCS and parts[0].text.upper() in UNIT_WORDS and \
                                prev is not None and prev.kind == "PUNCT" and prev.text == "(":
                            skip = True
                        if len(parts) == 1 and fn == "EXTRACT" and self.at_word("FROM"):
                            skip = True
                        if window and len(parts) == 1 and parts[0].kind == "ID" and \
                                self.toks[parts[0].idx - 1].is_word("OVER"):
                            skip = True                                    # OVER window_name
                        if not skip:
                            r = self.make_ref(scope, clause, parts, lam)
                            if r is not None:
                                e.refs.append(r)
                        expect_operand = False
                    prev = self.toks[self.i - 1]
                    continue
                # ---- operator position ---------------------------------------------------
                if allow_alias and not lenient and case_depth == 0 and e.alias_tok is None:
                    self.next()
                    e.alias, e.alias_tok = t.name, t
                    prev = t
                    continue
                self.next()                                                  # unknown trailing word
                prev = t
                continue
            if self.i == pos:
                raise ParseError(f"parser stuck near {self._near()}")
            prev = self.toks[self.i - 1] if self.i else None
        e.tj = self.i
        return e

    def subquery_in_parens_missing(self):
        # SELECT inside a lenient expression without surrounding parens is not valid SQL for us
        raise ParseError(f"unexpected SELECT near {self._near()}")

    def paren(self, scope, clause, e, lam, window, expect_operand):
        """'(' at current position - sub-query, grouping, row/list or lambda parameter list."""
        open_idx = self.i
        nxt = self.peek(1)
        if nxt.kind == "ID" and nxt.text.upper() in QUERY_START and not (nxt.text.upper() == "TABLE" and
                                                                         self.peek(2).kind == "PUNCT"):
            self.next()
            q = self.parse_query("subquery", "", scope)
            self.expect_punct(")")
            scope.children.append(q)
            self.subq_at[open_idx] = q
            return
        if nxt.kind == "PUNCT" and nxt.text == "(" and self._paren_starts_query():
            self.next()
            q = self.parse_query("subquery", "", scope)
            self.expect_punct(")")
            scope.children.append(q)
            self.subq_at[open_idx] = q
            return
        self.next()
        mark = len(scope.refs)
        if not self.at_punct(")"):
            sub = self.scan_list(scope, clause, lenient=True, window=window, lam=lam)
            for s in sub:
                e.strings.extend(s.strings)
                e.refs.extend(s.refs)
        self.expect_punct(")")
        if self.at_op("->"):                                  # (a, b) -> expr
            for r in scope.refs[mark:]:
                if len(r.parts) == 1:
                    lam.add(r.parts[0].text.lower())
                    self.ref_at.pop(r.ti, None)
            del scope.refs[mark:]
            e.refs = [r for r in e.refs if r in scope.refs]

    def call(self, scope, clause, e, lam, window, name):
        """name chain already consumed, positioned at '('."""
        base = name.split(".")[-1]
        self.next()                                           # (
        if self.at_punct(")"):
            self.next()
        else:
            nxt = self.peek()
            if nxt.kind == "ID" and nxt.text.upper() in ("SELECT", "WITH") or \
                    (nxt.kind == "ID" and nxt.text.upper() == "FROM" and base not in ("EXTRACT", "TRIM", "SUBSTRING",
                                                                                      "SUBSTR", "OVERLAY")):
                q = self.parse_query("subquery", "", scope)
                scope.children.append(q)
                self.subq_at[self.i - 1] = q
            else:
                self.accept_word("DISTINCT", "ALL") if base not in ("TRIM",) else None
                first = True
                while True:
                    if base == "EXTRACT" and first:
                        while self.peek().kind == "ID" and not self.at_word("FROM"):
                            self.next()
                    sub = self.scan_expr(scope, clause, lenient=True, window=window, fn=base, lam=lam)
                    e.strings.extend(sub.strings)
                    e.refs.extend(sub.refs)
                    first = False
                    if self.at_punct(","):
                        self.next()
                        continue
                    break
            self.expect_punct(")")
        # postfix:  FILTER (WHERE ..)   WITHIN GROUP (..)   IGNORE NULLS   OVER (..) | OVER name
        while True:
            if self.at_word("FILTER") and self.at_punct("(", k=1):
                self.next(); self.next()
                self.scan_list(scope, clause, lenient=True, lam=lam)
                self.expect_punct(")")
            elif self.at_word("WITHIN") and self.at_word("GROUP", k=1):
                self.next(); self.next()
                self.expect_punct("(")
                self.scan_list(scope, clause, lenient=True, lam=lam)
                self.expect_punct(")")
            elif self.at_word("IGNORE", "RESPECT") and self.at_word("NULLS", k=1):
                self.next(); self.next()
            elif self.at_word("OVER"):
                self.next()
                if self.at_punct("("):
                    self.next()
                    if not self.at_punct(")"):
                        self.scan_list(scope, clause, lenient=True, window=True, lam=lam)
                    self.expect_punct(")")
                elif self.peek().kind in ("ID", "QID"):
                    self.next()
            else:
                break

    # ---- conditions ----------------------------------------------------------------------------
    def classify(self, scope, a, b, clause, source=None):
        for (x, y) in self.split_conjuncts(a, b):
            self.classify_one(scope, x, y, clause, source)

    def _match_close(self, i, j):
        """index of the ')' matching the '(' at i (within [i, j)) or -1"""
        d = 0
        for k in range(i, j):
            t = self.toks[k]
            if t.kind == "PUNCT":
                if t.text == "(":
                    d += 1
                elif t.text == ")":
                    d -= 1
                    if d == 0:
                        return k
        return -1

    def split_conjuncts(self, a, b):
        # strip enclosing parentheses
        while b - a >= 2 and self.toks[a].kind == "PUNCT" and self.toks[a].text == "(" and \
                self._match_close(a, b) == b - 1:
            # keep the parens if the content is a sub-query
            if self.toks[a + 1].is_word("SELECT", "WITH"):
                break
            a, b = a + 1, b - 1
        parts, depth, case, between, start, has_or = [], 0, 0, 0, a, False
        for k in range(a, b):
            t = self.toks[k]
            if t.kind == "PUNCT":
                depth += (t.text in "([") - (t.text in ")]")
            elif t.kind == "ID" and depth == 0:
                u = t.text.upper()
                if u == "CASE":
                    case += 1
                elif u == "END":
                    case = max(0, case - 1)
                elif case == 0:
                    if u == "BETWEEN":
                        between += 1
                    elif u == "AND":
                        if between:
                            between -= 1
                        else:
                            parts.append((start, k)); start = k + 1
                    elif u == "OR":
                        has_or = True
        parts.append((start, b))
        if has_or:
            return [(a, b)]
        out = []
        for (x, y) in parts:
            if y > x:
                if len(parts) > 1 and y - x >= 2 and self.toks[x].kind == "PUNCT" and self.toks[x].text == "(" \
                        and self._match_close(x, y) == y - 1 and not self.toks[x + 1].is_word("SELECT", "WITH"):
                    out.extend(self.split_conjuncts(x, y))
                else:
                    out.append((x, y))
        return out

    def classify_one(self, scope, a, b, clause, source):
        refs_all = [self.ref_at[k] for k in range(a, b) if k in self.ref_at and self.ref_at[k].scope is scope]
        cond = Cond("complex", scope, clause, source, refs=refs_all, ti=a, tj=b)
        while b - a >= 2 and self.toks[a].kind == "PUNCT" and self.toks[a].text == "(" and \
                self._match_close(a, b) == b - 1 and not self.toks[a + 1].is_word("SELECT", "WITH"):
            a, b = a + 1, b - 1
        if b <= a:
            return
        opk, op, depth, case = -1, "", 0, 0
        if self.toks[a].is_word("NOT", "EXISTS"):
            scope.conds.append(cond)
            return
        d0, c0 = 0, 0
        for k in range(a, b):                                   # an OR at the top level -> complex condition
            t = self.toks[k]
            if t.kind == "PUNCT":
                d0 += (t.text in "([") - (t.text in ")]")
            elif t.kind == "ID" and d0 == 0:
                u = t.text.upper()
                c0 += (u == "CASE") - (u == "END" and c0 > 0)
                if u == "OR" and c0 == 0:
                    scope.conds.append(cond)
                    return
        k = a
        while k < b:
            t = self.toks[k]
            if t.kind == "PUNCT":
                depth += (t.text in "([") - (t.text in ")]")
            elif depth == 0:
                if t.kind == "OP" and t.text in COMPARE_OPS:
                    opk, op = k, t.text
                    break
                if t.kind == "ID":
                    u = t.text.upper()
                    if u == "CASE":
                        case += 1
                    elif u == "END":
                        case = max(0, case - 1)
                    elif case == 0 and u in COND_WORDS:
                        opk, op = k, u
                        if u == "IS" and self.toks[k + 1].is_word("NOT") if k + 1 < b else False:
                            op = "IS NOT"
                        break
                    elif case == 0 and u == "NOT" and k + 1 < b and self.toks[k + 1].is_word(*COND_WORDS):
                        opk, op = k, "NOT " + self.toks[k + 1].text.upper()
                        break
            k += 1
        if opk < 0:
            scope.conds.append(cond)
            return
        rstart = opk + (2 if op.startswith("NOT ") or op == "IS NOT" else 1)
        L = [self.ref_at[k] for k in range(a, opk) if k in self.ref_at and self.ref_at[k].scope is scope]
        R = [self.ref_at[k] for k in range(rstart, b) if k in self.ref_at and self.ref_at[k].scope is scope]
        values = []
        for k in range(rstart, b):
            t = self.toks[k]
            if t.kind == "STR":
                values.append(unquote_string(t.text).strip().lower())
            elif t.kind == "NUM":
                values.append(t.text.strip().lower())
        subq = None
        if rstart < b and self.toks[rstart].kind == "PUNCT" and self.toks[rstart].text == "(":
            subq = self.subq_at.get(rstart)
        cond.op, cond.values = op, values

        def only(refs, lo, hi):
            return len(refs) == 1 and refs[0].ti == lo and refs[0].tj == hi - 1

        if subq is not None and len(L) == 1:
            cond.kind, cond.left, cond.subquery = "in_subquery", L[0], subq
            cond.wrapped = not only(L, a, opk)
        elif len(L) == 1 and not R:
            cond.kind, cond.left, cond.wrapped = "filter", L[0], not only(L, a, opk)
        elif len(R) == 1 and not L and op in COMPARE_OPS:
            cond.kind, cond.left, cond.op = "filter", R[0], FLIP.get(op, op)
            cond.wrapped = not only(R, rstart, b)
        elif len(L) == 1 and len(R) >= 1:
            cond.kind, cond.left, cond.right = "join", L[0], R[0]
            cond.wrapped = not (only(L, a, opk) and only(R, rstart, b))
            for extra in R[1:]:                                    # a BETWEEN b.x AND b.y
                scope.conds.append(Cond("join", scope, clause, source, left=L[0], right=extra, op=op,
                                        wrapped=True, refs=refs_all, ti=a, tj=b))
        elif len(R) == 1 and len(L) > 1:
            cond.kind, cond.left, cond.right, cond.wrapped = "join", R[0], L[0], True
        scope.conds.append(cond)

    # ---- statements -----------------------------------------------------------------------------
    def parse(self):
        st, first = self.stmt, self.peek()
        if first.kind == "EOF":
            st.kind, st.mode = "EMPTY", "skipped"
            return
        w = first.text.upper() if first.kind == "ID" else first.text
        if w in ("SELECT", "WITH", "(", "FROM", "VALUES") or (w == "TABLE" and self.peek(1).kind != "PUNCT"):
            st.kind = "SELECT"
            st.root = self.parse_query("root")
        elif w == "CREATE":
            self.parse_create()
        elif w == "INSERT":
            self.parse_insert()
        elif w == "MERGE":
            self.parse_merge()
        elif w == "UPDATE":
            self.parse_update()
        elif w == "DELETE":
            self.parse_delete()
        elif w in ("SET", "DECLARE"):
            self.parse_var(w)
            return
        elif w == "CACHE":
            self.parse_cache()
        elif w == "EXPLAIN":
            self.next()
            while self.at_word("EXTENDED", "FORMATTED", "COST", "CODEGEN", "VERBOSE", "ANALYZE"):
                self.next()
            st.kind = "SELECT"
            st.root = self.parse_query("root")
        else:
            st.kind = "OTHER" if first.kind == "ID" else "UNKNOWN"
            if first.kind == "ID":
                st.kind = w if w in ("DROP", "USE", "TRUNCATE", "ALTER", "OPTIMIZE", "VACUUM", "GRANT", "SHOW",
                                     "DESCRIBE", "ANALYZE", "REFRESH", "COPY", "BEGIN", "END", "IF", "WHILE") else "OTHER"
            st.mode = "skipped"
            st.warnings.append(f"Statement type '{first.text}' is not analysed (kept verbatim).")
            self.i = self.end
            if w == "DROP":
                self.parse_drop()
            return
        if self.i < self.end:
            raise ParseError(f"could not parse everything, stopped near {self._near()}")

    def parse_drop(self):
        i = self.stmt.ti
        words = []
        while i < self.end and self.toks[i].kind == "ID" and self.toks[i].text.upper() in (
                "DROP", "TABLE", "VIEW", "TEMP", "TEMPORARY", "IF", "EXISTS", "MATERIALIZED", "STREAMING"):
            words.append(self.toks[i].text.upper()); i += 1
        if "TABLE" in words or "VIEW" in words:
            self.i = i
            try:
                self.stmt.target = TableName(self.name_chain())
                self.stmt.target_role = "drop"
            except ParseError:
                pass
            self.i = self.end

    def _target(self, role):
        toks = self.name_chain()
        self.stmt.target, self.stmt.target_role = TableName(toks), role
        return self.stmt.target

    def parse_create(self):
        st = self.stmt
        st.kind = "CREATE"
        self.next()
        mods = set()
        while self.at_word("OR", "REPLACE", "GLOBAL", "TEMP", "TEMPORARY", "EXTERNAL", "MATERIALIZED", "STREAMING",
                           "LIVE", "TRANSIENT"):
            mods.add(self.next().text.upper())
        kind = self.peek().text.upper() if self.peek().kind == "ID" else ""
        if kind not in ("TABLE", "VIEW"):
            st.kind, st.mode = "OTHER", "skipped"
            st.warnings.append(f"CREATE {kind} is not analysed (kept verbatim).")
            self.i = self.end
            return
        self.next()
        if self.at_word("IF"):
            self.next(); self.expect_word("NOT"); self.expect_word("EXISTS")
        tn = self._target("create")
        st.created_key = tn.key
        cols = []
        if self.at_punct("("):
            self.next()
            d, seg = 0, True
            while True:
                t = self.peek()
                if t.kind == "EOF":
                    raise ParseError("unterminated column list")
                if t.kind == "PUNCT" and t.text == "(":
                    d += 1
                elif t.kind == "PUNCT" and t.text == ")":
                    if d == 0:
                        self.next(); break
                    d -= 1
                elif t.kind == "PUNCT" and t.text == "," and d == 0:
                    seg = True; self.next(); continue
                elif seg and d == 0 and t.kind in ("ID", "QID"):
                    cols.append(t.name)
                    seg = False
                self.next()
        st.created_columns = cols
        # table options until AS <query> (skipping balanced groups)
        while self.peek().kind != "EOF":
            if self.at_word("AS") and (self.at_word(*QUERY_START, k=1) or self.at_punct("(", k=1)):
                self.next()
                st.root = self.parse_query("root")
                if not cols:
                    st.created_columns = [n for n in st.root.outputs()[0]]
                break
            if self.at_word("LIKE", "CLONE") or (self.at_word("DEEP", "SHALLOW") and self.at_word("CLONE", k=1)):
                while self.at_word("LIKE", "CLONE", "DEEP", "SHALLOW"):
                    self.next()
                q = self.new_query("root")
                sc = self.new_scope(q)
                q.branches.append(sc)
                sc.stars.append(("", None))
                self.new_source(sc, "table", table=TableName(self.name_chain()))
                st.root = q
                continue
            if self.at_punct("("):
                self.skip_balanced()
            elif self.at_word("AS") and self.peek(1).kind == "EOF":
                self.next()
            else:
                self.next()
        if st.root is None and kind == "VIEW":
            st.warnings.append("CREATE VIEW without a recognisable AS <query>")

    def parse_cache(self):
        st = self.stmt
        self.next()
        self.accept_word("LAZY")
        self.expect_word("TABLE")
        tn = self._target("create")
        st.kind = "CREATE"
        st.created_key = tn.key
        if self.at_word("OPTIONS"):
            self.next(); self.skip_balanced()
        self.accept_word("AS")
        if self.at_word(*QUERY_START) or self.at_punct("("):
            st.root = self.parse_query("root")
            st.created_columns = st.root.outputs()[0]
        else:
            self.i = self.end

    def parse_insert(self):
        st = self.stmt
        st.kind = "INSERT"
        self.next()
        if self.at_word("OVERWRITE") and self.at_word("DIRECTORY", "LOCAL", k=1):
            st.kind, st.mode = "OTHER", "skipped"
            st.warnings.append("INSERT OVERWRITE DIRECTORY is not analysed.")
            self.i = self.end
            return
        if not self.accept_word("INTO", "OVERWRITE"):
            raise ParseError("expected INTO / OVERWRITE")
        self.accept_word("TABLE")
        self._target("insert")
        while True:
            if self.at_word("PARTITION") and self.at_punct("(", k=1):
                self.next(); self.skip_balanced()
            elif self.at_word("BY") and self.at_word("NAME", k=1):
                self.next(); self.next()
            elif self.at_word("REPLACE") and self.at_word("WHERE", "USING", k=1):
                self.next()
                if self.at_word("USING"):
                    self.next(); self.skip_balanced()
                else:
                    self.next()
                    q0 = self.new_query("paren")
                    sc0 = self.new_scope(q0)
                    q0.branches.append(sc0)
                    self.scan_expr(sc0, "other")
            elif self.at_punct("(") and not (self.at_word(*QUERY_START, k=1) or self._paren_starts_query()):
                self.next()
                while not self.at_punct(")"):
                    t = self.next()
                    if t.kind == "EOF":
                        raise ParseError("unterminated column list")
                    if t.kind in ("ID", "QID"):
                        st.target_columns.append(t)
                self.next()
            else:
                break
        if self.at_word(*QUERY_START) or self.at_punct("("):
            st.root = self.parse_query("root")
        else:
            raise ParseError(f"expected a query after INSERT target near {self._near()}")

    def _target_alias(self, sc, src):
        if self.at_word("AS") and self.peek(1).kind in ("ID", "QID"):
            self.next()
            t = self.next()
            src.alias, src.alias_tok = t.name, t
        elif self.peek().kind in ("ID", "QID") and not self.at_word("SET", "WHERE", "USING", "ON", "WHEN", "FROM"):
            t = self.next()
            src.alias, src.alias_tok = t.name, t

    def _dml_scope(self):
        q = self.new_query("root")
        sc = self.new_scope(q, "dml")
        q.branches.append(sc)
        self.stmt.root = q
        return q, sc

    def parse_update(self):
        st = self.stmt
        st.kind = "UPDATE"
        self.next()
        q, sc = self._dml_scope()
        tn = TableName(self.name_chain())
        st.target, st.target_role = tn, "update"
        src = self.new_source(sc, "table", table=tn, join_type="FROM", role="update")
        self._target_alias(sc, src)
        self.expect_word("SET")
        self.parse_assignments(sc, src)
        if self.at_word("FROM"):
            self.next()
            self.parse_from(sc)
        if self.at_word("WHERE"):
            self.next()
            e = self.scan_expr(sc, "where")
            self.classify(sc, e.ti, e.tj, "where")

    def parse_assignments(self, sc, target_src):
        while True:
            parts = self.name_chain()
            ref = self.make_ref(sc, "assign", parts, set())
            if ref is not None:
                ref.kind = "assign_target"
                ref.source, ref.status = target_src, "resolved"
                ref.name = parts[-1].name.lower()
                ref.name_tok = parts[-1]
                ref.qualifier_toks = parts[:-1]
            if not self.at_op("=") and not self.at_op("=="):
                raise ParseError(f"expected '=' in SET near {self._near()}")
            self.next()
            self.scan_expr(sc, "set")
            if self.at_punct(","):
                self.next(); continue
            break

    def parse_delete(self):
        st = self.stmt
        st.kind = "DELETE"
        self.next()
        self.expect_word("FROM")
        q, sc = self._dml_scope()
        tn = TableName(self.name_chain())
        st.target, st.target_role = tn, "delete"
        src = self.new_source(sc, "table", table=tn, join_type="FROM", role="delete")
        self._target_alias(sc, src)
        if self.at_word("USING"):
            self.next()
            self.parse_from(sc)
        if self.at_word("WHERE"):
            self.next()
            e = self.scan_expr(sc, "where")
            self.classify(sc, e.ti, e.tj, "where")

    def parse_merge(self):
        st = self.stmt
        st.kind = "MERGE"
        self.next()
        self.expect_word("INTO")
        q, sc = self._dml_scope()
        tn = TableName(self.name_chain())
        st.target, st.target_role = tn, "merge"
        tgt = self.new_source(sc, "table", table=tn, join_type="FROM", role="merge")
        self._target_alias(sc, tgt)
        self.expect_word("USING")
        sj = self.i
        self.parse_factor(sc, "INNER", sj)
        src = sc.sources[-1]
        self.expect_word("ON")
        e = self.scan_expr(sc, "on")
        src.on_range = (e.ti, e.tj)
        self.classify(sc, e.ti, e.tj, "on", src)
        while self.at_word("WHEN"):
            self.next()
            self.accept_word("NOT")
            self.expect_word("MATCHED")
            if self.at_word("BY"):
                self.next(); self.next()
            if self.at_word("AND"):
                self.next()
                c = self.scan_expr(sc, "where")
                self.classify(sc, c.ti, c.tj, "where")
            self.expect_word("THEN")
            if self.at_word("UPDATE"):
                self.next()
                self.expect_word("SET")
                if self.at_op("*"):
                    self.next()
                else:
                    self.parse_assignments(sc, tgt)
            elif self.at_word("DELETE"):
                self.next()
            elif self.at_word("INSERT"):
                self.next()
                if self.at_op("*"):
                    self.next()
                else:
                    if self.at_punct("("):
                        self.next()
                        while not self.at_punct(")"):
                            t = self.next()
                            if t.kind == "EOF":
                                raise ParseError("unterminated INSERT column list")
                            if t.kind in ("ID", "QID"):
                                ref = self.make_ref(sc, "assign", [t], set())
                                if ref:
                                    ref.kind, ref.source, ref.status = "assign_target", tgt, "resolved"
                                    ref.name, ref.name_tok = t.name.lower(), t
                        self.next()
                    self.expect_word("VALUES")
                    self.expect_punct("(")
                    self.scan_list(sc, "set", lenient=True)
                    self.expect_punct(")")
            else:
                raise ParseError(f"unexpected MERGE action near {self._near()}")

    def parse_var(self, w):
        st = self.stmt
        st.kind = w
        st.mode = "skipped"
        self.next()
        self.accept_word("OR"); self.accept_word("REPLACE")
        self.accept_word("VAR", "VARIABLE")
        name_parts = []
        while self.peek().kind != "EOF" and not self.at_op("=") and not self.at_word("DEFAULT") \
                and not self.at_punct(";"):
            name_parts.append(self.next().text)
            if w == "DECLARE" and len(name_parts) == 1:
                break
        st.var_name = "".join(name_parts)
        # value = everything after '=' / DEFAULT
        while self.peek().kind != "EOF" and not self.at_op("=") and not self.at_word("DEFAULT"):
            self.next()
        self.next()
        st.var_strings = [unquote_string(t.text) for t in self.toks[self.i:self.end] if t.kind == "STR"]
        self.i = self.end


# ---------------------------------------------------------------------------------------- fallback
def _fallback(script, stmt):
    """Token based best-effort extraction: tables after FROM/JOIN/INTO/UPDATE/USING and alias.column refs."""
    p = _Parser(script, stmt)
    q = p.new_query("root")
    sc = p.new_scope(q, "fallback")
    q.branches.append(sc)
    stmt.root = q
    stmt.mode = "fallback"
    toks = script.toks
    i = stmt.ti
    expect_table = False
    pending_join = "FROM"
    while i < stmt.tj:
        t = toks[i]
        if t.kind == "ID":
            u = t.text.upper()
            if u in ("FROM", "JOIN", "INTO", "UPDATE", "USING", "TABLE") and not (
                    u == "TABLE" and i > stmt.ti and toks[i - 1].text.upper() not in ("CREATE", "REPLACE", "EXISTS", "TEMP", "TEMPORARY", "VIEW")):
                expect_table = True
                if u == "JOIN":
                    words = []
                    j = i - 1
                    while j >= stmt.ti and toks[j].kind == "ID" and toks[j].text.upper() in (
                            "LEFT", "RIGHT", "FULL", "INNER", "CROSS", "OUTER", "SEMI", "ANTI", "NATURAL"):
                        words.insert(0, toks[j].text.upper()); j -= 1
                    words = [w for w in words if w != "OUTER"]
                    pending_join = " ".join(words) or "INNER"
                else:
                    pending_join = "FROM"
                i += 1
                continue
        if expect_table:
            if t.kind in ("ID", "QID", "DQ") and not (t.kind == "ID" and (t.text.upper() in (
                    "SELECT", "VALUES", "LATERAL", "UNNEST", "IF", "NOT", "EXISTS", "OR", "REPLACE", "TEMP",
                    "TEMPORARY", "VIEW", "TABLE") or t.text.upper() in CLAUSE_STOP or t.text.upper() in AFTER_TABLE_RESERVED)):
                j = i
                chain = [toks[j]]
                while j + 2 < stmt.tj and toks[j + 1].kind == "PUNCT" and toks[j + 1].text == "." and \
                        toks[j + 2].kind in ("ID", "QID", "DQ"):
                    chain.append(toks[j + 2]); j += 2
                if j + 1 < stmt.tj and toks[j + 1].kind == "PUNCT" and toks[j + 1].text == "(":
                    expect_table = False          # function call
                    i = j + 1
                    continue
                tn = TableName(chain)
                src = p.new_source(sc, "table", table=tn, join_type=pending_join, join_ti=i)
                k = j + 1
                if k < stmt.tj and toks[k].is_word("AS"):
                    k += 1
                if k < stmt.tj and toks[k].kind in ("ID", "QID", "DQ") and not (
                        toks[k].kind == "ID" and toks[k].text.upper() in AFTER_TABLE_RESERVED):
                    src.alias, src.alias_tok = toks[k].name, toks[k]
                    j = k
                i = j + 1
                if i < stmt.tj and toks[i].kind == "PUNCT" and toks[i].text == ",":
                    i += 1                         # comma join: next name is another table
                    pending_join = "COMMA"
                    continue
                expect_table = False
                continue
            elif not (t.kind == "PUNCT" and t.text == "("):
                expect_table = False
        i += 1
    # alias.column / table.column references
    names = {}
    for s in sc.sources:
        names[(s.alias or s.table.parts[-1]).lower()] = s
        names.setdefault(s.table.parts[-1].lower(), s)
    for i in range(stmt.ti, stmt.tj - 2):
        a, d, b = toks[i], toks[i + 1], toks[i + 2]
        if a.kind in ("ID", "QID") and d.kind == "PUNCT" and d.text == "." and b.kind in ("ID", "QID") and \
                a.name.lower() in names and not (i > stmt.ti and toks[i - 1].kind == "PUNCT" and toks[i - 1].text == "."):
            if i + 3 < stmt.tj and toks[i + 3].kind == "PUNCT" and toks[i + 3].text == "(":
                continue
            src = names[a.name.lower()]
            ref = ColRef(parts=[a, b], ti=a.idx, tj=b.idx, scope=sc, clause="other", source=src,
                         name=b.name.lower(), name_tok=b, qualifier_toks=[a], status="resolved")
            sc.refs.append(ref)
    # join conditions as plain text
    for s in sc.sources:
        if s.join_type != "FROM" and s.join_ti >= 0:
            j = s.join_ti
            while j < stmt.tj and not toks[j].is_word("ON"):
                j += 1
                if j - s.join_ti > 40:
                    break
            if j < stmt.tj and toks[j].is_word("ON"):
                k = j + 1
                d = 0
                while k < stmt.tj:
                    tk = toks[k]
                    if tk.kind == "PUNCT":
                        d += (tk.text == "(") - (tk.text == ")")
                        if d < 0:
                            break
                    if d == 0 and tk.kind == "ID" and tk.text.upper() in CLAUSE_STOP | JOIN_WORDS_SOFT:
                        break
                    k += 1
                s.on_range = (j + 1, k)
                try:
                    _fallback_conds(script, sc, j + 1, k, s)
                except Exception:   # noqa
                    pass
    return sc


def _fallback_conds(script, sc, a, b, src):
    toks = script.toks
    refs = {r.ti: r for r in sc.refs}
    cur = a
    k = a
    pieces = []
    depth = 0
    while k < b:
        t = toks[k]
        if t.kind == "PUNCT":
            depth += (t.text == "(") - (t.text == ")")
        if t.kind == "ID" and t.text.upper() == "AND" and depth == 0:
            pieces.append((cur, k)); cur = k + 1
        k += 1
    pieces.append((cur, b))
    for x, y in pieces:
        rs = [refs[j] for j in range(x, y) if j in refs]
        ops = [toks[j] for j in range(x, y) if toks[j].kind == "OP" and toks[j].text in COMPARE_OPS]
        if len(rs) == 2 and ops:
            sc.conds.append(Cond("join", sc, "on", src, left=rs[0], right=rs[1], op=ops[0].text, refs=rs, ti=x, tj=y))
        elif len(rs) == 1 and ops:
            vals = [unquote_string(toks[j].text).lower() if toks[j].kind == "STR" else toks[j].text.lower()
                    for j in range(x, y) if toks[j].kind in ("STR", "NUM")]
            sc.conds.append(Cond("filter", sc, "on", src, left=rs[0], op=ops[0].text, values=vals, refs=rs, ti=x, tj=y))


# ---------------------------------------------------------------------------------------- linking
def _find_cte(scope, name):
    """CTE (QueryNode) visible from `scope` under `name` or None."""
    name = name.lower()
    node = scope.query
    guard = 0
    while node is not None and guard < 200:
        guard += 1
        if node.kind == "cte" and node.owner is not None:
            vis = node.owner.ctes[:node.cte_index] + ([node] if node.owner.recursive else [])
            for c in reversed(vis):
                if c.name.lower() == name:
                    return c
            owner = node.owner
            node = owner.parent_scope.query if owner.parent_scope is not None else None
            continue
        for c in reversed(node.ctes):
            if c.name.lower() == name:
                return c
        node = node.parent_scope.query if node.parent_scope is not None else None
    return None


def source_outputs(src, script):
    """(names or None, has_star) of a derived-like source."""
    if src.kind == "lateral_view":
        return [c.lower() for c in src.col_aliases], False
    if src.col_aliases and src.kind in ("derived", "values", "function"):
        return [c.lower() for c in src.col_aliases], False
    if src.kind in ("derived", "cte", "values") and src.query is not None:
        return src.query.outputs()
    if src.kind == "internal":
        defs = script.internal_defs.get(src.table.key)
        if defs:
            q, cols = defs[0]
            if cols:
                return [c.lower() for c in cols], False
            return q.outputs()
    return None, True


def _names_of(src):
    n = set()
    if src.alias:
        n.add(src.alias.lower())
    elif src.table is not None:
        parts = [p.lower() for p in src.table.parts]
        for k in range(1, len(parts) + 1):
            n.add(".".join(parts[-k:]))
    elif src.func_name:
        n.add(src.func_name.lower())
    return n


def _lookup(scope, qual):
    s, guard = scope, 0
    while s is not None and guard < 100:
        guard += 1
        for src in s.sources:
            if qual in _names_of(src):
                return src
        s = s.parent_scope
    return None


def _resolve_ref(script, ref):
    scope = ref.scope
    p = [t.name.lower() if t.kind in ("QID", "DQ") else t.text.lower() for t in ref.parts]
    if ref.kind == "assign_target" or ref.status == "resolved" and ref.source is not None and ref.kind != "column":
        return
    src = None
    n = len(p)
    qlen = 0
    for ql in (1, 2, 3):
        if n >= ql + 1:
            s = _lookup(scope, ".".join(p[:ql]))
            if s is not None:
                src, qlen = s, ql
                break
    if src is not None:
        ref.qualifier_toks = ref.parts[:qlen]
        ref.name, ref.name_tok, ref.path = p[qlen], ref.parts[qlen], p[qlen + 1:]
        _finish_with_source(script, ref, src)
        return
    ref.name, ref.name_tok, ref.path = p[0], ref.parts[0], p[1:]
    name = p[0]
    # select alias used in ORDER/GROUP/HAVING/QUALIFY
    if ref.clause in ("order", "group", "having", "qualify") and n == 1:
        for it in scope.items:
            if it.alias and it.alias.lower() == name and not (it.simple_ref is not None and it.simple_ref.name == name):
                ref.status = "alias"
                return
    srcs = [s for s in scope.sources]
    if not srcs:
        # correlated / outer scope
        up = scope.parent_scope
        cands = []
        while up is not None and not cands:
            cands = list(up.sources)
            up = up.parent_scope
        if len(cands) == 1:
            _finish_with_source(script, ref, cands[0])
        else:
            ref.status, ref.candidates = ("ambiguous" if cands else "unresolved"), cands
        return
    if len(srcs) == 1:
        _finish_with_source(script, ref, srcs[0])
        return
    # lateral view output columns, derived outputs
    known, unknown = [], []
    for s in srcs:
        names, star = source_outputs(s, script)
        if s.kind in ("derived", "cte", "internal", "lateral_view", "values") and names is not None and not star:
            if name in names:
                known.append(s)
        else:
            unknown.append(s)
    if len(known) == 1 and not unknown:
        _finish_with_source(script, ref, known[0])
    elif len(known) == 0 and len(unknown) == 1:
        _finish_with_source(script, ref, unknown[0])
    else:
        ref.status, ref.candidates = "ambiguous", known + unknown


def _finish_with_source(script, ref, src):
    ref.source = src
    ref.status = "resolved" if src.kind == "table" else ("derived" if src.kind != "function" else "derived")


def link_script(script):
    """Classify table sources (physical / cte / internal) and resolve every column reference."""
    created = {}
    for st in script.statements:
        # sources
        for s in st.sources:
            if s.kind == "table":
                if len(s.table.parts) == 1:
                    cte = _find_cte(s.scope, s.table.parts[0])
                    if cte is not None:
                        s.kind, s.query = "cte", cte
                        continue
                if s.table.key in created:
                    s.kind, s.created_by = "internal", created[s.table.key]
        for sc in st.scopes:
            for r in list(sc.refs):
                try:
                    _resolve_ref(script, r)
                except Exception as e:      # noqa
                    r.status = "unresolved"
                    st.warnings.append(f"Could not resolve column reference {r}: {e}")
        # using columns -> refs (so the converter can rename them)
        for sc in st.scopes:
            for s in sc.sources:
                for ut in s.using:
                    ref = ColRef(parts=[ut], ti=ut.idx, tj=ut.idx, scope=sc, clause="on", kind="using",
                                 name=ut.name.lower(), name_tok=ut, status="resolved", source=s)
                    sc.refs.append(ref)
        if st.created_key:
            created[st.created_key] = st.index
            if st.root is not None:
                script.internal_defs.setdefault(st.created_key, []).append((st.root, st.created_columns or None))
        elif st.kind == "INSERT" and st.target is not None and st.root is not None and st.target.key in created:
            cols = [t.name for t in st.target_columns] or None
            script.internal_defs.setdefault(st.target.key, []).append((st.root, cols))
        # a DML/CTAS target that is also created internally
    return script


# ---------------------------------------------------------------------------------------- entry
def split_statements(toks):
    """Token index ranges of statements split on top-level ';'."""
    out, start, depth = [], 0, 0
    for k, t in enumerate(toks):
        if t.kind == "EOF":
            break
        if t.kind == "PUNCT":
            if t.text == "(":
                depth += 1
            elif t.text == ")":
                depth = max(0, depth - 1)
            elif t.text == ";" and depth == 0:
                if k > start:
                    out.append((start, k))
                start = k + 1
    if start < len(toks) - 1:
        out.append((start, len(toks) - 1))
    return out


def parse_script(text):
    """Parse a SQL script (several statements allowed).  Never raises."""
    text = text if isinstance(text, str) else str(text)
    try:
        toks, comments, warns = tokenize(text)
    except Exception as e:      # noqa  (tokenizer is lenient; this is a last-resort guard)
        toks, comments, warns = [Tok("EOF", "", len(text), len(text), 0)], [], [f"Tokenizer failure: {e}"]
    script = Script(text, toks, comments, warnings=list(warns))
    for n, (a, b) in enumerate(split_statements(toks), 1):
        stmt = Statement(index=n, kind="SELECT", ti=a, tj=b, text=text[toks[a].start:toks[b - 1].end])
        script.statements.append(stmt)
        try:
            _Parser(script, stmt).parse()
        except ParseError as e:
            _reset(stmt)
            stmt.warnings.append(f"Structured parse failed ({e}); using fallback extraction for this statement.")
            _safe_fallback(script, stmt)
        except RecursionError:
            _reset(stmt)
            stmt.warnings.append("Statement is too deeply nested; using fallback extraction.")
            _safe_fallback(script, stmt)
        except Exception as e:     # noqa
            _reset(stmt)
            stmt.warnings.append(f"Unexpected parser error ({type(e).__name__}: {e}); using fallback extraction.")
            _safe_fallback(script, stmt)
    try:
        link_script(script)
    except Exception as e:         # noqa
        script.warnings.append(f"Linking step failed: {e}")
    return script


def _reset(stmt):
    stmt.root = None
    stmt.scopes, stmt.queries, stmt.sources = [], [], []
    stmt.target = None
    stmt.created_key, stmt.created_columns, stmt.target_columns = "", [], []
    stmt.kind = stmt.kind if stmt.kind in ("SELECT", "CREATE", "INSERT", "MERGE", "UPDATE", "DELETE") else stmt.kind


def _safe_fallback(script, stmt):
    try:
        _fallback(script, stmt)
    except Exception as e:         # noqa
        _reset(stmt)
        stmt.mode = "skipped"
        stmt.errors.append(f"Fallback extraction failed too: {e}")
