"""Pod cross-pollination tool: rule-based SQL (Databricks flavour) analysis and conversion. No LLM, no network."""
__version__ = "2.0.0"
