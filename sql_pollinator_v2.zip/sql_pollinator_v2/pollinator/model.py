"""Turns a parsed script into a "concept model": table INSTANCES (the same table used twice = two instances),
join EDGES (instance.column <op> instance.column, traced through CTEs / sub-queries / temp tables back to the real
tables), FILTERS and the SELECTION REASONS of the query.  Everything here is rule based.
"""
import re
from dataclasses import dataclass, field

from .parser import parse_script, source_outputs
from .tokenizer import unquote_string

REASON_FIELD = "selectionreason"


# ---------------------------------------------------------------------------------------- helpers
def norm_reason(text):
    """Case/space/punctuation-insensitive form used to compare selection reasons."""
    return re.sub(r"\s+", " ", re.sub(r"[^0-9a-z]+", " ", str(text).lower())).strip()


def norm_field(name):
    return re.sub(r"[^0-9a-z]", "", str(name).lower())


def is_reason_field(name):
    return norm_field(name) == REASON_FIELD


def condense(text, limit=400):
    t = re.sub(r"\s+", " ", text).strip()
    return t if len(t) <= limit else t[:limit - 3] + "..."


@dataclass(eq=False)
class Instance:
    id: str
    source: object
    key: str
    raw: str
    name: str
    alias: str
    join_type: str
    join_text: str
    scope: object
    context: str
    depth: int
    stmt: int
    is_root: bool
    role: str = "read"
    cols: dict = field(default_factory=dict)             # column -> set(clauses)
    filters: list = field(default_factory=list)          # (col, op, values tuple, clause)
    outputs: list = field(default_factory=list)          # (out_alias, col, position)
    order: int = 0

    @property
    def label(self):
        return f"{self.raw}" + (f" {self.alias}" if self.alias else "")

    @property
    def col_names(self):
        return set(self.cols)

    @property
    def join_cols(self):
        return {c for c, cl in self.cols.items() if "on" in cl or "using" in cl}


@dataclass(eq=False)
class Edge:
    a: object
    col_a: str
    b: object
    col_b: str
    op: str
    join_type: str
    kind: str = "on"            # on | where | using | in_subquery | complex
    wrapped: bool = False
    scope: object = None

    def other(self, inst):
        return self.b if inst is self.a else self.a

    def text(self):
        l = f"{self.a.alias or self.a.name}.{self.col_a}"
        r = f"{self.b.alias or self.b.name}.{self.col_b}"
        return f"{l} {self.op} {r}"


@dataclass
class Reason:
    text: str
    norm: str
    source: str                         # alias | predicate | comment | variable | insert | struct | manual
    scopes: set = None                  # leaf scope ids; None = the whole script


class QueryModel:
    def __init__(self, script, catalog=None):
        self.script = script
        self.catalog = catalog or {}
        self.instances = []
        self.inst_of = {}                # source id -> Instance
        self.edges = []
        self.warnings = []
        self.unresolved = 0
        self.reasons = []
        self._build()

    # ---- construction ---------------------------------------------------------------------------
    def _build(self):
        sc = self.script
        for st in sc.statements:
            for w in st.warnings + st.errors:
                self.warnings.append(f"statement {st.index}: {w}")
        for w in sc.warnings:
            self.warnings.append(w)
        n = 0
        for st in sc.statements:
            for s in st.sources:
                if s.kind != "table":
                    continue
                n += 1
                scope = s.scope
                inst = Instance(
                    id=f"t{n}", source=s, key=s.table.key, raw=s.table.raw(sc.text), name=s.table.name,
                    alias=s.alias, join_type=s.join_type, join_text=self._join_text(s), scope=scope,
                    context=self._context(scope), depth=self._depth(scope), stmt=st.index,
                    is_root=(s.join_type == "FROM" and s.order == 0), role=s.role, order=s.order)
                self.instances.append(inst)
                self.inst_of[s.id] = inst
        for st in sc.statements:
            for scope in st.scopes:
                self._use_scope(scope)
        self.reasons = []

    def _context(self, scope):
        path, q, guard = [], scope.query, 0
        while q is not None and guard < 50:
            guard += 1
            if q.kind == "cte":
                path.append(f"cte:{q.name}")
            elif q.kind == "subquery":
                path.append("subquery")
            elif q.kind == "derived":
                path.append("derived")
            q = q.parent_scope.query if q.parent_scope is not None else None
        return " > ".join(reversed(path)) or "main"

    def _depth(self, scope):
        d, q, guard = 0, scope.query, 0
        while q is not None and guard < 50:
            guard += 1
            if q.parent_scope is not None:
                d += 1
            q = q.parent_scope.query if q.parent_scope is not None else None
        return d

    def _join_text(self, s):
        text = self.script.text
        raw = s.table.raw(text) + (f" {s.alias}" if s.alias else "")
        if s.join_type == "FROM":
            return f"FROM {raw}"
        jt = "," if s.join_type == "COMMA" else f"{s.join_type} JOIN"
        out = f"{jt} {raw}"
        if s.on_range and s.on_range[1] > s.on_range[0]:
            a, b = s.on_range
            out += " ON " + condense(text[self.script.toks[a].start:self.script.toks[b - 1].end])
        elif s.using:
            out += " USING (" + ", ".join(u.name for u in s.using) + ")"
        return out

    # ---- lineage --------------------------------------------------------------------------------
    def bases(self, ref, depth=0):
        """[(Instance, column)] that a column reference ultimately reads (through CTEs / derived tables / temp tables)."""
        if depth > 15:
            return []
        src = ref.source
        name = ref.name
        if src is None or ref.status in ("alias", "star"):
            if ref.status == "ambiguous":
                src = self._by_catalog(ref)
            if src is None:
                return []
        if ref.status == "ambiguous":
            src = self._by_catalog(ref) or src
        return self._src_col(src, name, depth)

    def _by_catalog(self, ref):
        cands = [c for c in ref.candidates if c.kind == "table"]
        hits = []
        for c in cands:
            cols = self.catalog.get(c.table.key) or self.catalog.get(c.table.name)
            if cols and ref.name in cols:
                hits.append(c)
        return hits[0] if len(hits) == 1 else None

    def _src_col(self, src, name, depth):
        if src.kind == "table":
            inst = self.inst_of.get(src.id)
            return [(inst, name)] if inst is not None else []
        if src.kind in ("derived", "cte", "values") and src.query is not None:
            if src.col_aliases and src.kind in ("derived", "values"):
                names = [c.lower() for c in src.col_aliases]
                if name in names:
                    return self._out_pos(src.query, names.index(name), depth + 1)
            return self._out_name(src.query, name, depth + 1)
        if src.kind == "internal":
            res = []
            for q, cols in self.script.internal_defs.get(src.table.key, []):
                if cols and name in [c.lower() for c in cols]:
                    res.extend(self._out_pos(q, [c.lower() for c in cols].index(name), depth + 1))
                else:
                    res.extend(self._out_name(q, name, depth + 1))
            return res
        return []

    def _out_pos(self, q, pos, depth):
        out = []
        for leaf in q.leaves():
            if pos < len(leaf.items) and not any(it.is_star for it in leaf.items[:pos + 1]):
                out.extend(self._item_bases(leaf.items[pos], depth))
        return out

    def _out_name(self, q, name, depth):
        if depth > 15:
            return []
        if q.col_aliases:
            names = [c.lower() for c in q.col_aliases]
            if name in names:
                return self._out_pos(q, names.index(name), depth)
        out = []
        for leaf in q.leaves():
            found = False
            for it in leaf.items:
                if it.out_name == name and not it.is_star:
                    out.extend(self._item_bases(it, depth))
                    found = True
                    break
            if found:
                continue
            for it in leaf.items:
                if it.is_star:
                    cands = [s for s in leaf.sources if (not it.star_qual or it.star_qual in self._names(s))]
                    cands = [s for s in cands if s.kind != "function"]
                    if len(cands) > 1:
                        cands = [s for s in cands if self._has_col(s, name)] or cands[:0]
                    if len(cands) == 1:
                        out.extend(self._src_col(cands[0], name, depth + 1))
            if leaf.kind in ("table", "fallback"):
                for s in leaf.sources:
                    out.extend(self._src_col(s, name, depth + 1))
        return out

    def _has_col(self, src, name):
        if src.kind == "table":
            cols = self.catalog.get(src.table.key) or self.catalog.get(src.table.name)
            return bool(cols and name in cols)
        names, star = source_outputs(src, self.script)
        return names is not None and name in names

    @staticmethod
    def _names(src):
        from .parser import _names_of
        return _names_of(src)

    def _item_bases(self, item, depth):
        if item.simple_ref is not None:
            return self.bases(item.simple_ref, depth + 1)
        out = []
        for r in item.refs:
            out.extend(self.bases(r, depth + 1))
        return out

    # ---- usage ----------------------------------------------------------------------------------
    def _use_scope(self, scope):
        for r in scope.refs:
            if r.status in ("alias", "star") or r.kind == "assign_target" and r.source is None:
                continue
            bs = self.bases(r)
            if not bs:
                if r.status in ("unresolved", "ambiguous"):
                    self.unresolved += 1
                continue
            for inst, col in bs:
                if inst is not None:
                    inst.cols.setdefault(col, set()).add(r.clause)
        for it in scope.items:
            if it.simple_ref is not None and scope.kind != "values" and scope.query.kind == "root":
                bs = self.bases(it.simple_ref)
                if len(bs) == 1 and bs[0][0] is not None:
                    bs[0][0].outputs.append((it.alias.lower() if it.alias else "", bs[0][1], it.position))
        for c in scope.conds:
            self._use_cond(scope, c)
        for s in scope.sources:
            if s.using and s.order > 0:
                prev = scope.sources[s.order - 1]
                for u in s.using:
                    name = u.name.lower()
                    lb = self._src_col(prev, name, 0)
                    rb = self._src_col(s, name, 0)
                    for li, lc in lb[:2]:
                        for ri, rc in rb[:2]:
                            if li is not None and ri is not None and li is not ri:
                                self.edges.append(Edge(li, lc, ri, rc, "=", s.join_type, "using", False, scope))

    def _use_cond(self, scope, c):
        if c.kind == "filter":
            for inst, col in self.bases(c.left)[:3]:
                if inst is not None:
                    inst.filters.append((col, c.op, tuple(c.values), c.clause))
        elif c.kind == "join":
            lb, rb = self.bases(c.left)[:3], self.bases(c.right)[:3]
            jt = c.source.join_type if (c.clause == "on" and c.source is not None) else "WHERE"
            for li, lc in lb:
                for ri, rc in rb:
                    if li is None or ri is None:
                        continue
                    if li is ri:
                        li.filters.append((lc, c.op + " " + rc, (), c.clause))
                        continue
                    self.edges.append(Edge(li, lc, ri, rc, c.op, jt, "on" if c.clause == "on" else "where",
                                           c.wrapped, scope))
        elif c.kind == "in_subquery" and c.subquery is not None:
            first = c.subquery.first_leaf()
            lb = self.bases(c.left)[:2]
            rb = self._item_bases(first.items[0], 0)[:2] if first is not None and first.items else []
            for li, lc in lb:
                for ri, rc in rb:
                    if li is not None and ri is not None and li is not ri:
                        self.edges.append(Edge(li, lc, ri, rc, c.op, "IN-SUBQUERY", "in_subquery", c.wrapped, scope))
        elif c.kind == "complex" and c.clause in ("on", "where"):
            insts = []
            for r in c.refs:
                for inst, _ in self.bases(r)[:2]:
                    if inst is not None and inst not in insts:
                        insts.append(inst)
            if len(insts) >= 2 and c.clause == "on":
                jt = c.source.join_type if c.source is not None else "WHERE"
                for other in insts[1:]:
                    self.edges.append(Edge(insts[0], "*", other, "*", "complex", jt, "complex", True, scope))

    # ---- scope subsets --------------------------------------------------------------------------
    def closure(self, leaf_scopes):
        """Scopes reachable from the given leaf scopes (sub-queries, CTEs and temp tables they read)."""
        seen, stack = set(), list(leaf_scopes)
        while stack:
            sc = stack.pop()
            if sc.id in seen:
                continue
            seen.add(sc.id)
            qs = list(sc.children)
            for s in sc.sources:
                if s.kind in ("derived", "cte", "values") and s.query is not None:
                    qs.append(s.query)
                elif s.kind == "internal":
                    qs.extend(q for q, _ in self.script.internal_defs.get(s.table.key, []))
            for q in qs:
                stack.extend(q.leaves())
        return seen

    def select_instances(self, scope_ids):
        if scope_ids is None:
            return list(self.instances)
        ids = set()
        by_id = {sc.id: sc for sc in self.script.all_scopes()}
        leafs = [by_id[i] for i in scope_ids if i in by_id]
        reach = self.closure(leafs)
        return [i for i in self.instances if i.scope.id in reach]

    @property
    def parse_mode(self):
        modes = {s.mode for s in self.script.statements if s.kind not in ("SET", "DECLARE", "EMPTY")}
        if not modes or modes <= {"full"}:
            return "full"
        if "fallback" in modes:
            return "fallback" if modes <= {"fallback", "skipped"} else "partial-fallback"
        return "full"


# ---------------------------------------------------------------------------------------- selection reasons
_COMMENT_RE = re.compile(r"selection[\s_\-]*reason\s*[:=\-]\s*(.+)", re.I)


def _strings_in_item(script, item):
    """String literals that can end up as the VALUE of the select item (ignores literals inside WHEN conditions)."""
    toks = script.toks
    out, skip_stack = [], []
    for k in range(item.ti, item.tj):
        t = toks[k]
        if t.kind == "ID":
            u = t.text.upper()
            if u == "CASE":
                skip_stack.append(False)
            elif u == "WHEN" and skip_stack:
                skip_stack[-1] = True
            elif u in ("THEN", "ELSE") and skip_stack:
                skip_stack[-1] = False
            elif u == "END" and skip_stack:
                skip_stack.pop()
        elif t.kind == "STR" and not any(skip_stack):
            out.append(unquote_string(t.text))
    return [s for s in out if s.strip()]


def extract_reasons(script, manual=None):
    """All selection reasons of a script with the scopes they belong to.  Rules (all case-insensitive):
       1. select item aliased  selectionreason / selection_reason  ('x' AS selectionreason, CASE ... THEN 'x')
       2. INSERT INTO t (.., selectionreason, ..) SELECT/VALUES ..  (literal in the same position)
       3. predicates  selectionreason = 'x' / IN ('x','y')
       4. SET selectionreason = 'x'   /  DECLARE ... selectionreason DEFAULT 'x'
       5. comments   -- selectionreason: x
       6. map/struct literals  named_struct('selectionreason', 'x')
       A manual value (from the Excel sheet / UI) replaces everything else."""
    found = []

    def add(text, source, scopes):
        text = str(text).strip()
        if text:
            found.append(Reason(text, norm_reason(text), source, scopes))

    if manual:
        for part in re.split(r"[\n;|]+", str(manual)):
            add(part, "manual", None)
    else:
        for st in script.statements:
            if st.kind in ("SET", "DECLARE") and is_reason_field(st.var_name.split(".")[-1]):
                for v in st.var_strings:
                    add(v, "variable", None)
            for sc in st.scopes:
                for it in sc.items:
                    if is_reason_field(it.alias):
                        for v in _strings_in_item(script, it):
                            add(v, "alias", {sc.id})
                for c in sc.conds:
                    if c.kind == "filter" and c.left is not None and is_reason_field(c.left.name) and \
                            c.op in ("=", "==", "IN", "LIKE", "ILIKE", "<=>"):
                        for tk in range(c.ti, c.tj):
                            t = script.toks[tk]
                            if t.kind == "STR":
                                add(unquote_string(t.text), "predicate", {sc.id})
            # INSERT INTO t (cols) SELECT / VALUES
            if st.kind == "INSERT" and st.root is not None and st.target_columns:
                names = [t.name for t in st.target_columns]
                for k, n in enumerate(names):
                    if is_reason_field(n):
                        for leaf in st.root.leaves():
                            if k < len(leaf.items) and not any(i.is_star for i in leaf.items[:k + 1]):
                                for v in _strings_in_item(script, leaf.items[k]):
                                    add(v, "insert", {leaf.id})
                            if leaf.kind == "values":
                                for row in leaf.values_rows[1:]:
                                    if k < len(row):
                                        for v, _ in row[k].strings:
                                            add(v, "insert", {leaf.id})
        toks = script.toks
        for k in range(len(toks) - 3):
            t = toks[k]
            if t.kind == "STR" and is_reason_field(unquote_string(t.text)) and toks[k + 1].text == "," \
                    and toks[k + 2].kind == "STR":
                add(unquote_string(toks[k + 2].text), "struct", None)
        for cm in script.comments:
            for line in cm.text.splitlines():
                m = _COMMENT_RE.search(line)
                if m:
                    add(m.group(1).strip().rstrip("*/").strip().strip("'\""), "comment", None)
    if any(r.source != "comment" for r in found):          # explicit values outrank comments
        found = [r for r in found if r.source != "comment"]
    # merge duplicates: same reason -> union of scopes (None wins = whole script)
    merged = {}
    for r in found:
        cur = merged.get(r.norm)
        if cur is None:
            merged[r.norm] = Reason(r.text, r.norm, r.source, None if r.scopes is None else set(r.scopes))
        else:
            if cur.scopes is None or r.scopes is None:
                cur.scopes = None
            else:
                cur.scopes |= r.scopes
    return list(merged.values())


def build_model(sql, manual_reason=None, catalog=None):
    script = parse_script(sql)
    model = QueryModel(script, catalog)
    model.reasons = extract_reasons(script, manual_reason)
    return model
