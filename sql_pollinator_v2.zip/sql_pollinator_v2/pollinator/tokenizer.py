"""Lenient Databricks-SQL tokenizer.  It NEVER raises: bad input produces warnings, not exceptions.

Token kinds
  ID    bare word (keyword or identifier; may contain glued $(placeholders))
  QID   `back-quoted identifier`
  STR   'single-quoted string'
  DQ    "double-quoted" (a string in Databricks, an identifier in ANSI mode - the parser decides)
  NUM   number
  OP    operator
  PUNCT ( ) , ; . [ ] { } : @ ?
  EOF
Comments are not tokens; they are returned separately (with positions).
Placeholders  $(a.b)  ${a.b}  {{ a }}  are atomic parts of identifiers, so  $(gold.schema).claims  is
ID('$(gold.schema)') PUNCT('.') ID('claims').
"""
import re
from dataclasses import dataclass


@dataclass(eq=False)
class Tok:
    kind: str
    text: str
    start: int
    end: int
    idx: int = 0

    @property
    def up(self):
        return self.text.upper() if self.kind == "ID" else self.text

    @property
    def name(self):
        """Identifier text without quotes, original case."""
        t = self.text
        if self.kind == "QID":
            return t[1:-1].replace("``", "`") if len(t) >= 2 and t.endswith("`") else t[1:]
        if self.kind == "DQ":
            return t[1:-1] if len(t) >= 2 and t.endswith('"') else t[1:]
        return t

    def is_word(self, *words):
        return self.kind == "ID" and self.text.upper() in words

    def __repr__(self):
        return f"{self.kind}({self.text!r})"


@dataclass
class Comment:
    text: str       # without the comment markers
    start: int
    end: int
    block: bool


_PH = r"(?:\$\([^()\n]+\)|\$\{[^{}\n]+\}|\{\{[^{}\n]+\}\})"
PLACEHOLDER_RE = re.compile(_PH)
_WORDCH = r"[^\W\d]|\d"      # unicode letter/digit/underscore
_ID_RE = re.compile(rf"(?:{_PH}|[^\W\d]|_)(?:{_PH}|\w)*")
_NUM_RE = re.compile(r"(?:0[xX][0-9a-fA-F]+|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)(?:BD|bd|[LlSsYyDdFf])?(?![\w$])")
_DIGITID_RE = re.compile(rf"\d(?:{_PH}|\w)*")
_WS_RE = re.compile(r"\s+")
_OPS = ["<=>", "->>", "->", "=>", "::", "<>", "!=", "<=", ">=", "==", "||", "<<", ">>", "!<", "!>"]
_ONECHAR_OPS = set("+-*/%&|^~=<>!")
_PUNCT = set("(),;.[]{}:@?")
_STR_PREFIX = {"r", "R", "x", "X", "b", "B", "e", "E", "n", "N"}


def tokenize(text):
    """-> (tokens, comments, warnings).  tokens always ends with an EOF token."""
    toks, comments, warns = [], [], []
    i, n = 0, len(text)

    def add(kind, s, e):
        t = Tok(kind, text[s:e], s, e, len(toks))
        toks.append(t)
        return t

    while i < n:
        c = text[i]
        if c.isspace():
            i = _WS_RE.match(text, i).end()
            continue
        # comments -------------------------------------------------------
        if c == "-" and text.startswith("--", i):
            j = text.find("\n", i)
            j = n if j < 0 else j
            comments.append(Comment(text[i + 2:j].rstrip("\r"), i, j, False))
            i = j
            continue
        if c == "/" and text.startswith("/*", i):
            j = text.find("*/", i + 2)
            if j < 0:
                warns.append("Unterminated /* comment")
                comments.append(Comment(text[i + 2:], i, n, True))
                i = n
            else:
                comments.append(Comment(text[i + 2:j], i, j + 2, True))
                i = j + 2
            continue
        # strings --------------------------------------------------------
        if c in "'\"":
            j = _scan_quoted(text, i, c)
            if j < 0:
                warns.append(f"Unterminated string literal starting at offset {i}")
                j = n
            add("STR" if c == "'" else "DQ", i, j)
            i = j
            continue
        if c == "`":
            j = i + 1
            while j < n:
                if text[j] == "`":
                    if j + 1 < n and text[j + 1] == "`":
                        j += 2
                        continue
                    break
                j += 1
            if j >= n:
                warns.append(f"Unterminated `identifier` at offset {i}")
                j = n
            else:
                j += 1
            add("QID", i, j)
            i = j
            continue
        # numbers --------------------------------------------------------
        if c.isdigit() or (c == "." and i + 1 < n and text[i + 1].isdigit()
                           and not (toks and (toks[-1].kind in ("ID", "QID") or toks[-1].text in (")", "]")))):
            m = _NUM_RE.match(text, i)
            if m:
                add("NUM", i, m.end())
                i = m.end()
                continue
            m = _DIGITID_RE.match(text, i)
            if m:
                add("ID", i, m.end())
                i = m.end()
                continue
        # identifiers (with glued placeholders) -------------------------
        m = _ID_RE.match(text, i)
        if m:
            j = m.end()
            word = text[i:j]
            if word in _STR_PREFIX and j < n and text[j] in "'\"":
                k = _scan_quoted(text, j, text[j], raw=word in "rR")
                if k > 0:
                    add("STR", i, k)
                    i = k
                    continue
            add("ID", i, j)
            i = j
            continue
        # operators / punctuation ---------------------------------------
        for op in _OPS:
            if text.startswith(op, i):
                add("OP", i, i + len(op))
                i += len(op)
                break
        else:
            if c in _ONECHAR_OPS:
                add("OP", i, i + 1)
            elif c in _PUNCT:
                add("PUNCT", i, i + 1)
            elif c == "$":      # stray dollar: part of a parameter such as $1 ; treat as identifier char
                m2 = re.compile(r"\$\w*").match(text, i)
                add("ID", i, m2.end())
                i = m2.end()
                continue
            else:
                add("OP", i, i + 1)        # unknown character: keep going
            i += 1
    toks.append(Tok("EOF", "", n, n, len(toks)))
    return toks, comments, warns


def _scan_quoted(text, i, q, raw=False):
    """Index just after the closing quote or -1.  Handles '' doubling and backslash escapes."""
    n, j = len(text), i + 1
    while j < n:
        ch = text[j]
        if ch == "\\" and not raw:
            j += 2
            continue
        if ch == q:
            if j + 1 < n and text[j + 1] == q:
                j += 2
                continue
            return j + 1
        j += 1
    return -1


def unquote_string(tok_text):
    """Value of a string literal token."""
    t = tok_text
    if len(t) >= 2 and t[0] in "rRxXbBeEnN" and t[1] in "'\"":
        t = t[1:]
    if len(t) < 2:
        return t.strip("'\"")
    q = t[0]
    body = t[1:-1] if t.endswith(q) and len(t) >= 2 else t[1:]
    body = body.replace(q * 2, q)
    body = re.sub(r"\\(.)", lambda m: {"n": "\n", "t": "\t"}.get(m.group(1), m.group(1)), body)
    return body
