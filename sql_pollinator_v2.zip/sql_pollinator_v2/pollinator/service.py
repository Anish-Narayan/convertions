"""Orchestration: query splitting, concept pairing by selection reason, analysis of pod pairs, explain view."""
import re

from .analysis import align
from .model import build_model, norm_reason
from .store import SHEETS, fingerprint, norm_name, now, pair_key

HEADER_RE = re.compile(r"^[ \t]*--[ \t]*([A-Za-z0-9_.\- ]{1,80}?)[ \t]*$")
DIVIDER_RE = re.compile(r"^[ \t]*(?:-{4,}|={4,}|#{4,}|\*{4,})[ \t]*$")


def split_queries(text, per_statement=False):
    """Split pasted text into queries.  Separators: '--name' header lines (single comment word/phrase without other
    text before the next SQL), divider lines (----, ====), or (per_statement) every ';'-terminated statement.
    -> [(name, sql)]"""
    text = (text or "").replace("\r\n", "\n")
    if per_statement:
        from .parser import parse_script
        sc = parse_script(text)
        return [(f"statement_{s.index}", s.text) for s in sc.statements if s.text.strip()]
    lines = text.split("\n")
    blocks, cur_name, cur = [], None, []

    def flush():
        body = "\n".join(cur).strip()
        if body and re.search(r"[A-Za-z]", re.sub(r"--[^\n]*", "", body)):
            blocks.append((cur_name, body))

    for i, ln in enumerate(lines):
        m = HEADER_RE.match(ln)
        nxt = next((l for l in lines[i + 1:] if l.strip()), "")
        # a header is a comment-only line directly followed by SQL (not by another comment line)
        if m and nxt and not nxt.lstrip().startswith("--") and not m.group(1).strip().lower().startswith(("selection", "note")) \
                and ":" not in ln and "=" not in ln and (cur_name is None and not "\n".join(cur).strip() or
                                                          "\n".join(cur).strip().rstrip().endswith(";") or
                                                          not "\n".join(cur).strip()):
            flush()
            cur_name, cur = m.group(1).strip().replace(" ", "_"), []
            continue
        if DIVIDER_RE.match(ln):
            flush()
            cur_name, cur = None, []
            continue
        cur.append(ln)
    flush()
    out, used = [], set()
    for k, (n, b) in enumerate(blocks, 1):
        n = n or f"query_{k}"
        base, j = n, 2
        while n.lower() in used:
            n, j = f"{base}_{j}", j + 1
        used.add(n.lower())
        out.append((n, b))
    return out


# ---------------------------------------------------------------------------------------- models / catalog
def build_catalog(queries):
    """table key -> columns seen anywhere (used to place unqualified columns in multi-table queries)."""
    cat = {}
    for q in queries:
        try:
            m = build_model(q["sql"])
        except Exception:      # noqa
            continue
        for i in m.instances:
            for key in (i.key, i.name):
                cat.setdefault(key, set()).update(c for c in i.cols if c != "*")
    return cat


def build_models(queries, catalog=None):
    out = []
    for q in queries:
        try:
            m = build_model(q["sql"], q.get("selection_reason_override") or None, catalog)
        except Exception as e:     # noqa  (never let one query kill an analysis)
            m = None
            q = dict(q, _error=str(e))
        out.append((q, m))
    return out


def reasons_of(m):
    return [] if m is None else m.reasons


def pair_concepts(models_a, models_b):
    """[(qa, ma, qb, mb, reason_text, scopesA, scopesB)] for queries sharing a selection reason (normalised)."""
    merged = {}
    for qa, ma in models_a:
        for ra in reasons_of(ma):
            for qb, mb in models_b:
                for rb in reasons_of(mb):
                    if ra.norm != rb.norm or not ra.norm:
                        continue
                    ka = None if ra.scopes is None else frozenset(ra.scopes)
                    kb = None if rb.scopes is None else frozenset(rb.scopes)
                    key = (qa["query_name"], qb["query_name"], ka, kb)
                    if key in merged:
                        merged[key][4].append(ra.text)
                    else:
                        merged[key] = [qa, ma, qb, mb, [ra.text], ka, kb]
    out = []
    for qa, ma, qb, mb, texts, ka, kb in merged.values():
        out.append((qa, ma, qb, mb, " | ".join(dict.fromkeys(texts)), ka, kb))
    out.sort(key=lambda t: (t[4].lower(), t[0]["query_name"].lower(), t[2]["query_name"].lower()))
    return out


def _cols_text(inst):
    return ", ".join(sorted(c for c in inst.col_names if c != "*"))


def analyze_pair(store, pod_a, pod_b):
    """Analyse two pods and overwrite the stored analysis of this pod pair."""
    pod_a, pod_b = pair_key(pod_a, pod_b)
    if norm_name(pod_a) == norm_name(pod_b):
        raise ValueError("Choose two different pods.")
    qa_all, qb_all = store.queries(pod_a), store.queries(pod_b)
    if not qa_all or not qb_all:
        raise ValueError("Both pods need at least one query.")
    allq = store_all_queries(store)
    catalog = build_catalog(allq)
    ma, mb = build_models(qa_all, catalog), build_models(qb_all, catalog)
    pairs = pair_concepts(ma, mb)
    data = {k: [] for k in ("Concepts", "TableMap", "ColumnMap", "JoinMap", "Unmatched", "Runs")}
    stamp, all_warn = now(), []
    for n, (qa, a, qb, b, reason, ka, kb) in enumerate(pairs, 1):
        cid = f"C{n:03d}"
        al = align(a, ka, b, kb)
        base = {"concept_id": cid, "pod_a": pod_a, "pod_b": pod_b, "selection_reason": reason,
                "query_a": qa["query_name"], "query_b": qb["query_name"]}
        tm = [t for t in al.tables if t.a is not None and t.b is not None]
        ta = sum(1 for t in al.tables if t.a is not None)
        tb = sum(1 for t in al.tables if t.b is not None)
        warns = [f"A: {w}" for w in a.warnings] + [f"B: {w}" for w in b.warnings]
        all_warn += [f"{cid} {w}" for w in warns]
        data["Concepts"].append({**base, "parse_a": a.parse_mode, "parse_b": b.parse_mode, "tables_a": ta,
                                 "tables_b": tb, "tables_matched": len(tm),
                                 "notes": " || ".join(al.notes + warns), "analysed_at": stamp})
        for t in al.tables:
            x, y = t.a, t.b
            data["TableMap"].append({
                **base,
                "table_a": x.raw if x else "", "key_a": x.key if x else "", "alias_a": x.alias if x else "",
                "join_type_a": x.join_type if x else "", "join_a": x.join_text if x else "",
                "cols_a": _cols_text(x) if x else "", "root_a": int(x.is_root) if x else "",
                "table_b": y.raw if y else "", "key_b": y.key if y else "", "alias_b": y.alias if y else "",
                "join_type_b": y.join_type if y else "", "join_b": y.join_text if y else "",
                "cols_b": _cols_text(y) if y else "", "root_b": int(y.is_root) if y else "",
                "confidence": t.confidence, "evidence": "; ".join(t.evidence) if (x and y) else "no counterpart found"})
        for c in al.columns:
            data["ColumnMap"].append({**base, "table_a": c.pair.a.raw, "key_a": c.pair.a.key, "column_a": c.col_a,
                                      "table_b": c.pair.b.raw, "key_b": c.pair.b.key, "column_b": c.col_b,
                                      "usage": c.usage, "confidence": c.confidence, "basis": c.basis})
        for tp, side, col in al.unmatched_cols:
            inst = tp.a if side == "A" else tp.b
            row = {**base, "table_a": tp.a.raw, "key_a": tp.a.key, "table_b": tp.b.raw, "key_b": tp.b.key,
                   "usage": "", "confidence": 0.0}
            if side == "A":
                row.update(column_a=col, column_b="", basis=f"column used only in A ({inst.raw})")
            else:
                row.update(column_a="", column_b=col, basis=f"column used only in B ({inst.raw})")
            data["ColumnMap"].append(row)
        for j in al.joins:
            data["JoinMap"].append({**base, "join_a": j.a_text, "type_a": j.a_type, "join_b": j.b_text,
                                    "type_b": j.b_type, "status": j.status, "note": j.note})
    # reasons present in one pod only
    paired_a = {(p[0]["query_name"], norm_reason(p[4].split(" | ")[0])) for p in pairs}
    ra = {r.norm for _, m in ma for r in reasons_of(m)}
    rb = {r.norm for _, m in mb for r in reasons_of(m)}
    for pod, models, other in ((pod_a, ma, rb), (pod_b, mb, ra)):
        for q, m in models:
            rs = reasons_of(m)
            if not rs:
                data["Unmatched"].append({"pod_a": pod_a, "pod_b": pod_b, "pod": pod, "query": q["query_name"],
                                          "selection_reason": "", "status": "no selection reason found in query"})
            for r in rs:
                if r.norm not in other:
                    data["Unmatched"].append({"pod_a": pod_a, "pod_b": pod_b, "pod": pod, "query": q["query_name"],
                                              "selection_reason": r.text, "status": "reason only in this pod"})
    data["Runs"].append({"pod_a": pod_a, "pod_b": pod_b, "analysed_at": stamp, "hash_a": fingerprint(qa_all),
                         "hash_b": fingerprint(qb_all), "concepts": len(pairs), "warnings": len(all_warn)})
    store.replace_analysis(pod_a, pod_b, data)
    return {"pod_a": pod_a, "pod_b": pod_b, "concepts": len(pairs), "warnings": all_warn[:50],
            "unmatched": len(data["Unmatched"]), "analysed_at": stamp}


def store_all_queries(store):
    return store.queries()


def run_status(store):
    """Per pair: last run + whether the queries changed since (stale)."""
    out = []
    pods = store.pods()
    fp = {p: fingerprint(store.queries(p)) for p in pods}
    for r in store.runs():
        a, b = r["pod_a"], r["pod_b"]
        stale = fp.get(a) != r.get("hash_a") or fp.get(b) != r.get("hash_b")
        out.append({"pod_a": a, "pod_b": b, "analysed_at": r["analysed_at"], "concepts": r["concepts"],
                    "warnings": r["warnings"], "stale": stale})
    return out


def group_analysis(raw):
    """Nest the flat sheets by concept for the UI."""
    concepts = {c["concept_id"]: {**c, "tables": [], "columns": [], "joins": []} for c in raw["Concepts"]}
    for sh, k in (("TableMap", "tables"), ("ColumnMap", "columns"), ("JoinMap", "joins")):
        for r in raw[sh]:
            if r["concept_id"] in concepts:
                concepts[r["concept_id"]][k].append(r)
    return {"concepts": list(concepts.values()), "unmatched": raw["Unmatched"]}


def explain(sql, override=""):
    """'How the tool understood this query' for the UI."""
    m = build_model(sql, override or None)
    inst = [{"table": i.raw, "alias": i.alias, "join": i.join_text, "join_type": i.join_type, "context": i.context,
             "columns": sorted(c for c in i.col_names if c != "*"),
             "filters": [f"{c} {op} {', '.join(v)}" if v else f"{c} {op}" for c, op, v, _ in i.filters]}
            for i in m.instances]
    edges = [f"{e.a.label}.{e.col_a} {e.op} {e.b.label}.{e.col_b}  [{e.join_type}]" for e in m.edges]
    return {"parse_mode": m.parse_mode, "reasons": [{"text": r.text, "source": r.source,
                                                     "scope": "whole query" if r.scopes is None else "one select block"}
                                                    for r in m.reasons],
            "tables": inst, "joins": edges, "warnings": m.warnings, "unresolved_columns": m.unresolved,
            "statements": [{"index": s.index, "kind": s.kind, "mode": s.mode} for s in m.script.statements]}
