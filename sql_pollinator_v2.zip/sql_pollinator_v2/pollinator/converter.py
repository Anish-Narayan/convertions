"""Cross-pollination: rewrite pod-A SQL so it runs on pod B, using what the analysis learned.

The original text is edited IN PLACE (token spans), so formatting, comments, $(placeholders) and everything that is
not mapped stay byte-for-byte identical.  Rules:
  * table instance  -> replacement table chosen per INSTANCE (join type / columns / root-ness) when the analysis saw
                       the same source table playing different roles
  * column          -> replacement column of the chosen table; unqualified columns are placed with the column catalog
  * qualifier       -> alias-less `claims.col` follows the table rename
  * CTE / temp-table outputs keep their old name through an added `AS old_name` (so later references still work)
  * join type       -> optionally aligned with pod B (off by default)
Unmapped tables/columns are left untouched and reported.
"""
from dataclasses import dataclass, field

from .analysis import _jac
from .model import QueryModel
from .parser import parse_script
from .store import norm_name, pair_key
from .tokenizer import tokenize


@dataclass
class ConvertResult:
    sql: str = ""
    ok: bool = True
    changes: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    unmapped_tables: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)


def key_of(raw):
    toks, _, _ = tokenize(str(raw))
    return ".".join(t.name.lower() if t.kind in ("QID", "DQ") else t.text.lower()
                    for t in toks if t.kind in ("ID", "QID", "DQ"))


def last_part(raw):
    toks, _, _ = tokenize(str(raw))
    ids = [t for t in toks if t.kind in ("ID", "QID", "DQ")]
    return ids[-1].text if ids else str(raw)


class KnowledgeBase:
    """Table / column replacements from pod `src` to pod `dst`, learned from the stored analysis (+ overrides)."""

    def __init__(self, store, src, dst):
        self.src, self.dst = src, dst
        self.tables, self.columns, self.catalog = {}, {}, {}
        self.concepts = 0
        raw = store.analysis(src, dst)
        if not raw["Concepts"]:
            self.empty = True
        else:
            self.empty = False
        swap = norm_name(raw["Concepts"][0]["pod_a"]) != norm_name(src) if raw["Concepts"] else False
        self.concepts = len(raw["Concepts"])
        self._tables(raw["TableMap"], swap)
        self._columns(raw["ColumnMap"], swap)
        self._overrides(store.read("Overrides"))

    def _tables(self, rows, swap):
        agg = {}
        for r in rows:
            s, d = ("b", "a") if swap else ("a", "b")
            if not r.get(f"key_{s}") or not r.get(f"key_{d}"):
                continue
            cols = {c.strip() for c in str(r.get(f"cols_{s}", "")).split(",") if c.strip()}
            self.catalog.setdefault(r[f"key_{s}"], set()).update(cols)
            k = (r[f"key_{s}"], r[f"key_{d}"], r.get(f"join_type_{s}", ""), str(r.get(f"root_{s}", "")))
            e = agg.setdefault(k, {"src_key": r[f"key_{s}"], "dst_key": r[f"key_{d}"], "dst_raw": r[f"table_{d}"],
                                   "src_join": r.get(f"join_type_{s}", ""), "dst_join": r.get(f"join_type_{d}", ""),
                                   "src_root": str(r.get(f"root_{s}", "")) == "1", "src_cols": set(), "conf": [], "n": 0})
            e["src_cols"] |= cols
            e["conf"].append(float(r.get("confidence") or 0))
            e["n"] += 1
        for e in agg.values():
            e["conf"] = sum(e["conf"]) / len(e["conf"])
            self.tables.setdefault(e["src_key"], []).append(e)

    def _columns(self, rows, swap):
        agg = {}
        for r in rows:
            s, d = ("b", "a") if swap else ("a", "b")
            sc, dc = r.get(f"column_{s}"), r.get(f"column_{d}")
            if not sc:
                continue
            self.catalog.setdefault(r[f"key_{s}"], set()).add(str(sc).lower())
            if not dc:
                continue
            k = (r[f"key_{s}"], str(sc).lower(), r[f"key_{d}"], str(dc))
            e = agg.setdefault(k, {"conf": [], "n": 0})
            e["conf"].append(float(r.get("confidence") or 0))
            e["n"] += 1
        for (sk, sc, dk, dc), e in agg.items():
            self.columns.setdefault((sk, sc), []).append({"dst_key": dk, "dst_col": dc, "conf": sum(e["conf"]) / len(e["conf"]),
                                                         "n": e["n"]})

    def _overrides(self, rows):
        for r in rows:
            fwd = norm_name(r.get("pod_from")) == norm_name(self.src) and norm_name(r.get("pod_to")) == norm_name(self.dst)
            bwd = norm_name(r.get("pod_from")) == norm_name(self.dst) and norm_name(r.get("pod_to")) == norm_name(self.src)
            if not (fwd or bwd):
                continue
            st, sc, dt, dc = (r.get("source_table"), r.get("source_column"), r.get("target_table"), r.get("target_column"))
            if bwd:
                st, sc, dt, dc = dt, dc, st, sc
            if not st:
                continue
            self.empty = False
            if str(r.get("kind", "")).lower() == "column" and sc and dc:
                self.columns.setdefault((key_of(st), str(sc).lower()), []).insert(
                    0, {"dst_key": key_of(dt) if dt else "", "dst_col": str(dc), "conf": 2.0, "n": 99})
            elif dt:
                self.tables.setdefault(key_of(st), []).insert(
                    0, {"src_key": key_of(st), "dst_key": key_of(dt), "dst_raw": str(dt), "src_join": "", "dst_join": "",
                        "src_root": False, "src_cols": set(), "conf": 2.0, "n": 99, "override": True})

    # -- lookups
    def candidates(self, key):
        if key in self.tables:
            return self.tables[key]
        short = key.split(".")[-1]
        hits = [k for k in self.tables if k.split(".")[-1] == short]
        if len(hits) == 1:
            return self.tables[hits[0]]
        return []

    def pick(self, inst):
        cands = self.candidates(inst.key)
        if not cands:
            return None, []
        cols = {c for c in inst.col_names if c != "*"}
        scored = []
        for c in cands:
            s = c["conf"] + 0.05 * min(c["n"], 5)
            if c.get("override"):
                s += 10
            else:
                s += 0.35 * (c["src_join"] == inst.join_type) + 0.15 * (c["src_root"] == inst.is_root)
                s += 0.5 * _jac(cols, c["src_cols"]) if c["src_cols"] else 0
            scored.append((s, c))
        scored.sort(key=lambda t: -t[0])
        best = scored[0][1]
        alts = {c["dst_key"] for s, c in scored[1:] if c["dst_key"] != best["dst_key"]}
        return best, sorted(alts)

    def column(self, src_key, col, dst_key):
        cands = self.columns.get((src_key, col))
        if cands is None:
            short = src_key.split(".")[-1]
            for (k, c), v in self.columns.items():
                if c == col and k.split(".")[-1] == short:
                    cands = v
                    break
        if not cands:
            return None
        pool = [c for c in cands if c["dst_key"] == dst_key] or ([c for c in cands if not c["dst_key"]] or [])
        if not pool:
            pool = [c for c in cands if c["dst_key"].split(".")[-1] == dst_key.split(".")[-1]]
        if not pool:
            return None
        return max(pool, key=lambda c: (c["conf"], c["n"]))


def convert(sql, kb, align_join_types=False, keep_final_names=False):
    res = ConvertResult()
    script = parse_script(sql)
    model = QueryModel(script, kb.catalog)
    text = script.text
    edits = []                   # (start, end, replacement, description)
    for w in model.warnings:
        res.warnings.append(w)
    if kb.empty:
        res.ok = False
        res.warnings.append(f"No analysis found between '{kb.src}' and '{kb.dst}'. Run Analyze first.")
        res.sql = sql
        return res

    chosen = {}                                       # Instance -> kb row
    unmapped = {}
    for inst in model.instances:
        row, alts = kb.pick(inst)
        if row is None:
            unmapped.setdefault(inst.key, inst.raw)
            continue
        chosen[id(inst)] = row
        if alts:
            res.warnings.append(f"{inst.raw} maps to {row['dst_raw']} here, but '{kb.src}'->'{kb.dst}' also saw "
                                f"{', '.join(alts)} for it in other roles; chosen by join type/columns.")
        tn = inst.source.table
        if row["dst_raw"] and tn.raw(text) != row["dst_raw"]:
            edits.append((tn.start, tn.end, row["dst_raw"], f"table {inst.raw} -> {row['dst_raw']}"))
        if align_join_types and row["dst_join"] and row["src_join"] and row["dst_join"] != row["src_join"] \
                and row["src_join"] == inst.join_type and inst.source.join_ti > 0 and inst.join_type != "FROM":
            toks = script.toks
            j = inst.source.join_ti
            k = j
            while k - 1 >= 0 and toks[k - 1].kind == "ID" and toks[k - 1].text.upper() in (
                    "NATURAL", "INNER", "CROSS", "LEFT", "RIGHT", "FULL", "OUTER", "SEMI", "ANTI"):
                k -= 1
            if toks[j].is_word("JOIN"):
                edits.append((toks[k].start, toks[j].end, f"{row['dst_join']} JOIN",
                              f"join type {inst.join_type} -> {row['dst_join']} for {inst.raw}"))
        # qualifier without alias:  claims.col
    res.unmapped_tables = sorted(unmapped.values())
    for name in res.unmapped_tables:
        res.warnings.append(f"Table {name} has no mapping from '{kb.src}' to '{kb.dst}' - left unchanged.")

    for st in script.statements:
        for sc in st.scopes:
            for r in sc.refs:
                _column_edit(r, sc, st, model, kb, chosen, edits, res, text, keep_final_names)
    # table-name qualifiers for alias-less instances
    for inst in model.instances:
        row = chosen.get(id(inst))
        if row is None or inst.alias or not row["dst_raw"]:
            continue
        for r in inst.source.scope.refs:
            if r.source is inst.source and r.qualifier_toks:
                qs, qe = r.qualifier_toks[0].start, r.qualifier_toks[-1].end
                newq = row["dst_raw"] if len(r.qualifier_toks) > 1 else last_part(row["dst_raw"])
                if text[qs:qe] != newq:
                    edits.append((qs, qe, newq, f"qualifier {text[qs:qe]} -> {newq}"))
    # apply
    edits.sort(key=lambda e: (e[0], e[1]))
    clean, last_end = [], -1
    for e in edits:
        if e[0] < last_end:
            res.warnings.append(f"Skipped an overlapping edit ({e[3]}).")
            continue
        clean.append(e)
        last_end = max(last_end, e[1])
    out = text
    for s, e, rep, _ in sorted(clean, key=lambda x: -x[0]):
        out = out[:s] + rep + out[e:]
    res.sql = out
    counts = {}
    for c in clean:
        counts[c[3]] = counts.get(c[3], 0) + 1
    res.changes = [d + (f"  (x{n})" if n > 1 else "") for d, n in counts.items()]
    res.stats = {"tables_replaced": sum(1 for c in clean if c[3].startswith("table")),
                 "columns_replaced": sum(1 for c in clean if c[3].startswith("column")),
                 "aliases_added": sum(1 for c in clean if c[3].startswith("alias")),
                 "unmapped_tables": len(res.unmapped_tables)}
    if any(s.mode != "full" for s in script.statements if s.kind not in ("SET", "DECLARE", "EMPTY")):
        res.warnings.append("Some statements could not be fully parsed or are of a kind that is not converted; "
                            "check them manually (they are kept verbatim).")
    res.warnings = list(dict.fromkeys(res.warnings))
    return res


def _column_edit(r, scope, st, model, kb, chosen, edits, res, text, keep_final):
    if r.status in ("alias", "star", "unresolved") or r.name_tok is None:
        if r.status == "unresolved" and r.kind == "column":
            res.warnings.append(f"Column '{'.'.join(t.text for t in r.parts)}' could not be attributed to a table - unchanged.")
        return
    src = r.source
    if r.status == "ambiguous" and src is None:
        src = model._by_catalog(r)
        if src is None:
            # all candidate tables map this column the same way?
            targets = set()
            for c in r.candidates:
                inst = model.inst_of.get(c.id)
                row = chosen.get(id(inst)) if inst else None
                if inst is None or row is None:
                    targets = None
                    break
                m = kb.column(inst.key, r.name, row["dst_key"])
                targets.add(m["dst_col"] if m else r.name)
            if targets and len(targets) == 1 and next(iter(targets)) != r.name:
                new = next(iter(targets))
                edits.append((r.name_tok.start, r.name_tok.end, new, f"column {r.name} -> {new} (unqualified)"))
            elif targets is None or len(targets) > 1:
                res.warnings.append(f"Unqualified column '{r.name}' could be from several tables - qualify it with an alias; unchanged.")
            return
    if src is None or src.kind != "table":
        return
    inst = model.inst_of.get(src.id)
    row = chosen.get(id(inst)) if inst is not None else None
    if row is None:
        return
    if r.kind == "using":
        _using_edit(r, scope, model, kb, chosen, edits, res)
        return
    m = kb.column(inst.key, r.name, row["dst_key"])
    if m is None:
        if r.name != "*":
            res.warnings.append(f"Column {inst.raw}.{r.name} has no mapping in '{kb.dst}' - left unchanged.")
        return
    new = m["dst_col"]
    if new.lower() == r.name and text[r.name_tok.start:r.name_tok.end].strip("`\"").lower() == new.lower():
        return
    tok = r.name_tok
    edits.append((tok.start, tok.end, new, f"column {inst.raw}.{r.name} -> {new}"))
    it = r.item
    if it is not None and it.simple_ref is r and not it.alias and r.kind == "column" and r.clause == "select":
        final = st.kind == "SELECT" and scope.query.kind == "root"
        if not final or keep_final:
            old = text[tok.start:tok.end]
            end = r.parts[-1].end
            edits.append((end, end, f" AS {old}", f"alias keeps output name {old}"))


def _using_edit(r, scope, model, kb, chosen, edits, res):
    s = r.source
    prev = scope.sources[s.order - 1] if s.order > 0 else None
    inst = model.inst_of.get(s.id)
    pinst = model.inst_of.get(prev.id) if prev is not None else None
    if inst is None or pinst is None or id(pinst) not in chosen:
        res.warnings.append(f"JOIN ... USING ({r.name}) involves a derived table; check the column name manually.")
        return
    a = kb.column(inst.key, r.name, chosen[id(inst)]["dst_key"])
    b = kb.column(pinst.key, r.name, chosen[id(pinst)]["dst_key"])
    na, nb = (a["dst_col"] if a else r.name), (b["dst_col"] if b else r.name)
    if na.lower() == nb.lower():
        if na.lower() != r.name:
            edits.append((r.name_tok.start, r.name_tok.end, na, f"column USING({r.name}) -> {na}"))
    else:
        res.warnings.append(f"JOIN ... USING ({r.name}): the column is called '{nb}' on one side and '{na}' on the other in "
                            f"'{kb.dst}'. Rewrite it as ON a.{nb} = b.{na}.")


def convert_many(store, src, dst, queries, **opts):
    kb = KnowledgeBase(store, src, dst)
    return [(name, convert(sql, kb, **opts)) for name, sql in queries]
