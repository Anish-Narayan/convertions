"""Builds examples/sample_pod_data.xlsx : 3 pods, several concepts, already analysed.  Run:  python examples/make_sample.py"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pollinator.store import Store
from pollinator import service

path = os.path.join(os.path.dirname(__file__), "sample_pod_data.xlsx")
if os.path.exists(path):
    os.remove(path)
st = Store(path)
Q = {
"Pod_Alpha": {
 "diabetes": """-- selectionreason: Diabetes with complications
SELECT m.member_id, c.claim_amount, 'Diabetes with complications' AS selectionreason
FROM $(gold.schema).members m
INNER JOIN $(gold.schema).claims c ON c.member_id = m.member_id AND c.dx_code IN ('E11.65','E11.9')
INNER JOIN $(gold.schema).claims c2 ON c2.member_id = m.member_id AND c2.proc_code = '99213'
WHERE c.service_date >= '2024-01-01'""",
 "asthma": """WITH asthma_dx AS (
  SELECT d.member_id, d.service_date FROM $(gold.schema).claims d WHERE d.dx_code LIKE 'J45%'
)
SELECT a.member_id, p.provider_name, 'Asthma' AS selectionreason
FROM asthma_dx a LEFT JOIN $(gold.schema).providers p ON p.member_id = a.member_id""",
 "only_alpha": "SELECT x.id, 'Hypertension' AS selectionreason FROM $(gold.schema).bp x",
},
"Pod_Beta": {
 "diabetes_b": """SELECT p.patient_id, e.paid_amount, 'diabetes with complications' AS selection_reason
FROM $(silver.schema).patients p
LEFT JOIN $(silver.schema).encounters e ON e.patient_id = p.patient_id AND e.dx_code IN ('E11.65','E11.9')
LEFT JOIN $(silver.schema).encounter_procs x ON x.patient_id = p.patient_id AND x.proc_code = '99213'
WHERE e.service_date >= '2024-01-01'""",
 "asthma_b": """-- selectionreason: ASTHMA
CREATE OR REPLACE TEMP VIEW dx AS SELECT d.patient_id, d.service_date FROM $(silver.schema).encounters d WHERE d.dx_code LIKE 'J45%';
SELECT dx.patient_id, pr.name FROM dx JOIN $(silver.schema).practitioners pr ON pr.patient_id = dx.patient_id""",
},
"Pod_Gamma": {
 "dm": "SELECT a.mbr, a.amt, 'Diabetes with complications' AS selectionreason FROM $(prod.schema).mbr_claims a WHERE a.dx IN ('E11.65','E11.9')",
},
}
for pod, qs in Q.items():
    st.add_pod(pod)
    for n, s in qs.items():
        st.upsert_query(pod, n, s)
service.analyze_pair(st, "Pod_Alpha", "Pod_Beta")
service.analyze_pair(st, "Pod_Alpha", "Pod_Gamma")
print("written", path)
