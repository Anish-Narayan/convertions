import os, sys, tempfile, unittest, random
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pollinator.parser import parse_script
from pollinator.model import build_model, norm_reason
from pollinator.analysis import align, name_sim
from pollinator.store import Store
from pollinator import service
from pollinator.converter import KnowledgeBase, convert


def tables(sql):
    m = build_model(sql)
    return [(i.key, i.alias, i.join_type) for i in m.instances]


class Parser(unittest.TestCase):
    def test_placeholders_and_joins(self):
        t = tables("SELECT 1 FROM $(gold.schema).claims a LEFT JOIN $(gold.schema).providers p ON a.x=p.x "
                   "INNER JOIN $(env)_t t ON t.k=a.k JOIN claims_${env} d ON d.k=a.k")
        self.assertEqual(t, [("$(gold.schema).claims", "a", "FROM"), ("$(gold.schema).providers", "p", "LEFT"),
                             ("$(env)_t", "t", "INNER"), ("claims_${env}", "d", "INNER")])

    def test_case_insensitive_keys(self):
        self.assertEqual(tables("select 1 from Cat.Sch.CLAIMS A")[0][0], "cat.sch.claims")

    def test_join_variants(self):
        t = [x[2] for x in tables("SELECT 1 FROM a LEFT OUTER JOIN b ON 1=1 RIGHT JOIN c ON 1=1 FULL OUTER JOIN d ON 1=1 "
                                  "CROSS JOIN e LEFT SEMI JOIN f ON 1=1 LEFT ANTI JOIN g ON 1=1, h")]
        self.assertEqual(t, ["FROM", "LEFT", "RIGHT", "FULL", "CROSS", "LEFT SEMI", "LEFT ANTI", "COMMA"])

    def test_cte_and_internal_tables_are_not_physical(self):
        m = build_model("CREATE TEMP VIEW v AS SELECT * FROM x.a; WITH c AS (SELECT * FROM x.b) "
                        "SELECT * FROM c JOIN v ON c.i=v.i JOIN x.d ON d.i=c.i")
        self.assertEqual(sorted(i.key for i in m.instances), ["x.a", "x.b", "x.d"])

    def test_cte_shadowing_physical_table(self):
        m = build_model("WITH claims AS (SELECT * FROM claims) SELECT * FROM claims")
        self.assertEqual([i.key for i in m.instances], ["claims"])

    def test_lineage_through_cte(self):
        m = build_model("WITH c AS (SELECT a.id AS k FROM t a) SELECT 1 FROM c JOIN u ON u.k = c.k")
        e = m.edges[0]
        self.assertEqual({(e.a.key, e.col_a), (e.b.key, e.col_b)}, {("t", "id"), ("u", "k")})

    def test_or_condition_is_not_a_join(self):
        m = build_model("SELECT 1 FROM a JOIN b ON (a.x=b.x OR a.y=b.y) AND b.z=3")
        self.assertTrue(all(e.kind == "complex" for e in m.edges))
        self.assertEqual(m.instances[1].filters[0][:3], ("z", "=", ("3",)))

    def test_functions_keywords_not_columns(self):
        m = build_model("SELECT extract(YEAR FROM t.d), date_add(day, 1, t.e), INTERVAL 1 DAY, CAST(t.f AS decimal(10,2)), "
                        "x -> 1, transform(t.arr, x -> x + t.k), count(DISTINCT t.id) FILTER (WHERE t.g=1), ${v}, :p, "
                        "row_number() OVER (PARTITION BY t.h ORDER BY t.i DESC NULLS LAST) FROM tbl t")
        self.assertEqual(sorted(m.instances[0].cols), ["arr", "d", "e", "f", "g", "h", "i", "id", "k"])

    def test_unqualified_in_single_table(self):
        m = build_model("SELECT a, b FROM t WHERE c = 1")
        self.assertEqual(sorted(m.instances[0].cols), ["a", "b", "c"])

    def test_set_ops_and_subqueries(self):
        t = tables("SELECT 1 FROM a UNION ALL SELECT 2 FROM b WHERE b.x IN (SELECT y FROM c) AND EXISTS (SELECT 1 FROM d)")
        self.assertEqual([x[0] for x in t], ["a", "b", "c", "d"])

    def test_dml(self):
        self.assertEqual([x[0] for x in tables("MERGE INTO t USING s ON t.i=s.i WHEN MATCHED THEN UPDATE SET t.a=s.a")], ["t", "s"])
        self.assertEqual([x[0] for x in tables("DELETE FROM t WHERE id IN (SELECT id FROM s)")], ["t", "s"])
        self.assertEqual([x[0] for x in tables("UPDATE t SET a=1 WHERE b=2")], ["t"])
        self.assertEqual([x[0] for x in tables("INSERT INTO o (a) SELECT x FROM s")], ["s"])

    def test_backticks_quotes_comments(self):
        t = tables("SELECT 'FROM fake' AS x, `a b`.c FROM `my cat`.`sch`.`tbl 1` `a b` -- FROM nothing\n /* JOIN zzz */")
        self.assertEqual(t, [("my cat.sch.tbl 1", "a b", "FROM")])

    def test_fallback_on_broken_sql(self):
        s = parse_script("SELECT a.x FROM t1 a JOIN t2 b ON a.i=b.i WHERE (((")
        self.assertEqual(s.statements[0].mode, "fallback")
        m = build_model("SELECT a.x FROM t1 a JOIN t2 b ON a.i=b.i WHERE (((")
        self.assertEqual([i.key for i in m.instances], ["t1", "t2"])
        self.assertEqual(m.parse_mode, "fallback")

    def test_never_raises_on_garbage(self):
        random.seed(7)
        chars = list("()'\";,.`$-/*{}[]:<>= \nSELECTFROMJOINWHEREONASCASEEND")
        for _ in range(500):
            txt = "".join(random.choice(chars) for _ in range(random.randint(0, 80)))
            build_model(txt)

    def test_unterminated_string_comment(self):
        self.assertTrue(parse_script("SELECT 'abc FROM t").warnings)
        build_model("SELECT 1 /* open")


class Reasons(unittest.TestCase):
    def reasons(self, sql, manual=None):
        return sorted((r.norm, r.source) for r in build_model(sql, manual).reasons)

    def test_alias_case_insensitive_and_underscore(self):
        self.assertEqual(self.reasons("SELECT 'Diabetes Care' AS SelectionReason FROM t"), [("diabetes care", "alias")])
        self.assertEqual(self.reasons("SELECT 'x' AS selection_reason FROM t"), [("x", "alias")])

    def test_case_expression_only_values(self):
        r = self.reasons("SELECT CASE WHEN t.a='cond' THEN 'one' ELSE 'two' END AS selectionreason FROM t")
        self.assertEqual(r, [("one", "alias"), ("two", "alias")])

    def test_union_branches_have_own_scope(self):
        m = build_model("SELECT 'A1' AS selectionreason FROM t1 UNION ALL SELECT 'B1' AS selectionreason FROM t2")
        by = {r.norm: r for r in m.reasons}
        self.assertEqual(len(m.select_instances(by["a1"].scopes)), 1)
        self.assertEqual(m.select_instances(by["a1"].scopes)[0].key, "t1")

    def test_predicate_variable_insert_comment_struct(self):
        self.assertEqual(self.reasons("SELECT 1 FROM t WHERE selectionreason IN ('a','b')"), [("a", "predicate"), ("b", "predicate")])
        self.assertEqual(self.reasons("SET selectionreason = 'Foo'; SELECT 1"), [("foo", "variable")])
        self.assertEqual(self.reasons("INSERT INTO o (id, SelectionReason) SELECT x, 'Z' FROM t"), [("z", "insert")])
        self.assertEqual(self.reasons("-- Selection Reason: Asthma\nSELECT 1"), [("asthma", "comment")])
        self.assertEqual(self.reasons("SELECT named_struct('selectionreason', 'Q') FROM t"), [("q", "struct")])

    def test_manual_override_wins_and_normalisation(self):
        self.assertEqual(self.reasons("SELECT 'x' AS selectionreason FROM t", "A; B"), [("a", "manual"), ("b", "manual")])
        self.assertEqual(norm_reason("  Type-2  Diabetes! "), norm_reason("type 2 diabetes"))


class Analysis(unittest.TestCase):
    def test_names(self):
        self.assertGreater(name_sim("claims", "claim_header"), 0.5)
        self.assertEqual(name_sim("A", "a"), 1.0)

    def test_replacement_and_duplicate_pattern(self):
        a = build_model("SELECT 1 FROM g.members m JOIN g.claims c ON c.member_id=m.member_id AND c.dx IN ('E11') "
                        "JOIN g.claims c2 ON c2.member_id=m.member_id")
        b = build_model("SELECT 1 FROM s.patients p LEFT JOIN s.encounters e ON e.pt_id=p.pt_id AND e.dx IN ('E11') "
                        "LEFT JOIN s.encounter_dx x ON x.pt_id=p.pt_id")
        r = align(a, None, b, None)
        pairs = {(t.a.key, t.b.key) for t in r.tables if t.a and t.b}
        self.assertEqual(pairs, {("g.members", "s.patients"), ("g.claims", "s.encounters"), ("g.claims", "s.encounter_dx")})
        self.assertTrue(any("2x" in n for n in r.notes))
        self.assertTrue(any(j.status == "join type differs" for j in r.joins))
        cols = {(c.col_a, c.col_b) for c in r.columns}
        self.assertIn(("member_id", "pt_id"), cols)


class EndToEnd(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.st = Store(os.path.join(self.dir, "d.xlsx"))
        self.st.add_pod("A"); self.st.add_pod("B")
        self.st.upsert_query("A", "q", "SELECT a.member_id, a.claim_amount, p.provider_name, 'Dx' AS selectionreason "
                             "FROM $(gold.schema).claims a INNER JOIN $(gold.schema).providers p ON a.provider_id=p.provider_id "
                             "WHERE a.service_date >= '2024-01-01'")
        self.st.upsert_query("B", "q", "SELECT h.beneficiary_id, h.allowed_amount, m.provider_name, 'dx' AS selection_reason "
                             "FROM $(silver.schema).claim_header h LEFT JOIN $(silver.schema).provider_master m "
                             "ON h.provider_key=m.provider_key WHERE h.date_of_service >= '2024-01-01'")

    def test_analyze_overwrites_and_flags_stale(self):
        r = service.analyze_pair(self.st, "B", "A")
        self.assertEqual(r["concepts"], 1)
        service.analyze_pair(self.st, "A", "B")
        self.assertEqual(len(self.st.read("Concepts")), 1)             # overwritten, not appended
        self.assertFalse(service.run_status(self.st)[0]["stale"])
        self.st.upsert_query("A", "q", "SELECT 1 FROM t")
        self.assertTrue(service.run_status(self.st)[0]["stale"])

    def test_convert_both_directions_preserves_text(self):
        service.analyze_pair(self.st, "A", "B")
        kb = KnowledgeBase(self.st, "A", "B")
        src = "SELECT a.member_id, a.claim_amount -- keep me\nFROM $(gold.schema).claims a\n  JOIN $(gold.schema).providers p ON a.provider_id = p.provider_id\nWHERE A.SERVICE_DATE > '2024-02-02'"
        r = convert(src, kb, align_join_types=True)
        self.assertEqual(r.sql, "SELECT a.beneficiary_id, a.allowed_amount -- keep me\nFROM $(silver.schema).claim_header a\n"
                                "  LEFT JOIN $(silver.schema).provider_master p ON a.provider_key = p.provider_key\n"
                                "WHERE A.date_of_service > '2024-02-02'")
        back = convert("SELECT h.beneficiary_id FROM $(silver.schema).claim_header h", KnowledgeBase(self.st, "B", "A"))
        self.assertEqual(back.sql, "SELECT h.member_id FROM $(gold.schema).claims h")

    def test_cte_keeps_output_names_and_unqualified(self):
        service.analyze_pair(self.st, "A", "B")
        kb = KnowledgeBase(self.st, "A", "B")
        r = convert("WITH x AS (SELECT a.member_id FROM $(gold.schema).claims a) SELECT x.member_id FROM x", kb)
        self.assertEqual(r.sql, "WITH x AS (SELECT a.beneficiary_id AS member_id FROM $(silver.schema).claim_header a) SELECT x.member_id FROM x")
        r = convert("SELECT claims.member_id FROM $(gold.schema).claims WHERE claim_amount > 5", kb)
        self.assertEqual(r.sql, "SELECT claim_header.beneficiary_id FROM $(silver.schema).claim_header WHERE allowed_amount > 5")

    def test_unmapped_and_no_analysis(self):
        service.analyze_pair(self.st, "A", "B")
        r = convert("SELECT * FROM $(gold.schema).other o", KnowledgeBase(self.st, "A", "B"))
        self.assertIn("$(gold.schema).other", r.unmapped_tables)
        self.st.add_pod("C")
        self.assertFalse(convert("SELECT 1 FROM t", KnowledgeBase(self.st, "A", "C")).ok)

    def test_override(self):
        service.analyze_pair(self.st, "A", "B")
        self.st.add_override({"pod_from": "A", "pod_to": "B", "kind": "table", "source_table": "$(gold.schema).other",
                              "target_table": "$(silver.schema).misc"})
        r = convert("SELECT 1 FROM $(gold.schema).Other o", KnowledgeBase(self.st, "A", "B"))
        self.assertEqual(r.sql, "SELECT 1 FROM $(silver.schema).misc o")

    def test_long_sql_roundtrip_and_rename_delete(self):
        big = "SELECT " + ", ".join(f"c{i}" for i in range(9000)) + " FROM t"
        self.st.upsert_query("A", "big", big)
        self.assertEqual([q for q in self.st.queries("A") if q["query_name"] == "big"][0]["sql"], big)
        self.st.rename_pod("A", "Alpha")
        self.assertIn("Alpha", self.st.pods())
        self.st.delete_pod("Alpha")
        self.assertEqual(self.st.queries("Alpha"), [])

    def test_split_queries(self):
        self.assertEqual([n for n, _ in service.split_queries("--q1\nSELECT 1;\n--q2\nSELECT 2")], ["q1", "q2"])
        self.assertEqual(len(service.split_queries("SELECT 1\n-----\nSELECT 2")), 2)
        self.assertEqual(len(service.split_queries("-- selectionreason: x\nSELECT 1")), 1)

    def test_api(self):
        from app import create_app
        c = create_app(os.path.join(self.dir, "api.xlsx")).test_client()
        self.assertEqual(c.post("/api/pods", json={"name": "P"}).status_code, 200)
        self.assertEqual(c.post("/api/pods", json={"name": "p"}).status_code, 400)
        self.assertEqual(c.post("/api/analyze", json={"pod_a": "P", "pod_b": "P"}).status_code, 400)
        self.assertEqual(c.get("/").status_code, 200)


if __name__ == "__main__":
    unittest.main()
