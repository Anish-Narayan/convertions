"""Pod cross-pollination tool - local web UI.   python app.py [--data pod_data.xlsx] [--port 8765]"""
import argparse
import os
import sys
import threading
import traceback
import webbrowser

from flask import Flask, jsonify, request, send_file, send_from_directory

from pollinator import service
from pollinator.converter import KnowledgeBase, convert
from pollinator.model import build_model
from pollinator.store import Store, StoreError, norm_name


def resource_dir():
    return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))


def create_app(data_path):
    app = Flask(__name__, static_folder=None)
    store = Store(data_path)

    def err(msg, code=400):
        return jsonify({"error": str(msg)}), code

    @app.errorhandler(StoreError)
    def _se(e):
        return err(e)

    @app.errorhandler(ValueError)
    def _ve(e):
        return err(e)

    @app.errorhandler(Exception)
    def _ex(e):
        traceback.print_exc()
        return err(f"Unexpected error: {type(e).__name__}: {e}", 500)

    @app.get("/")
    def index():
        return send_from_directory(os.path.join(resource_dir(), "web"), "index.html")

    @app.get("/api/state")
    def state():
        qs = store.queries()
        counts = {}
        for q in qs:
            counts[norm_name(q["pod"])] = counts.get(norm_name(q["pod"]), 0) + 1
        return jsonify({"pods": [{"name": p, "queries": counts.get(norm_name(p), 0)} for p in store.pods()],
                        "runs": service.run_status(store), "data_path": store.path})

    @app.post("/api/pods")
    def add_pod():
        return jsonify({"name": store.add_pod((request.json or {}).get("name"))})

    @app.put("/api/pods/<name>")
    def rename_pod(name):
        store.rename_pod(name, (request.json or {}).get("new_name"))
        return jsonify({"ok": True})

    @app.delete("/api/pods/<name>")
    def del_pod(name):
        store.delete_pod(name)
        return jsonify({"ok": True})

    @app.get("/api/queries")
    def queries():
        pod = request.args.get("pod", "")
        out = []
        catalog = service.build_catalog(store.queries())
        for q in store.queries(pod):
            try:
                m = build_model(q["sql"], q["selection_reason_override"] or None, catalog)
                info = {"reasons": [{"text": r.text, "source": r.source} for r in m.reasons],
                        "parse_mode": m.parse_mode, "warnings": len(m.warnings), "tables": len({i.key for i in m.instances})}
            except Exception as e:      # noqa
                info = {"reasons": [], "parse_mode": "error", "warnings": 1, "tables": 0, "error": str(e)}
            out.append({**q, **info})
        return jsonify(out)

    @app.post("/api/queries")
    def save_query():
        d = request.json or {}
        pod, sql = d.get("pod"), d.get("sql", "")
        if d.get("split") and not d.get("old_name"):
            items = service.split_queries(sql, per_statement=d.get("per_statement", False))
            if not items:
                raise ValueError("No SQL found.")
            names = [store.upsert_query(pod, n, s, d.get("override", "")) for n, s in items]
            return jsonify({"names": names})
        return jsonify({"names": [store.upsert_query(pod, d.get("name"), sql, d.get("override", ""), d.get("old_name"))]})

    @app.delete("/api/queries")
    def del_query():
        store.delete_query(request.args.get("pod", ""), request.args.get("name", ""))
        return jsonify({"ok": True})

    @app.post("/api/explain")
    def explain():
        d = request.json or {}
        return jsonify(service.explain(d.get("sql", ""), d.get("override", "")))

    @app.post("/api/analyze")
    def analyze():
        d = request.json or {}
        return jsonify(service.analyze_pair(store, d.get("pod_a"), d.get("pod_b")))

    @app.post("/api/analyze_all")
    def analyze_all():
        pods = [p for p in store.pods() if store.queries(p)]
        out, skipped = [], []
        for i in range(len(pods)):
            for j in range(i + 1, len(pods)):
                out.append(service.analyze_pair(store, pods[i], pods[j]))
        return jsonify({"results": out, "pairs": len(out), "skipped": skipped})

    @app.get("/api/analysis")
    def analysis():
        a, b = request.args.get("pod_a", ""), request.args.get("pod_b", "")
        res = service.group_analysis(store.analysis(a, b))
        st = [r for r in service.run_status(store)
              if {norm_name(r["pod_a"]), norm_name(r["pod_b"])} == {norm_name(a), norm_name(b)}]
        res["status"] = st[0] if st else None
        return jsonify(res)

    @app.post("/api/convert")
    def do_convert():
        d = request.json or {}
        src, dst = d.get("from_pod"), d.get("to_pod")
        if not src or not dst or norm_name(src) == norm_name(dst):
            raise ValueError("Choose two different pods.")
        text = d.get("text", "")
        if not text.strip():
            raise ValueError("Paste at least one query.")
        mode = d.get("split_mode", "auto")
        items = service.split_queries(text, per_statement=(mode == "statement")) if mode != "single" else [("query_1", text.strip())]
        kb = KnowledgeBase(store, src, dst)
        results = []
        for name, sql in items:
            r = convert(sql, kb, align_join_types=bool(d.get("align_join_types")),
                        keep_final_names=bool(d.get("keep_final_names")))
            results.append({"name": name, "sql": r.sql, "ok": r.ok, "changes": r.changes, "warnings": r.warnings,
                            "stats": r.stats, "unmapped_tables": r.unmapped_tables})
        return jsonify({"results": results})

    @app.get("/api/overrides")
    def overrides():
        return jsonify([{**r, "index": i} for i, r in enumerate(store.read("Overrides"))])

    @app.post("/api/overrides")
    def add_override():
        d = request.json or {}
        if not d.get("pod_from") or not d.get("pod_to") or not d.get("source_table"):
            raise ValueError("pod_from, pod_to and source_table are required.")
        if d.get("kind") == "column" and not (d.get("source_column") and d.get("target_column")):
            raise ValueError("Column overrides need source and target column.")
        if d.get("kind") != "column" and not d.get("target_table"):
            raise ValueError("Table overrides need a target table.")
        store.add_override(d)
        return jsonify({"ok": True})

    @app.delete("/api/overrides/<int:i>")
    def del_override(i):
        store.delete_override(i)
        return jsonify({"ok": True})

    @app.get("/api/download")
    def download():
        return send_file(store.path, as_attachment=True, download_name=os.path.basename(store.path))

    return app


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", default=os.path.join(os.path.dirname(os.path.abspath(
        sys.executable if getattr(sys, "frozen", False) else __file__)), "pod_data.xlsx"))
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    app = create_app(a.data)
    url = f"http://127.0.0.1:{a.port}/"
    print(f"Pod cross-pollination tool\n  data file: {os.path.abspath(a.data)}\n  open:      {url}\n  (Ctrl+C to stop)")
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=a.port, threaded=True)


if __name__ == "__main__":
    main()
